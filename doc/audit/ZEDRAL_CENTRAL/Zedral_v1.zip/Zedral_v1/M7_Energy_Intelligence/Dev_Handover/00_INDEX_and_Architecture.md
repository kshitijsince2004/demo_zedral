# Zedral · M7 Energy Intelligence — Developer Handover
### 00 · Master Index, Architecture, Stack & Conventions
**Audience:** engineering team · **Status:** v1 for build (dual-lens energy: ABSOLUTE consumption/cost/carbon + NORMALISED intensity/EnPI vs regression baseline; all-utilities multi-carrier energy balance; SEU register; ISO 50006 EnB/EnPI; IPMVP M&V; max-demand / power-factor / time-of-use; GHG Scope 1/2 + ISO 14404 steel CO₂ intensity; priced energy waste; automatic metering, SCADA/BMS & prediction = interfaces only) · **Date:** 2026-06-19

> This is the build-ready specification set for **M7 · Energy Intelligence**, the platform's energy-and-carbon system-of-record and energy-management information system — the **last module** (after M2–M6). The foundation layers (Data Lake, Canonical Model, Manifold, Unified Intelligence, Monitoring, Reporting, Financial Impact, Platform/Security) are in `../../Dev_Handover/`; sibling modules are in `../../M2_Maintenance_Intelligence/` … `../../M6_Quality_Intelligence/`. Read this index first: module scope, the architecture, which **platform decisions (D1–D11)** bind M7, the **stack** M7 inherits, M7-specific conventions, and the **build roadmap**. The *why* behind every spec is the Energy deep-plan one level up: `../M7_Energy_Intelligence_DeepPlan.md`.

---

## 1. Document set & reading order

| # | Spec | Build priority |
|---|------|----------------|
| 00 | **This index** — architecture, stack, conventions, roadmap | Read first |
| 01 | **Data Model & Schema** — new energy entities, DDL dictionary (`energy_schema.sql`), the no-double-count anchor | Phase M7-0 |
| 02 | **Normalisation, Baseline & M&V** — common-unit GJ/CO₂e, energy balance, EnB/EnPI (ISO 50006), CUSUM, IPMVP | Phase M7-1/2 |
| 03 | **Metering Capture & On-ramp** — meter hierarchy, capture fidelities, meter device-management / data-quality gate | Phase M7-1 |
| 04 | **Carriers, SEU & Allocation** — carrier model, SEU register, allocation down the tree, genealogy | Phase M7-1/2 |
| 05 | **Demand, Tariff, Carbon & Aggregation** — max-demand/PF/ToU, tariff decomposition, Scope 1/2 + ISO 14404, rollup pipeline | Phase M7-2/3 |
| 06 | **KPIs, Analytics & Financial/Carbon** — formulas + SQL, registry, M7↔M4/M5/M6 reconciliation, priced waste | Phase M7-2/3 |
| 07 | **APIs, Events & Integration** — Serving APIs, published events, sibling contracts | Phase M7-2 |
| 08 | **Prediction / Future-scope Interfaces** — load/demand forecast, anomaly, energy-signature, DR & tariff-opt; the shared ML gate | Future |
| 09 | **Security, RBAC, NFRs & Acceptance** — roles, audit, NFRs, acceptance tests | All phases |
| 10 | **Glossary** | Reference |

---

## 2. Module scope (what M7 is, in one screen)

M7 is the **energy-and-carbon intelligence layer over a shared production truth** — it consumes the canonical `ProductionCount` + `StateInterval` + genealogy, meters or ingests **every energy carrier** (electricity, gas, steam, compressed air, water), and adds normalisation, the energy balance, EnB/EnPI, M&V, demand/PF management, carbon and cost. Like M6 (and unlike pure thin-write M4/M5), M7 **owns new transactional data** (`energy.meter`, `energy.meter_reading`, `energy.energy_consumption`) — but anchors every consumption row to the *one* shared `ProductionCount` / `StateInterval` so energy, OEE, yield and quality never disagree.

**Two lenses (deep-plan §2, the M7 equivalent of M5's dual-basis & M6's dual-lens):** the **ABSOLUTE** lens (kWh/GJ/₹/kgCO₂e — what we drew & spent) and the **NORMALISED** lens (EnPI/SEC — energy ÷ driver, regression-adjusted — are we actually efficient?). Both first-class.

**Non-goals (neighbouring modules/systems):** data capture itself (M1 owns first-party reads/bills/logs; M7 consumes canonical readings); the machine **state** (M4 owns `StateInterval`; M7 *reads it* to split energy by state); **material accounting** (M5 owns *how much* was lost; M7 attributes the *embodied energy*); the good/defective split (M6 owns it; M7 attributes embedded energy); the plan (M3 — M7 *feeds* ToU/demand headroom); the financial ledger (M7 *feeds* Financial Impact). **Future-proofed interfaces only, not v1 build:** automatic interval metering & meter device management, real-time SCADA/BMS streaming, automated demand response / load control, the tariff-optimisation engine (hooks present: `meter`, `tariff`, `demand_interval`, the streaming interface).

---

## 3. Architecture (engines & data flow)

```mermaid
flowchart LR
  SRC["M1 manual reads/bills/fuel-logs · ingested EMS/historian · interval meters/SCADA/BMS (future)"] --> CAP["E2 Consumption Capture & Normalisation (GJ + CO2e · allocate · basis/fidelity)"]
  REF["E1 Energy Reference & Policy (carrier·GJ/CO2 factors·metering tree·SEU·EnPI·tariff·emission factors)"] --> CAP
  CAP --> BAL["E3 Energy Balance & EnPI (close balance · EnB · EnPI/SEC regression)"]
  BAL --> MV["E4 M&V, Demand & Power-Quality (CUSUM · avoided energy · max-demand · PF · ToU)"]
  CAP --> CO2["E5 Carbon (Scope 1/2 location+market · ISO 14404)"]
  BAL & MV & CO2 --> KPI["E6 KPI & Cost (EnPI · ₹ · kgCO2e, priced & ranked)"]
  KPI --> CANON["Canonical zone + Serving"]
  CANON --> SIB["M4 energy-by-state · M5/M6 embodied energy · M3 ToU/demand · UIL · Monitoring · Financial · Reporting"]
  PRED["E7 forecast / DR / tariff-opt — FUTURE"] -. future .-> MV
```

Engines map 1:1 to deep-plan §3. E7 (forecast/DR/optimise) is wired but dark (spec 08).

---

## 4. Platform decisions that bind M7 (D1–D11, doc 04)

- **D2** near-real-time minutes default → live load/demand tile & peak-approach alerts on the streaming path (where automatic metering exists); EnPI/baseline recompute as scheduled rollup.
- **D4** Excel/CSV + generic DB connector first → v1 ingest of bills/meter exports via Manifold; meter/SCADA connectors are the switch-on on-ramp.
- **D5** conservative auto-map + review queue → carrier/meter/tariff mapping from an ingested source goes through Manifold's review queue, never blind.
- **D6** "Standard" KPI tier → v1 publishes EnPI/SEC, absolute consumption, energy cost/t, CO₂/t, demand & PF (descriptive/diagnostic); forecast/DR later.
- **D7** cost-rates client-owned, "rate-as-of-event" → energy cost & carbon priced against the tariff/factor effective at the consumption window; embodied-energy € is M5/M6's loss energy (counted once).
- **D9** rules now / ML later → demand/PF/CUSUM signals are deterministic in v1; forecasting/anomaly/DR is spec 08, gated.
- **D11** second-sector validation → exercise the normalised-lens regression & demand engine on an electricity-dominant discrete client (deep-plan §10).

---

## 5. Stack (inherited; no new infra)

Postgres (`energy` schema; OLTP energy SoR — append-only consumption/bills/baselines), TimescaleDB/ClickHouse for `meter_reading` & interval/EnPI time-series and demand rollups, Kafka/Flink for the live load/demand tile & alerts, Redis for the live cache, Airflow for scheduled baseline/EnPI/carbon recompute, FastAPI Serving APIs, React UI, Keycloak RBAC. Same as M4/M5/M6 — M7 adds no new infrastructure; the automatic-metering edge collectors (future) are the only new component, on the §5 interface.

---

## 6. M7-specific conventions

- **Schema `energy`** — not a reserved word; no quoting needed (unlike M5's `"yield"`). NB: the reserved word `window` is avoided — the demand-window column is `window_kind`.
- **Meter/MeterReading/EnergyConsumption are MASTERED here** (M7 is the SoR) but every `energy_consumption` is anchored to `canon.production_count_id` (EnPI denominator), `canon.state_interval` (M4 state, soft ref) and `canon.material_lot` (genealogy) — the no-double-count rule. M4/M5/M6 read M7 via the Serving energy projection (spec 07), never by querying `energy.*` directly (golden rule).
- **Soft refs** (`state_interval_ref` → M4, `m5_loss_ref` → M5, `m6_defect_ref` → M6, `cost_centre_ref`) are plain BIGINT, no cross-schema FK. Hard FK only to `canon.*` and within `energy.*`.
- **SUM-then-divide** roll-ups (`v_enpi_rollup` = Σenergy ÷ Σdriver) — never average per-period EnPI ratios (the Simpson's-paradox trap, as in M4/M5/M6).
- **Basis & fidelity on every consumption row** — `METERED`/`BILLED`/`APPORTIONED`/`ESTIMATED` × `MANUAL`/`BILL`/`INGESTED`/`AUTOMATIC`; an apportioned number is never shown with sub-meter confidence (deep-plan §3/§5).
- **Energy balance gap is data honesty, not waste** — `energy_balance.unmetered_gap_gj` is surfaced as a coverage figure, never booked as efficiency loss (the M5 mass-balance analogue).
- **Effective-dated factors** — `emission_factor` & `tariff` are "rate-as-of" (D7); a historical GJ/kgCO₂e/₹ uses the factor in force then.
- **Reconciliation is a CI test** — EnPI denominator == M4/M5/M6 tonnes; idle-energy tied to M4 `StateInterval`; embodied-energy == M5 loss energy == M6 defect energy, counted once (spec 06 §4, spec 09).

---

## 7. Build roadmap

| Phase | Scope | Specs |
|---|---|---|
| **M7-0** | Energy reference & policy + canonical wiring (carrier catalog + GJ/CO₂ factors; metering tree; SEU register; EnPI defs; tariff); bring canonical Meter/MeterReading/EnergyConsumption to life; repoint existing dashboards onto `energy.*` | 01, 03, 04 |
| **M7-1** | Consumption capture + balance + absolute lens (reads/bills/fuel-logs → GJ + CO₂e; allocate; close balance) | 02, 03, 04 |
| **M7-2** | EnPI/baseline + normalised lens + M&V (regression EnB, CUSUM, IPMVP); **M7↔M4 (energy-by-state) + M7↔M5/M6 (embodied energy) reconciliation** | 02, 06 |
| **M7-3** | Demand/PF/ToU + carbon (Scope 1/2 + ISO 14404) + priced waste + Monitoring board + ISO 50001/CO₂ reporting | 05, 06, 07 |
| **M7-4** | Automatic interval metering / SCADA / BMS switch-on — Coverage/Fidelity gate rises; real-time demand | 03, 07 |
| **Future** | Load/demand forecast + excess anomaly + energy-signature + prescriptive tariff/load/DG opt & automated DR — gated on the shared ML-readiness History gate | 08 |
