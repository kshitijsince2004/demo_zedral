# 02 · Normalisation, Baseline & M&V Spec
**Build:** Phase M7-1/2 · deep-plan §4

> M7's calculation core — the engine that turns raw kWh/m³/tonnes into a defensible EnPI, a closed energy balance, and an auditable saving. Standards-literal so an EnPI survives an ISO 50001 audit and a saving survives finance under IPMVP.

## 1. Common-unit conversion (the precondition)

Every carrier → **GJ** via `energy_carrier.gj_per_native_unit` (electricity ×3.6e-3 final, or source-primary per `energy_config.energy_basis`; gas/fuel by NCV; steam by enthalpy; compressed air & water by specific energy back to electricity). Every carrier → **kgCO₂e** via the effective-dated `emission_factor` (spec 05). Conversion factors are versioned reference data — a historical GJ/kgCO₂e uses the factor in force **then** (D7 rate-as-of). Output: each `meter_reading` / `utility_bill` line becomes one or more `energy_consumption` rows in GJ + CO₂e with a `basis` and `fidelity`.

## 2. The energy balance (close it, name the gap)

Per carrier × period, populate `energy_balance`: `purchased_gj + generated_gj = distributed_gj + measured_loss_gj + unmetered_gap_gj`. The **gap** is a metering-coverage figure (`gap_pct` = gap ÷ boundary). It is surfaced via `v_energy_balance_recon`, flagged when above `energy_config.balance_gap_tolerance` (default 5%), and **never** booked as waste or saving — the M5 mass-balance honesty rule. A falling gap = better metering, not less energy.

## 3. EnB & EnPI (ISO 50006-literal)

- **Simple EnPI / SEC** = energy ÷ output (GJ/t, kWh/t) — the entry point, `enpi_kind = SPECIFIC`.
- **Regression baseline** (`energy_baseline.method = REGRESSION`): `Energy = β₀ + β₁·Production + β₂·Weather(HDD/CDD) + β₃·Mix + …`, fitted over ≥12 months (`baseline_from/to`), `coefficients` JSONB + `r_squared`. The **intercept β₀ is the standing/no-load load** — which is exactly why a ratio misrepresents low-utilisation periods and a regression does not.
- **Expected energy** = the baseline model evaluated at *this* period's drivers → `enpi_value.enpi_expected`.
- **Performance** = `variance_gj = actual − expected` (the residual). Never compare raw period-to-period; always actual vs baseline-projected at current conditions.
- Baselines are **versioned** (`version_no`, `is_current`); a re-baseline preserves history (audit). Driver set per `energy_config.normalisation_drivers`.

## 4. CUSUM (the drift detector — M7's analogue of SPC)

`enpi_value.cusum_gj` = running cumulative sum of residuals. Flat CUSUM ⇒ tracking baseline; a **slope change** pinpoints *when* a process drifted off its energy baseline (fouling furnace, stuck damper, developing air leak) — weeks before the monthly bill. A sustained positive slope raises an **excess/drift signal** → investigate the SEU. This is to energy what the control chart is to quality: catch the drift, not the month-end surprise.

## 5. Measurement & Verification (IPMVP)

A saving is **avoided energy** = baseline-projected − actual at current conditions (`enpi_value.avoided_energy_gj`), *not* naïve before/after (which would credit a production drop as a saving). Option per situation: **A** (retrofit isolation, key-parameter), **B** (retrofit isolation, all-parameter — needs a sub-meter), **C** (whole-facility regression, savings >~10% of total — the v1 default off bills), **D** (calibrated simulation — future). The chosen option and the reporting baseline are stored with the saving.

## 6. Acceptance (this spec)

Given a year of bills + monthly tonnes: the regression baseline fits with documented R²; expected vs actual reproduces a known month within ε; the energy balance closes within tolerance with the gap named; the EnPI rollup uses Σenergy ÷ Σdriver (not averaged ratios); a re-baseline preserves the prior version. M&V avoided-energy matches a hand-worked IPMVP-C example.
