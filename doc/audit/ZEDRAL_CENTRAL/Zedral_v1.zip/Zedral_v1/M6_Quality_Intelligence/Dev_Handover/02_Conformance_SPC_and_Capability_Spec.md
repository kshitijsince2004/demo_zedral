# 02 · Conformance, SPC & Capability Spec
**Phase M6-1/2 · deep-plan §4**

## 1. Chart selection (the two lenses in code)

| Data | Subgroup | Chart (`control_chart.chart_type`) |
|---|---|---|
| variable | 2–~9 | `XBAR_R` (mean & range) |
| variable | ≥ ~10 | `XBAR_S` (mean & std-dev) |
| variable | individual (n=1, e.g. one coil) | `I_MR` (individual & moving range) |
| attribute | proportion / number defective | `P` / `NP` |
| attribute | defects per unit / area | `C` / `U` |

Hero Steels default: `I_MR` per coil for gauge; `P`/`U` for surface defect rate; capability on thickness per grade.

## 2. Run-rule sets (`spc_signal.rule_code`)

Ship **Western Electric** + **Nelson**, tenant-tunable subset (`quality_config.default_spc_rule_set`). Minimum rule pack:

| Rule | Trigger | Detects |
|---|---|---|
| WE1 | 1 point beyond 3σ | classic special cause |
| WE2 | 2 of 3 beyond 2σ (same side) | shift the limit misses |
| WE3 | 4 of 5 beyond 1σ (same side) | smaller shift |
| WE4 / Nelson | 8 (or 9) consecutive one side of centre | sustained shift |
| Nelson3 | 6–7 points steadily rising/falling | drift (tool wear, temp creep) |
| Nelson7/8 | 15 hugging centre / 8 avoiding it | stratification/mixture — **MSA red flag** |

A signal raises a `spc_signal` row and (via spec 07 events) a containment prompt — but only a **special cause** acts; common-cause variation must **not** trigger tampering (deep-plan Principle 4).

## 3. Process capability (`control_chart.cp/cpk/pp/ppk`)

| Index | Formula | Note |
|---|---|---|
| Cp | (USL−LSL)/6σ_within | spread only; process must be **in control** first |
| Cpk | min[(USL−μ), (μ−LSL)]/3σ_within | spread + centring (the one that matters) |
| Pp/Ppk | same, σ_overall | long-run performance |

Rules: compute **only for an in-control chart** (`in_control = TRUE`) and **only with `characteristic.msa_status IN ('ACCEPTABLE','MARGINAL')`** when `quality_config.msa_blocks_capability = TRUE` (else publish with low-confidence flag). Surface the **Cpk vs Ppk gap** as a between-subgroup-variation diagnostic. Targets: `cpk_target` (1.33) general, `cpk_target_critical` (1.67) for `criticality='CRITICAL'`.

## 4. Conformance metrics (ISO 22400-literal — agree with M4/M5 by construction)

From the *one* `canon.production_count`:
- **FPY** = good first-time ÷ started (== M5 FPY).
- **Quality Ratio** = good ÷ produced (**== M4 Quality factor**, the reconciliation invariant).
- **Scrap/Rework Ratio** = scrap or rework ÷ produced (== M5's loss accounting basis).
- **DPU** = defects ÷ units; **DPMO/ppm** = (defects ÷ (units × opportunities)) × 10⁶.

## 5. Sampling (`inspection_plan_item.sampling_basis`)

`FULL_100PCT` (critical / vision-automated), `AQL_2859` (lot-by-lot, `aql_pct` + critical/major/minor classes + inspection level), `FIXED_N` (e.g. one coupon/coil for mechanicals), `CONTINUOUS_SPC` (subgroup at a frequency). The plan is versioned reference data part of the control plan (spec 03).

## 6. Recompute & replay

SPC limits recomputed on a schedule (`limits_recalc_at`) or on demand after a process change; capability recomputed per rollup window. All recomputation is **deterministic & replayable** from `qual.measurement` + `canon.production_count` — a corrected measurement re-derives the affected chart, signals and Cpk without manual patching (deep-plan §13).
