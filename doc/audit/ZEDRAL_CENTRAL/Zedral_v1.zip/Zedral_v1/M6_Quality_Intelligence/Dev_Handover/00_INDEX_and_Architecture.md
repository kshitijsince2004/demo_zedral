# Zedral · M6 Quality Intelligence — Developer Handover
### 00 · Master Index, Architecture, Stack & Conventions
**Audience:** engineering team · **Status:** v1 for build (dual-lens conformance: ATTRIBUTE defect/disposition + VARIABLE measurement/SPC/capability; governed defect taxonomy; quality holds; NCR → MRB → disposition incl. grade-downgrade; CAPA/8D; Cost of Quality; auto-capture & prediction = interfaces only) · **Date:** 2026-06-19

> This is the build-ready specification set for **M6 · Quality Intelligence**, the platform's quality system-of-record and conformance module (the foundation layers — Data Lake, Canonical Model, Manifold, Unified Intelligence, Monitoring, Reporting, Financial Impact, Platform/Security — are specified in `../../Dev_Handover/`; sibling modules are in `../../M2_Maintenance_Intelligence/`, `../../M3_Shopfloor_Planning_Management/`, `../../M4_OEE_Downtime/`, `../../M5_Yield_Intelligence/`). Read this index first: module scope, the architecture, which **platform decisions (D1–D11)** bind M6, the **stack** M6 inherits, M6-specific conventions, and the **build roadmap**. The *why* behind every spec is the Quality deep-plan one level up: `../M6_Quality_Intelligence_DeepPlan.md`.

---

## 1. Document set & reading order

| # | Spec | Build priority |
|---|------|----------------|
| 00 | **This index** — architecture, stack, conventions, roadmap | Read first |
| 01 | **Data Model & Schema** — new quality entities, DDL dictionary (`qual_schema.sql`), the no-double-count anchor | Phase M6-0 |
| 02 | **Conformance, SPC & Capability** — chart families, WE/Nelson rules, Cp/Cpk/Pp/Ppk, ISO 22400 reconciliation | Phase M6-1/2 |
| 03 | **Inspection Capture, Genealogy & On-ramp** — control plan, capture fidelities, MSA gate | Phase M6-1 |
| 04 | **Defect Taxonomy & Disposition** — 3-layer codes, criticality, MRB disposition, grade-downgrade | Phase M6-1/2 |
| 05 | **NCR, CAPA & Aggregation Pipeline** — NCR/MRB workflow, 8D, events, rollup pipeline | Phase M6-2/3 |
| 06 | **KPIs, Analytics & Cost of Quality** — formulas + SQL, registry, M6↔M4 / M6↔M5 reconciliation, PAF | Phase M6-2/3 |
| 07 | **APIs, Events & Integration** — Serving APIs, published events, sibling contracts | Phase M6-2 |
| 08 | **Prediction / Future-scope Interfaces** — defect-risk, SPC-excursion, CV; the shared ML gate | Future |
| 09 | **Security, RBAC, NFRs & Acceptance** — roles, audit, NFRs, acceptance tests | All phases |
| 10 | **Glossary** | Reference |

---

## 2. Module scope (what M6 is, in one screen)

M6 is the **conformance-and-intelligence layer over a shared truth** — it consumes the canonical `ProductionCount` + measurements + defect events, and adds SPC, the governed defect taxonomy, disposition, CAPA and Cost of Quality. Unlike M4/M5 (pure thin-write), M6 **owns the conformance record** (`qual.defect_record`, `qual.inspection`, `qual.measurement`) — but anchors every row to the *one* shared `ProductionCount` so quality, yield and OEE never disagree.

**Two lenses (deep-plan §2, the M6 equivalent of M5's dual-basis):** the **VARIABLE** lens (measured characteristic → SPC → Cp/Cpk/Pp/Ppk — catches the *drift before* a defect) and the **ATTRIBUTE** lens (non-conformance → defect → disposition — catches the *reject event*). Both first-class.

**Non-goals (neighbouring modules/systems):** data capture itself (M1 owns first-party capture; M6 consumes canonical measurements/defects); **material accounting & economics** (M5 owns *how much* was lost and *what it cost* on the *shared* DefectRecord; M6 owns *why* it's bad and *what we decided*); the **OEE Quality factor** (M4 owns it on the *shared* ProductionCount; M6 supplies the defect taxonomy/disposition behind it); the plan/route/sequence (M3 — M6 *feeds* quality holds); the financial ledger (M6 *feeds* Financial Impact, doesn't own cost accounting). **Future-proofed interfaces only, not v1 build:** supplier-quality scorecards, audit management, document/training control (hooks present: `defect_source`, `policy_change_log`).

---

## 3. Architecture (engines & data flow)

```mermaid
flowchart LR
  SRC["M1 inline checks/defects/lab · ingested QMS/LIMS · inline gauge/vision (future)"] --> CAP["E2 Conformance Capture (MSA-aware)"]
  REF["E1 Quality Reference & Policy (characteristic·spec·control plan·taxonomy·SPC rules·COQ map)"] --> CAP
  CAP --> SPC["E3 SPC & Capability (charts·WE/Nelson·Cpk·signal)"]
  CAP --> DISP["E4 Defect·Hold·Disposition (classify·hold·NCR·MRB)"]
  SPC --> DISP --> CAPA["E5 CAPA / Root-cause (5-Why·fishbone·8D·verify)"]
  SPC & DISP & CAPA --> KPI["E6 KPI & Cost-of-Quality"]
  KPI --> CANON["Canonical zone + Serving"]
  CANON --> SIB["M4 Q-factor · M5 priced loss · M3 holds · UIL · Monitoring · Financial · Reporting"]
  PRED["E7 prediction / CV — FUTURE"] -. future .-> SPC
```

Engines map 1:1 to deep-plan §3. E7 (prediction/CV) is wired but dark (spec 08).

---

## 4. Platform decisions that bind M6 (D1–D11, doc 04)

- **D2** near-real-time minutes default → SPC tile & out-of-control alerts on the streaming path; capability recompute as scheduled rollup.
- **D5** conservative auto-map + review queue → defect-code & spec mapping from an ingested QMS goes through Manifold's review queue, never blind.
- **D6** "Standard" KPI tier → v1 publishes FPY, Quality-ratio, defect ppm, Cpk, COQ (descriptive/diagnostic); prediction later.
- **D7** cost-rates client-owned, "rate-as-of-event" → Cost of Quality prices against the rate effective at detection; internal-failure € is M5's priced loss (counted once).
- **D9** rules now / ML later → SPC run-rules & disposition rules are deterministic in v1; defect/excursion prediction is spec 08, gated.
- **D11** second-sector validation → exercise the VARIABLE lens & capability on a discrete/Cpk-led client (deep-plan §10).

---

## 5. Stack (inherited; no new infra)

Postgres (`qual` schema; OLTP conformance SoR — append-only NCR/CAPA), TimescaleDB/ClickHouse for measurement & SPC time-series and capability rollups, Kafka/Flink for the live SPC tile & alerts, Redis for the live cache, Airflow for scheduled capability recompute, FastAPI Serving APIs, React UI, Keycloak RBAC. Same as M4/M5 — M6 adds no new infrastructure.

---

## 6. M6-specific conventions

- **Schema `qual`** — not a reserved word (unlike M5's `"yield"`); no quoting needed.
- **DefectCode/DefectRecord are MASTERED here** (M6 is the SoR) but `defect_record` is **registered on the canonical Event Spine** (`event_id`) and anchored to `canon.production_count_id` — the no-double-count rule. M4/M5 read it via the Serving DefectRecord projection (spec 07), never by querying `qual.*` directly (golden rule).
- **Soft refs** (`route_ref` → M3 `ops.route`, equipment-condition → M2 `maint.work_order`) are plain BIGINT, no cross-schema FK. Hard FK only to `canon.*` and within `qual.*`.
- **SUM-then-divide** roll-ups (`v_quality_rollup`) — never average sub-ratios (the Simpson's-paradox trap, as in M4/M5).
- **MSA gate** — no published Cpk for an unqualified gage (deep-plan §5, `quality_config.msa_blocks_capability`).
- **Reconciliation is a CI test** — M6 Quality-loss == M4 Quality factor; M6 disposition material == M5 priced loss (spec 06 §4, spec 09).

---

## 7. Build roadmap

| Phase | Scope | Specs |
|---|---|---|
| **M6-0** | Quality reference & policy + canonical wiring (characteristic/spec/control-plan/taxonomy → criticality/disposition/LossCategory map); bring canonical DefectCode/DefectRecord to life; repoint existing dashboards onto `canon.*` | 01, 03, 04 |
| **M6-1** | Conformance capture + attribute conformance (inspection/measurement/defect from M1); FPY/Quality-ratio/defect-rate; **M6↔M4 reconciliation** | 02, 03, 04 |
| **M6-2** | SPC & capability (charts, WE/Nelson, Cpk, MSA-gated) + holds & disposition (incl. grade-downgrade); **M6↔M5 reconciliation** | 02, 04, 06 |
| **M6-3** | CAPA/8D + Cost of Quality (PAF; internal-failure == M5 loss, once) + Monitoring board + COA/MTC reporting | 05, 06, 07 |
| **M6-4** | Automatic capture (inline gauge/lab/vision) switch-on — Fidelity/MSA gate rises | 03, 07 |
| **Future** | Defect/SPC prediction + CV — gated on the shared ML-readiness History gate | 08 |
