# Zedral · M7 Energy Intelligence — Developer Handover
### 00 · Master Index, Architecture, Stack & Conventions
**Audience:** engineering team · **Status:** v1 for build (dual-lens energy: ABSOLUTE consumption/cost/carbon + NORMALISED intensity/EnPI vs regression baseline; all-utilities multi-carrier energy balance; SEU register; ISO 50006 EnB/EnPI; IPMVP M&V; max-demand / power-factor / time-of-use; GHG Scope 1/2 + ISO 14404 steel CO₂ intensity; priced energy waste; automatic metering, SCADA/BMS & prediction = interfaces only) · **Date:** 2026-06-19

> This is the build-ready specification set for **M7 · Energy Intelligence**, the platform's energy-and-carbon system-of-record and energy-management information system — the **last module** (after M2–M6). The foundation layers (Data Lake, Canonical Model, Manifold, Unified Intelligence, Monitoring, Reporting, Financial Impact, Platform/Security) are in `../../Dev_Handover/`; sibling modules are in `../../M2_Maintenance_Intelligence/` … `../../M6_Quality_Intelligence/`. Read this index first: module scope, the architecture, which **platform decisions (D1–D11)** bind M7, the **stack** M7 inherits, M7-specific conventions, and the **build roadmap**. The *why* behind every spec is the Energy deep-plan one level up: `../M7_Energy_Intelligence_DeepPlan.md`.

---

## 1. Document set & reading order

| # | Spec | Build priority |
|---|------|----------------|
| 00 | **This index** — architecture, stack, conventions, roadmap | Read first |
| 01 | **Data Model & Schema** — new energy entities, DDL dictionary (`energy_schema.sql`), the no-double-count anchor | Phase M7-0 |
| 02 | **Normalisation, Baseline & M&V** — common-unit GJ/CO₂e, energy balance, EnB/EnPI (ISO 50006), CUSUM, IPMVP | Phase M7-1/2 |
| 03 | **Metering Capture & On-ramp** — meter hierarchy, capture fidelities, meter device-management / data-quality gate | Phase M7-1 |
| 04 | **Carriers, SEU & Allocation** — carrier model, SEU register, allocation down the tree, genealogy | Phase M7-1/2 |
| 05 | **Demand, Tariff, Carbon & Aggregation** — max-demand/PF/ToU, tariff decomposition, Scope 1/2 + ISO 14404, rollup pipeline | Phase M7-2/3 |
| 06 | **KPIs, Analytics & Financial/Carbon** — formulas + SQL, registry, M7↔M4/M5/M6 reconciliation, priced waste | Phase M7-2/3 |
| 07 | **APIs, Events & Integration** — Serving APIs, published events, sibling contracts | Phase M7-2 |
| 08 | **Prediction / Future-scope Interfaces** — load/demand forecast, anomaly, energy-signature, DR & tariff-opt; the shared ML gate | Future |
| 09 | **Security, RBAC, NFRs & Acceptance** — roles, audit, NFRs, acceptance tests | All phases |
| 10 | **Glossary** | Reference |

---

## 2. Module scope (what M7 is, in one screen)

M7 is the **energy-and-carbon intelligence layer over a shared production truth** — it consumes the canonical `ProductionCount` + `StateInterval` + genealogy, meters or ingests **every energy carrier** (electricity, gas, steam, compressed air, water), and adds normalisation, the energy balance, EnB/EnPI, M&V, demand/PF management, carbon and cost. Like M6 (and unlike pure thin-write M4/M5), M7 **owns new transactional data** (`energy.meter`, `energy.meter_reading`, `energy.energy_consumption`) — but anchors every consumption row to the *one* shared `ProductionCount` / `StateInterval` so energy, OEE, yield and quality never disagree.

**Two lenses (deep-plan §2, the M7 equivalent of M5's dual-basis & M6's dual-lens):** the **ABSOLUTE** lens (kWh/GJ/₹/kgCO₂e — what we drew & spent) and the **NORMALISED** lens (EnPI/SEC — energy ÷ driver, regression-adjusted — are we actually efficient?). Both first-class.

**Non-goals (neighbouring modules/systems):** data capture itself (M1 owns first-party reads/bills/logs; M7 consumes canonical readings); the machine **state** (M4 owns `StateInterval`; M7 *reads it* to split energy by state); **material accounting** (M5 owns *how much* was lost; M7 attributes the *embodied energy*); the good/defective split (M6 owns it; M7 attributes embedded energy); the plan (M3 — M7 *feeds* ToU/demand headroom); the financial ledger (M7 *feeds* Financial Impact). **Future-proofed interfaces only, not v1 build:** automatic interval metering & meter device management, real-time SCADA/BMS streaming, automated demand response / load control, the tariff-optimisation engine (hooks present: `meter`, `tariff`, `demand_interval`, the streaming interface).

---

## 3. Architecture (engines & data flow)

```mermaid
flowchart LR
  SRC["M1 manual reads/bills/fuel-logs · ingested EMS/historian · interval meters/SCADA/BMS (future)"] --> CAP["E2 Consumption Capture & Normalisation (GJ + CO2e · allocate · basis/fidelity)"]
  REF["E1 Energy Reference & Policy (carrier·GJ/CO2 factors·metering tree·SEU·EnPI·tariff·emission factors)"] --> CAP
  CAP --> BAL["E3 Energy Balance & EnPI (close balance · EnB · EnPI/SEC regression)"]
  BAL --> MV["E4 M&V, Demand & Power-Quality (CUSUM · avoided energy · max-demand · PF · ToU)"]
  CAP --> CO2["E5 Carbon (Scope 1/2 location+market · ISO 14404)"]
  BAL & MV & CO2 --> KPI["E6 KPI & Cost (EnPI · ₹ · kgCO2e, priced & ranked)"]
  KPI --> CANON["Canonical zone + Serving"]
  CANON --> SIB["M4 energy-by-state · M5/M6 embodied energy · M3 ToU/demand · UIL · Monitoring · Financial · Reporting"]
  PRED["E7 forecast / DR / tariff-opt — FUTURE"] -. future .-> MV
```

Engines map 1:1 to deep-plan §3. E7 (forecast/DR/optimise) is wired but dark (spec 08).

---

## 4. Platform decisions that bind M7 (D1–D11, doc 04)

- **D2** near-real-time minutes default → live load/demand tile & peak-approach alerts on the streaming path (where automatic metering exists); EnPI/baseline recompute as scheduled rollup.
- **D4** Excel/CSV + generic DB connector first → v1 ingest of bills/meter exports via Manifold; meter/SCADA connectors are the switch-on on-ramp.
- **D5** conservative auto-map + review queue → carrier/meter/tariff mapping from an ingested source goes through Manifold's review queue, never blind.
- **D6** "Standard" KPI tier → v1 publishes EnPI/SEC, absolute consumption, energy cost/t, CO₂/t, demand & PF (descriptive/diagnostic); forecast/DR later.
- **D7** cost-rates client-owned, "rate-as-of-event" → energy cost & carbon priced against the tariff/factor effective at the consumption window; embodied-energy € is M5/M6's loss energy (counted once).
- **D9** rules now / ML later → demand/PF/CUSUM signals are deterministic in v1; forecasting/anomaly/DR is spec 08, gated.
- **D11** second-sector validation → exercise the normalised-lens regression & demand engine on an electricity-dominant discrete client (deep-plan §10).

---

## 5. Stack (inherited; no new infra)

Postgres (`energy` schema; OLTP energy SoR — append-only consumption/bills/baselines), TimescaleDB/ClickHouse for `meter_reading` & interval/EnPI time-series and demand rollups, Kafka/Flink for the live load/demand tile & alerts, Redis for the live cache, Airflow for scheduled baseline/EnPI/carbon recompute, FastAPI Serving APIs, React UI, Keycloak RBAC. Same as M4/M5/M6 — M7 adds no new infrastructure; the automatic-metering edge collectors (future) are the only new component, on the §5 interface.

---

## 6. M7-specific conventions

- **Schema `energy`** — not a reserved word; no quoting needed (unlike M5's `"yield"`). NB: the reserved word `window` is avoided — the demand-window column is `window_kind`.
- **Meter/MeterReading/EnergyConsumption are MASTERED here** (M7 is the SoR) but every `energy_consumption` is anchored to `canon.production_count_id` (EnPI denominator), `canon.state_interval` (M4 state, soft ref) and `canon.material_lot` (genealogy) — the no-double-count rule. M4/M5/M6 read M7 via the Serving energy projection (spec 07), never by querying `energy.*` directly (golden rule).
- **Soft refs** (`state_interval_ref` → M4, `m5_loss_ref` → M5, `m6_defect_ref` → M6, `cost_centre_ref`) are plain BIGINT, no cross-schema FK. Hard FK only to `canon.*` and within `energy.*`.
- **SUM-then-divide** roll-ups (`v_enpi_rollup` = Σenergy ÷ Σdriver) — never average per-period EnPI ratios (the Simpson's-paradox trap, as in M4/M5/M6).
- **Basis & fidelity on every consumption row** — `METERED`/`BILLED`/`APPORTIONED`/`ESTIMATED` × `MANUAL`/`BILL`/`INGESTED`/`AUTOMATIC`; an apportioned number is never shown with sub-meter confidence (deep-plan §3/§5).
- **Energy balance gap is data honesty, not waste** — `energy_balance.unmetered_gap_gj` is surfaced as a coverage figure, never booked as efficiency loss (the M5 mass-balance analogue).
- **Effective-dated factors** — `emission_factor` & `tariff` are "rate-as-of" (D7); a historical GJ/kgCO₂e/₹ uses the factor in force then.
- **Reconciliation is a CI test** — EnPI denominator == M4/M5/M6 tonnes; idle-energy tied to M4 `StateInterval`; embodied-energy == M5 loss energy == M6 defect energy, counted once (spec 06 §4, spec 09).

---

## 7. Build roadmap

| Phase | Scope | Specs |
|---|---|---|
| **M7-0** | Energy reference & policy + canonical wiring (carrier catalog + GJ/CO₂ factors; metering tree; SEU register; EnPI defs; tariff); bring canonical Meter/MeterReading/EnergyConsumption to life; repoint existing dashboards onto `energy.*` | 01, 03, 04 |
| **M7-1** | Consumption capture + balance + absolute lens (reads/bills/fuel-logs → GJ + CO₂e; allocate; close balance) | 02, 03, 04 |
| **M7-2** | EnPI/baseline + normalised lens + M&V (regression EnB, CUSUM, IPMVP); **M7↔M4 (energy-by-state) + M7↔M5/M6 (embodied energy) reconciliation** | 02, 06 |
| **M7-3** | Demand/PF/ToU + carbon (Scope 1/2 + ISO 14404) + priced waste + Monitoring board + ISO 50001/CO₂ reporting | 05, 06, 07 |
| **M7-4** | Automatic interval metering / SCADA / BMS switch-on — Coverage/Fidelity gate rises; real-time demand | 03, 07 |
| **Future** | Load/demand forecast + excess anomaly + energy-signature + prescriptive tariff/load/DG opt & automated DR — gated on the shared ML-readiness History gate | 08 |

\newpage

# 01 · Data Model & Schema Spec
**Build:** Phase M7-0 · **Runnable DDL:** `energy_schema.sql` (PostgreSQL 15+, schema `energy`, pglast-valid 50 statements: 19 enums, 22 tables, 3 indexes, 4 views)

> The *why* is deep-plan §6 (carriers/SEU/SoR) and §11 (data contract). This spec is the **what** the engineer builds against. M7 is the energy system-of-record: `meter`, `meter_reading`, `energy_consumption` are **mastered here**, but every consumption row is anchored to the *one* shared `canon.production_count` (EnPI denominator), `canon.state_interval` (M4 state) and `canon.material_lot` (genealogy) — so a tonne of steel and the energy that made it are recorded **once** and reconcile by construction.

## 1. Entity groups (22 tables)

**Reference & policy (6):** `energy_config` (per-tenant policy: energy basis, default baseline method, demand window, PF threshold, balance-gap tolerance, normalisation drivers, carbon-in-waste), `energy_carrier` (carrier + `gj_per_native_unit` + default scope), `emission_factor` (effective-dated kgCO₂e/GJ per carrier×scope×region), `seu` (Significant Energy Use register), `tariff` (demand/PF/fixed/carbon structure, effective-dated), `tariff_period` (ToU windows + energy rate).

**Metering & capture (3):** `meter` (hierarchy via `parent_meter_ref`, carrier, asset node, multiplier, comms protocol, health, calibration), `meter_reading` (raw cumulative/interval, kVA/PF registers), `utility_bill` (boundary invoice decomposition — v1 primary source).

**Consumption spine (1):** `energy_consumption` — the canonical carrier-normalised fact (native + GJ + CO₂e, `direction`, `basis`, `fidelity`, `allocation_method`, window), anchored to `production_count_id` / `state_interval_ref` / `material_lot_ref` / `seu_ref`.

**Balance, baseline, EnPI, M&V (4):** `energy_balance` (purchased+generated = distributed+loss+gap), `enpi_definition` (numerator scope ÷ denominator driver), `energy_baseline` (EnB regression: intercept + `coefficients` JSONB + R²; versioned), `enpi_value` (per-period actual/expected/variance/CUSUM/avoided).

**Demand, carbon, cost, waste (4):** `demand_interval` (max-demand & PF; peak events), `emission_entry` (computed Scope 1/2 carbon), `energy_cost_entry` (priced per tariff component, rate-as-of), `energy_waste_entry` (ranked avoidable waste, ₹ + carbon, with M4/M5/M6 anchors).

**Targets, governance, readiness, prediction (4):** `energy_target` (ISO 50001 objectives), `policy_change_log` (audit), `readiness_snapshot` (Required/Coverage/Fidelity/History gates), `energy_prediction` (future stub, `is_active=FALSE`).

## 2. The no-double-count anchor (the most important rule)

`energy_consumption.production_count_id` is the canonical `ProductionCount` — the **same** row M4 reads for OEE, M5 for yield, M6 for conformance. M7 never recomputes production, state, yield or defect:

- **EnPI denominator** = `SUM` of the production tonnes on those `production_count_id`s — identical to the number under OEE/yield/quality.
- **Idle-energy waste** (`energy_waste_entry.state_interval_ref`) is tied to the **same** `canon.state_interval` M4 classified as idle/down — one state, two costs (lost time + idle energy).
- **Embodied-energy waste** for loss/defect (`m5_loss_ref` / `m6_defect_ref`) is the energy spent on the **same** units M5 prices as material loss and M6 classifies as defective — counted **once**, never re-priced as a separate loss.

## 3. DDL conventions (inherit canonical 02 §5)

`lower_snake_case`; surrogate `BIGINT … GENERATED ALWAYS AS IDENTITY`; `UUID tenant_id`; `TIMESTAMPTZ` UTC; units in the column name (`quantity_gj`, `co2e_kg`, `kva_demand`); `JSONB ext` extension namespace on every table; **hard FK only to `canon.*` and within `energy.*`**; other-module references are soft `*_ref` BIGINT. Reserved word `window` avoided (`window_kind`).

## 4. Key constraints & indexes

`UNIQUE (tenant_id, code)` on carrier/SEU/meter/EnPI; `UNIQUE (tenant_id, meter_ref, read_at)` on readings; `UNIQUE (tenant_id, enpi_ref, version_no)` on baselines (version history preserved for audit); window `CHECK (end >= start)` throughout; indexes on `energy_consumption` by (carrier, window), (SEU, window) and (production_count_id) for the reconciliation join. `meter_reading` and `enpi_value`/`demand_interval` are TimescaleDB hypertable candidates (time-series).

## 5. Views (SUM-then-divide)

`v_energy_rollup` (GJ + CO₂e by carrier×month), `v_enpi_rollup` (Σenergy ÷ Σdriver — never average ratios), `v_energy_balance_recon` (boundary vs accounted + gap%), `v_carbon_rollup` (by scope×month). These are the Serving projections UIL/Reporting read.

\newpage

# 02 · Normalisation, Baseline & M&V Spec
**Build:** Phase M7-1/2 · deep-plan §4

> M7's calculation core — the engine that turns raw kWh/m³/tonnes into a defensible EnPI, a closed energy balance, and an auditable saving. Standards-literal so an EnPI survives an ISO 50001 audit and a saving survives finance under IPMVP.

## 1. Common-unit conversion (the precondition)

Every carrier → **GJ** via `energy_carrier.gj_per_native_unit` (electricity ×3.6e-3 final, or source-primary per `energy_config.energy_basis`; gas/fuel by NCV; steam by enthalpy; compressed air & water by specific energy back to electricity). Every carrier → **kgCO₂e** via the effective-dated `emission_factor` (spec 05). Conversion factors are versioned reference data — a historical GJ/kgCO₂e uses the factor in force **then** (D7 rate-as-of). Output: each `meter_reading` / `utility_bill` line becomes one or more `energy_consumption` rows in GJ + CO₂e with a `basis` and `fidelity`.

## 2. The energy balance (close it, name the gap)

Per carrier × period, populate `energy_balance`: `purchased_gj + generated_gj = distributed_gj + measured_loss_gj + unmetered_gap_gj`. The **gap** is a metering-coverage figure (`gap_pct` = gap ÷ boundary). It is surfaced via `v_energy_balance_recon`, flagged when above `energy_config.balance_gap_tolerance` (default 5%), and **never** booked as waste or saving — the M5 mass-balance honesty rule. A falling gap = better metering, not less energy.

## 3. EnB & EnPI (ISO 50006-literal)

- **Simple EnPI / SEC** = energy ÷ output (GJ/t, kWh/t) — the entry point, `enpi_kind = SPECIFIC`.
- **Regression baseline** (`energy_baseline.method = REGRESSION`): `Energy = β₀ + β₁·Production + β₂·Weather(HDD/CDD) + β₃·Mix + …`, fitted over ≥12 months (`baseline_from/to`), `coefficients` JSONB + `r_squared`. The **intercept β₀ is the standing/no-load load** — which is exactly why a ratio misrepresents low-utilisation periods and a regression does not.
- **Expected energy** = the baseline model evaluated at *this* period's drivers → `enpi_value.enpi_expected`.
- **Performance** = `variance_gj = actual − expected` (the residual). Never compare raw period-to-period; always actual vs baseline-projected at current conditions.
- Baselines are **versioned** (`version_no`, `is_current`); a re-baseline preserves history (audit). Driver set per `energy_config.normalisation_drivers`.

## 4. CUSUM (the drift detector — M7's analogue of SPC)

`enpi_value.cusum_gj` = running cumulative sum of residuals. Flat CUSUM ⇒ tracking baseline; a **slope change** pinpoints *when* a process drifted off its energy baseline (fouling furnace, stuck damper, developing air leak) — weeks before the monthly bill. A sustained positive slope raises an **excess/drift signal** → investigate the SEU. This is to energy what the control chart is to quality: catch the drift, not the month-end surprise.

## 5. Measurement & Verification (IPMVP)

A saving is **avoided energy** = baseline-projected − actual at current conditions (`enpi_value.avoided_energy_gj`), *not* naïve before/after (which would credit a production drop as a saving). Option per situation: **A** (retrofit isolation, key-parameter), **B** (retrofit isolation, all-parameter — needs a sub-meter), **C** (whole-facility regression, savings >~10% of total — the v1 default off bills), **D** (calibrated simulation — future). The chosen option and the reporting baseline are stored with the saving.

## 6. Acceptance (this spec)

Given a year of bills + monthly tonnes: the regression baseline fits with documented R²; expected vs actual reproduces a known month within ε; the energy balance closes within tolerance with the gap named; the EnPI rollup uses Σenergy ÷ Σdriver (not averaged ratios); a re-baseline preserves the prior version. M&V avoided-energy matches a hand-worked IPMVP-C example.

\newpage

# 03 · Metering Capture & On-ramp Spec
**Build:** Phase M7-1 · deep-plan §5

> Where M7's capture decision lives. **v1 bootstraps from M1 manual meter reads, typed utility bills and fuel/DG logs; automatic interval metering, SCADA/historian and BMS are future-proofed → the full-EnMS metering platform.** Same canonical contract (`meter_reading` → `energy_consumption`), two fidelities.

## 1. The metering hierarchy (the spine)

`meter` models the tree via `parent_meter_ref`: BOUNDARY (utility bill / main meter) → AREA → FEEDER → SUB → MACHINE, plus VIRTUAL (calculated). Each meter carries `carrier_ref`, `asset_node_ref` (where it sits), `seu_ref`, `multiplier` (CT/PT ratio), `meter_kind`, `capture_fidelity`, and (electricity) `has_demand_register`. Hero Steels' single-line diagram and utility headers (gas/air/water) define the initial tree.

## 2. Two capture fidelities, one contract

| | v1 — Manual bootstrap (today) | Future-proofed — Automatic (switch-on) |
|---|---|---|
| Electricity | manual reads + utility bill (kWh, max demand, PF, ₹) | interval meters: 15-min kWh/kVA/PF per feeder (Modbus/DNP3/IEC 61850/DLMS) → concentrator → OPC-UA |
| Thermal | fuel/DG logs, gas bill | flow meters on gas/steam/air/water headers + BMS |
| Resolution | monthly / per-read | sub-hourly, sub-metered |
| Basis | `BILLED` / `APPORTIONED` | `METERED` |

Both emit `meter_reading` → `energy_consumption`; **no downstream engine changes**, only fidelity and confidence rise. The automatic path is what turns the demand engine from retrospective (off the bill) to real-time (peak-shave before the peak sets) and unlocks true sub-metered M&V (IPMVP-B) — it is the layer that realises the meter-device-management, real-time-monitoring and demand-response rungs of the full-EnMS target.

## 3. v1 — bootstrap from M1 (cheapest first value)

M1's manual reads → consumption stream; the utility bill → tariff/demand/PF source + the regression-baseline history; fuel/DG logs → Scope 1 carrier. M7 converts to GJ + CO₂e, **apportions** boundary/area energy down to work-centre and SEU by run-time / throughput / connected load (`allocation_method`), computes EnPI/SEC per process & grade, builds the regression baseline from a year of bills, and lights up demand/PF/ToU off the bill — **no new hardware**. Apportioned numbers are tagged `APPORTIONED` (not `METERED`).

## 4. Meter device management & the data-quality gate

Per meter: `health` (OK / UNCALIBRATED / STALE_COMMS / FAULT), `last_calibrated_on`, `multiplier`, `comms_protocol`. The gate: an uncalibrated or stale-comms meter is flagged low-confidence and **excluded from a published EnPI baseline fit**; an apportioned consumption shows its method, never a hard sub-meter; the energy-balance gap (spec 02 §2) is the aggregate honesty check feeding the **Coverage/Fidelity** readiness gate. This is the energy analogue of M6's MSA gate / M5's reconciliation-gap discipline.

## 5. On-ramps & readiness

Four on-ramps → `readiness_snapshot`: (a) **M1 first-party** reads/bills/logs (v1, no hardware); (b) **ingest** existing EMS/utility-portal/historian via Manifold + energy sector template; (c) **automatic** interval meters/SCADA/BMS (edge collectors, switch-on); (d) **first-party** energy capture + portable-meter campaign where nothing exists. Gates: Required (carrier+output+meter present), **Coverage** (metered share vs apportioned), **Fidelity** (calibration/comms), **History** (interval days for prediction). UI shows honest confidence: "this furnace SEC is indicative (bill-apportioned, no sub-meter)".

## 6. Acceptance (this spec)

Manual reads + a bill produce balanced `energy_consumption` in GJ + CO₂e with correct basis/fidelity; the metering tree rolls child meters into parents without double counting; an uncalibrated meter is excluded from the baseline fit; the Coverage gate reports the metered share; switching a meter from MANUAL to AUTOMATIC raises fidelity with no schema change.

\newpage

# 04 · Carriers, SEU & Allocation Spec
**Build:** Phase M7-1/2 · deep-plan §6

> The carrier → SEU → allocation chain — M7's product. Getting the carrier model and the SEU register right is the difference between an actionable energy SoR and a single "the plant used X kWh".

## 1. The carrier model (all-utilities, multi-carrier)

`energy_carrier` seeds the full set, each with native unit, `gj_per_native_unit`, default emission scope, and `is_self_generated`:

| `carrier_kind` | Steel use | Native | Scope |
|---|---|---|---|
| ELECTRICITY_GRID | mill drives, utilities | kWh | Scope 2 (location + market) |
| ELECTRICITY_CAPTIVE | DG backup/peak | kWh+fuel | Scope 1 (fuel) |
| NATURAL_GAS / FUEL_OIL / LPG | **reheating furnace** | m³/L/kg | Scope 1 |
| STEAM | annealing/pickling | tonne/GJ | Scope 1 (fired) / 2 (purchased) |
| COMPRESSED_AIR | actuation, blow-off | Nm³ | via electricity |
| WATER | cooling, descaling | m³ | via electricity |
| SOLAR / RECOVERED_HEAT | self-gen / waste heat | kWh/GJ | zero / avoided |

## 2. The SEU register (ISO 50001 §6.3; DOE taxonomy)

`seu` holds the Significant Energy Uses — the systems carrying the bulk of consumption or improvement potential. `seu_class` uses the DOE energy-treasure-hunt taxonomy: PROCESS_HEATING, COMPRESSED_AIR, MOTOR_DRIVE, PUMPING, FAN, STEAM, HVAC, LIGHTING, PROCESS_COOLING, GENERAL_UNALLOCATED, OTHER. Each SEU carries `energy_share_pct` (the Pareto), `relevant_variables` (the normalisation set), `asset_node_ref` and `cost_centre_ref`, and links to its `enpi_definition`(s) + `energy_baseline`.

**Rules:** a handful of SEUs carry most energy (steel: **reheating furnace** + **mill drives** dominate; **compressed air** = classic hidden waste). The Pareto by energy share *is* the metering-and-action priority. Every SEU has ≥1 EnPI + relevant variables. Exactly one `GENERAL_UNALLOCATED` SEU exists; when it tops the Pareto or exceeds threshold, auto-prompt "sub-meter this load" (the coverage gap made actionable).

## 3. Allocation down the tree (push the boundary down to the coil)

Every `energy_consumption` carries `asset_node_ref`, `seu_ref`, the cost centre, the window, and — where fidelity & COIL_NO genealogy allow — `production_count_id` and `material_lot_ref`. This is what lets M7 state energy **per tonne / per coil / per grade / per state**. Where no per-coil sub-meter exists, M7 apportions the work-centre energy across the coils made in the window by `allocation_method` (RUNTIME / THROUGHPUT / CONNECTED_LOAD) and tags `APPORTIONED` — honest, useful, upgradeable to `METERED` when instrumented. Default `allocation_method` is an open decision (deep-plan §14).

## 4. The canonical mapping (makes energy add up)

Each carrier/SEU carries the GJ factor, the default emission factor + scope, the `cost_centre_ref`, the `seu_class`, and the asset node — so M7's energy splits **reconcile to M4's state time, M5's loss quantity and M6's defect** (same production context, one mapping) and carbon **reconciles to ISO 14404** plant intensity. Seeded by the sector template (Manifold), tunable per tenant.

## 5. Acceptance (this spec)

The seeded steel carrier set + SEU register loads; SEU energy shares sum across the metering tree without double counting; an SEU with no EnPI is rejected as incomplete; the GENERAL_UNALLOCATED bucket triggers the sub-meter prompt above threshold; a coil's energy is correctly apportioned across the window with the basis tagged.

\newpage

# 05 · Demand, Tariff, Carbon & Aggregation Spec
**Build:** Phase M7-2/3 · deep-plan §7

> M7's deepest differentiation over a flat "kWh dashboard": the demand/power-quality charges set by a handful of unmanaged moments, and the carbon nobody priced until asked.

## 1. The tariff model (the bill is not one number)

`tariff` + `tariff_period` decompose the bill so it can be predicted and optimised: **energy charge** (ToU peak/shoulder/off-peak rate per `tariff_period`), **demand charge** (`demand_charge_per_kva` × max kVA), **power-factor penalty** (`pf_penalty_per_kvarh` below `energy_config.pf_penalty_threshold`), **fixed/capacity**, **fuel/gas charge**, **carbon price** (`carbon_price_per_tonne`). Effective-dated (rate-as-of, D7).

## 2. Demand management (manage the moment, don't pay for it)

`demand_interval` tracks the rolling **maximum demand** over the `energy_config.demand_window` (15/30-min) against `tariff.contracted_demand_kva` and the historical monthly peak. `event_kind`: **PEAK_APPROACH** (raise with lead time to shed/shift), **PEAK_BREACH**, **PF_PENALTY**. The value is entirely *before* the peak sets the month's demand charge. `power_factor` watched against threshold → capacitor-correction opportunity (raise > 0.95). ToU surface exposed to M3 for energy-aware scheduling. In v1 these are **signals/decision support** off the bill & early meters; **automated demand response / load control** is the future-proofed rung on the real-time metering interface (spec 08).

## 3. Carbon accounting (two-scope, steel-literal)

`emission_entry` derives carbon from the same consumption, per the GHG Protocol:
- **Scope 1** — on-site combustion (furnace gas, DG fuel): GJ × `emission_factor` combustion factor.
- **Scope 2** — purchased electricity/steam, **both** `SCOPE_2_LOCATION` (grid average factor) **and** `SCOPE_2_MARKET` (contractual/PPA/REC, residual-mix remainder). The two disagree by exactly the clean-energy procurement — both shown.
- **ISO 14404 intensity** — tCO₂ per tonne on the standard import/export boundary (Part 2 EAF / Part 1 BF / Part 3 EAF+DRI). M7 produces the universal-calculation-sheet inputs from metered carriers.
- **Scope 3** = future-proofed hook (`ghg_scope` enum carries it).

## 4. Embodied-energy of loss/defect (the M7↔M5↔M6 seam)

Energy spent making material then scrapped/downgraded is wasted twice. `energy_waste_entry` (category EMBODIED_SCRAP) computes the kWh/GJ + kgCO₂e attributable (per-process SEC × the lost/defective quantity) to M5's yield loss (`m5_loss_ref`) and M6's defective units (`m6_defect_ref`). This is the **same** energy as the energy component of M5/M6's loss — counted **once** (§6, spec 06 §4), never re-priced.

## 5. Aggregation pipeline

Streaming path (where automatic metering exists): live load/demand tile + peak-approach/PF/baseline-excursion alerts (Flink → Redis). Scheduled rollups (Airflow): `energy_consumption` → `energy_balance`, `enpi_value` (EnPI + CUSUM + avoided), `emission_entry`, `energy_cost_entry`, `energy_waste_entry` → the `v_*` Serving views. Deterministic & replayable: a corrected reading or re-versioned factor re-derives affected consumption/EnPI/cost/CO₂ without manual patching (old baseline version preserved).

## 6. Acceptance (this spec)

A bill decomposes into the right tariff components; a simulated demand approaching the cap raises PEAK_APPROACH before breach; low PF flags the penalty + correction size; Scope 2 produces both location and market figures; ISO 14404 intensity reconciles to summed Scope 1+2 ÷ tonnes; embodied-energy of a scrap lot equals SEC × lost qty and ties to the M5 loss row without re-pricing.

\newpage

# 06 · KPIs, Analytics & Financial/Carbon Spec
**Build:** Phase M7-2/3 · deep-plan §9, §12

> M7's contribution to the shared KPI registry (doc 03), reconciled to ISO 22400 / ISO 50006 so no module disagrees, plus the dual-currency (₹ + kgCO₂e) financial story and the cross-module reconciliation tests.

## 1. KPI definitions (registry)

| KPI | Formula (SQL: SUM-then-divide) | Target / meaning |
|---|---|---|
| **SEC / EnPI** | Σenergy_gj ÷ Σoutput_t | ≤ benchmark GJ/t per process & grade |
| **Normalised EnPI** | actual ÷ baseline-expected | the real, volume-adjusted efficiency |
| **Energy performance improvement** | (baseline − actual)/baseline, normalised | the ISO 50001 number |
| **Avoided energy (M&V)** | Σ baseline-projected − Σ actual (IPMVP) | verified saving |
| **Absolute consumption** | Σ GJ / kWh per carrier×period | cash & carbon exposure |
| **Energy cost / tonne** | Σ energy ₹ ÷ Σ output_t | per-tonne energy cost |
| **CO₂ intensity** | Σ tCO₂e ÷ Σ output_t | Scope 1+2, ISO 14404 |
| **Max demand & load factor** | peak kVA; avg ÷ peak | demand exposure / peakiness |
| **Power factor** | kW ÷ kVA | ≥ 0.95 (avoid penalty) |
| **Energy balance gap** | Σ gap ÷ Σ boundary | metering coverage (data honesty) |
| **Avoidable waste** | Σ idle + leaks + demand + PF + off-baseline + embodied | ranked € + kgCO₂e |
| **Renewable / self-gen share** | Σ(solar+recovered) ÷ Σ total | decarbonisation |

## 2. The financial & carbon story (two axes)

Price each tariff component & avoidable-waste category in **₹** (rate-as-of, D7) **and** in **kgCO₂e**, and rank by both — because the cheapest and cleanest actions diverge (off-peak grid is cheap but maybe dirtier than midday solar; captive DG can be cheaper but pure Scope 1). `energy_waste_entry` categories: IDLE_STANDBY (tied to M4 idle), AIR_LEAK, DEMAND_PEAK, POWER_FACTOR, OFF_BASELINE (CUSUM), EMBODIED_SCRAP (M5/M6), ON_PEAK_SHIFTABLE. Each = a line with ₹, tCO₂ and an action owner. Turns "energy is just the price of steel" into a ranked, dual-currency, owner-assigned backlog.

## 3. Analytics surfaces

Sankey energy balance (carrier → SEU → process); EnPI/SEC trend vs baseline with CUSUM; demand curve vs cap + load duration; PF trend; carbon by scope (location vs market); waste Pareto by ₹ and by carbon; per-grade & per-coil SEC where genealogy allows.

## 4. Cross-module reconciliation (CI tests — the no-double-count proof)

1. **EnPI denominator == M4/M5/M6 tonnes**: Σ production on `energy_consumption.production_count_id` == the production number under OEE/yield/quality (one number).
2. **Idle-energy ↔ M4 state**: `energy_waste_entry(IDLE_STANDBY).state_interval_ref` references the **same** `canon.state_interval` M4 classified idle/down — same minutes, second cost.
3. **Embodied energy counted once**: Σ `energy_waste_entry` energy for loss/defect reasons == energy spent on the **same** `production_count`/`m5_loss_ref`/`m6_defect_ref` units; never a *separate* loss from M5's material loss.
4. **Energy balance closes**: purchased+generated == distributed+loss+gap within tolerance; gap = coverage, not waste.

## 5. Acceptance (this spec)

Each KPI computed via SUM-then-divide matches a hand-worked example; the four reconciliation tests pass on a back-test window; the waste register ranks identically whether sorted by ₹ or surfaces a different order by kgCO₂e (proving the dual-currency divergence); CO₂ intensity ties to ISO 14404 inputs.

\newpage

# 07 · APIs, Events & Integration Spec
**Build:** Phase M7-2 · deep-plan §12

> M7 publishes energy facts and reads everyone else's; it never writes another module's tables (golden rule). All cross-module access is via versioned Serving APIs / events, never direct `energy.*` queries.

## 1. Serving APIs (read; FastAPI, versioned `/v1`)

- `GET /energy/consumption?carrier&seu&node&from&to&grain` → normalised GJ + CO₂e + cost, with basis/fidelity.
- `GET /energy/enpi?enpi&grain&from&to` → actual / expected / variance / CUSUM / avoided.
- `GET /energy/balance?carrier&period` → purchased/distributed/loss/**gap%** (coverage honesty).
- `GET /energy/demand?node&from&to` → max-demand vs cap, PF, peak events; `GET /energy/tariff-surface` → ToU windows + rates (for M3).
- `GET /energy/carbon?scope&period` → Scope 1 / 2-location / 2-market + ISO 14404 intensity.
- `GET /energy/waste?category&grain` → ranked avoidable waste (₹ + kgCO₂e + owner).
- `GET /energy/readiness?seu` → Required/Coverage/Fidelity/History gates.

## 2. Published events (Kafka; for Monitoring/UIL/siblings)

`energy.consumption.recorded`, `energy.enpi.computed`, `energy.baseline.excursion` (CUSUM slope change), `energy.demand.peak_approach`, `energy.powerfactor.penalty`, `energy.balance.gap_exceeded`, `energy.carbon.computed`, `energy.waste.ranked`. Each carries the canonical anchors (`production_count_id`, `state_interval_ref`, asset node) so consumers join to the shared truth.

## 3. Sibling contracts (the boundaries — deep-plan §12)

| Boundary | M7 reads | M7 publishes | Shared artifact |
|---|---|---|---|
| **M4 (OEE)** | `StateInterval` (running/idle/down) | energy-by-state, idle-energy loss | one `StateInterval` (M4 classifies, M7 attributes energy) |
| **M5 (Yield)** | loss qty | embodied energy of loss | one `ProductionCount` loss (M5 material, M7 energy) |
| **M6 (Quality)** | good/defective split (`DefectRecord`) | embedded-energy of defective | one `DefectRecord` |
| **M3 (Planning)** | plan/route/sequence | ToU cost surface + demand headroom | M7 signal in, M3 schedules; M7 never writes ops.* |
| **M2 (Maint.)** | condition/failure | energy-signature degradation (rising SEC) | shared ML model surface |
| **M1** | manual reads/bills/fuel-logs, COIL_NO | the energy SoR | `MeterReading`, `EnergyConsumption` |
| **Manifold** | meter/SCADA/bill/historian connectors | data contract + energy sector template | sector template |
| **UIL / Monitoring / Financial** | KPI registry / live cache / CostRate-Tariff | EnPI/consumption/demand/carbon/cost | shared registry |

## 4. Manifold integration

Connectors: CSV/Excel bill & meter exports (D4 first), generic DB, then meter/SCADA-historian/utility-portal (switch-on). Carrier/meter/tariff field-mapping through the **review queue** (D5, never blind). The seeded **energy sector template** carries the steel carrier set, SEU register, SEC EnPIs + relevant variables, tariff shape, emission factors and the ISO 14404 boundary.

## 5. Acceptance (this spec)

Every API is versioned and returns the canonical anchors; no consumer queries `energy.*` directly; events fire with the production/state anchor; M3 can read the ToU surface and M4/M5/M6 can read energy-by-state / embodied energy through the projection; a re-versioned factor re-emits derived events deterministically.

\newpage

# 08 · Prediction / Future-scope Interfaces Spec
**Build:** Future (gated) · deep-plan §8

> Forecasting load, predicting the demand peak, and prescribing the cheapest-and-cleanest choice is the operating-model's post-6-month → prescriptive horizon, **gated on accumulated interval history**. v1 is descriptive/diagnostic; this spec keeps prediction a switch-on, not a rebuild. `energy.energy_prediction` is the dark stub (`is_active=FALSE`).

## 1. Future capabilities (the ladder)

| Capability | v1 | Future |
|---|---|---|
| Consumption | meter, normalise, EnPI, balance | **load/consumption forecasting** per SEU×grade from plan & weather |
| Demand | track vs cap (off bill/early meters) | **demand-peak forecast + automated demand response / load control** (needs real-time metering) |
| Baseline variance | CUSUM excess signal | **excess-consumption anomaly ML** → auto-attribute to SEU |
| Condition | energy-signature trend | **energy-signature condition monitoring** (rising SEC/falling efficiency → fouled furnace / worn compressor / degrading motor; shared with M2) |
| Tariff/sourcing | ToU surface + DG-vs-grid view | **prescriptive tariff & load optimisation** — optimal schedule, DG-vs-grid dispatch, battery, contract right-sizing |
| Design | SEC by grade | **design-to-energy** — lowest-energy route×grade (shared with M5 design-to-yield) |

## 2. What v1 must get right (so it's a switch-on)

(a) **time-stamped consumption joined to production, state, grade, weather, tariff** from day one (features + objective); (b) **meter calibration/comms-health** on every stream (real features, not meter noise — the spec 03 gate); (c) **interval data where it exists** (DR & anomaly need sub-hourly — exactly why automatic metering is future-proofed now); (d) a **prediction-readiness (History) gate** (`readiness_snapshot.gate=HISTORY`, `history_days`) reporting per SEU×route when enough interval history exists. No prediction *promises* in v1 — only *readiness*.

## 3. One shared ML model surface (M2/M4/M5/M6/M7)

The **energy-signature** that predicts a compressor failure (M7) *is* the condition signal M2 reads; a grade transition that predicts a yield-loss window (M5) and a defect-risk window (M6) is the same window that predicts an energy-intensity spike (M7) — **one** model surface, not five. M7's prediction shares the platform ML-readiness substrate; automated demand-response & tariff-optimisation land on the §5 real-time metering interface.

## 4. Interfaces present now (dark)

`energy_prediction` (model_kind: LOAD_FORECAST / DEMAND_PEAK / EXCESS_ANOMALY / ENERGY_SIGNATURE / TARIFF_OPT; `is_active=FALSE`); the streaming meter interface (spec 03); the History readiness gate. No build until the gate passes and the shared model surface is online.

## 5. Acceptance (this spec)

The stub exists and is dark; the History gate reports interval-days per SEU×route; turning on a model requires no schema change to the v1 consumption/baseline/demand tables; an energy-signature feature is derivable from existing `meter_reading` + `enpi_value` without re-modelling.

\newpage

# 09 · Security, RBAC, NFRs & Acceptance Spec
**Build:** All phases · deep-plan §13

## 1. Roles (extend M1 Operator/Supervisor/Plant-Head/Admin)

| Role | Can |
|---|---|
| **Operator / Utilities operator** | record manual reads & fuel logs; see live load/demand tile + peak-approach alert for their area |
| **Shift Supervisor** | shift energy & intensity, demand & PF status; validate reads; act on load-shed/shift prompt |
| **Energy Manager / ISO 50001 lead** | configure carriers, meters, SEUs, EnPI defs & targets, baselines, normalisation drivers; run M&V; own the energy review & management-review pack |
| **Energy Engineer** | analyse SEU consumption, build regression baselines, size corrections (capacitors, VFDs, leak fixes) |
| **Sustainability / Carbon analyst** | Scope 1/2, location vs market, ISO 14404 intensity; emission-factor config |
| **Cost / Finance analyst** | read priced energy waste (read-only) |
| **Plant Manager** | energy trends, ₹ + CO₂, demand & baseline status (read-only) |
| **Admin** | masters, meter/connector integration, tariff & emission-factor config, energy policy |

## 2. Governance & audit

Energy configuration (baselines, normalisation drivers, tariff structure, emission factors, carrier factors) directly moves the EnPI/cost/carbon numbers → **every change is audit-logged** (`policy_change_log`) with effective dating (ISO 50001 traceability); an EnPI/CO₂ trend is never silently broken by a re-baseline or factor revision (old baseline version preserved); a saving is always attributable to a baseline version. The energy SoR (consumption, bills, baselines, M&V) is **append-only / audit-trailed** for ISO 50001 / ISO 14404 / GHG-assurance retention. Row-level scoping by site/area (M1). First-party/edge capture is **offline-tolerant** (queue local reads, sync on reconnect).

## 3. NFRs

Deterministic & replayable recompute from canonical readings (corrected reading / re-versioned factor re-derives consumption/EnPI/cost/CO₂ without manual patching). Live tile latency = D2 near-real-time (where automatic metering exists); scheduled baseline/EnPI/carbon rollups via Airflow. Tenant isolation = D8 logical default. No new infra beyond inherited stack (spec 00 §5). Multi-currency aware (`currency` columns); multi-carrier unit-safe (units in column names).

## 4. Acceptance tests (module-level gates)

1. **Balance closes** — purchased+generated == distributed+loss+gap within `balance_gap_tolerance`; gap named, not waste.
2. **EnPI normalised** — actual vs baseline-expected reproduces a known month within ε; SUM-then-divide rollups.
3. **Reconciliation (no double-count)** — EnPI denominator == M4/M5/M6 tonnes; idle-energy ↔ same M4 `StateInterval`; embodied-energy == M5 loss energy == M6 defect energy, counted once.
4. **Demand** — peak-approach fires before breach; PF penalty + correction sized.
5. **Carbon** — Scope 2 both location & market; ISO 14404 intensity ties to Σ Scope 1+2 ÷ tonnes.
6. **Fidelity honesty** — uncalibrated meter excluded from baseline fit; apportioned ≠ metered confidence.
7. **MVP migration gate** — existing kWh/energy-cost/intensity == canonical on the back-test window; existing dashboards keep running while repointed onto `energy.*`.
8. **Audit** — every config/baseline/factor change logged with effective dating; recompute reproducible.

\newpage

# 10 · Glossary
**M7 · Energy Intelligence** — terms, standards & acronyms

## Energy management & performance
- **EnMS** — Energy Management System (ISO 50001): the energy review → SEU → baseline → EnPI → objectives → action plan PDCA loop.
- **Energy review** — the ISO 50001 analysis of energy use & consumption that identifies the SEUs.
- **SEU — Significant Energy Use** — a use/system accounting for substantial consumption or holding large improvement potential (steel: reheating furnace, mill drives, compressed air). DOE system taxonomy: process heating, compressed air, motor/drive, pumping, fans, steam, HVAC, lighting, process cooling.
- **EnB — Energy Baseline** — the reference (≥12 months) energy-performance model every improvement is measured against (ISO 50006). May be a simple ratio or a regression (intercept β₀ = standing/no-load load).
- **EnPI — Energy Performance Indicator** — a metric of energy performance; here a ratio (SEC) or a regression-normalised model (ISO 50006).
- **SEC — Specific Energy Consumption** — energy per unit output (GJ/t, kWh/t) — the headline intensity.
- **Normalisation / relevant variables** — adjusting energy for the drivers that legitimately move it (production volume, weather HDD/CDD, product/grade mix, charge temperature) so efficiency is separated from volume.
- **Absolute vs Normalised lens** — M7's dual lenses: absolute = kWh/GJ/₹/kgCO₂e drawn & spent; normalised = EnPI/SEC efficiency. Equal weight (cf. M5 mass+count, M6 attribute+variable).

## Measurement & verification
- **M&V** — Measurement & Verification of energy savings (ISO 50015).
- **IPMVP** — International Performance Measurement & Verification Protocol; Options **A** (retrofit isolation, key-parameter), **B** (retrofit isolation, all-parameter), **C** (whole-facility regression), **D** (calibrated simulation).
- **Avoided energy** — baseline-projected energy at current conditions − actual; the *real* saving (not naïve before/after).
- **CUSUM** — cumulative sum of (actual − expected) energy; a slope change pinpoints when a process drifted off baseline. M7's analogue of the SPC control chart.
- **Energy balance** — purchased + generated = distributed + losses + unmetered gap (per carrier). The gap = metering-coverage honesty, never waste. M7's analogue of M5's mass balance.

## Carriers, metering & electricity
- **Carrier** — an energy type (electricity, gas, steam, compressed air, water…) converted to common-unit **GJ** + **kgCO₂e**.
- **Metering hierarchy** — boundary → area → feeder → sub → machine meters; `parent_meter_ref`.
- **Basis / Fidelity** — how a consumption number was derived: METERED / BILLED / CALCULATED / APPORTIONED / ESTIMATED × MANUAL / BILL / INGESTED / AUTOMATIC.
- **Protocols** — Modbus, DNP3, IEC 61850, DLMS/COSEM (meters) → data concentrator → **OPC-UA** → historian (the automatic on-ramp).
- **Maximum demand** — highest average power over a rolling 15/30-min window; sets the **demand charge** (often ~40% of the electricity bill).
- **Peak shaving** — shedding/shifting load to keep below the demand cap.
- **Time-of-use (ToU)** — energy priced by peak/shoulder/off-peak windows.
- **Power factor (PF)** — kW÷kVA; low PF (lagging) draws a **kVA/kVAr penalty**; corrected with capacitors (target ≥ 0.95).
- **Demand response (DR)** — automated load control to a demand/price signal (future-scope).

## Carbon
- **GHG Protocol** — corporate carbon-accounting standard. **Scope 1** = on-site combustion (furnace gas, DG fuel); **Scope 2** = purchased electricity/steam, computed **location-based** (grid average) **and** **market-based** (contractual/PPA/REC + residual mix); **Scope 3** = value-chain (future).
- **Emission factor** — kgCO₂e per GJ/kWh; effective-dated (rate-as-of).
- **ISO 14404** — calculation method for CO₂-emission intensity of steel (Part 1 blast furnace / Part 2 EAF / Part 3 EAF+DRI / Part 4 guidance + universal calculation sheet); tCO₂ per tonne on an import/export boundary.

## Platform & cross-module
- **Embodied / embedded energy** — energy already spent making material that became scrap (M5) or defective/downgraded (M6); wasted twice; counted **once** with M5/M6's loss.
- **Energy-by-state** — energy split by M4 `StateInterval` (running/idle/down); idle/standby = avoidable energy loss tied to the same downtime minutes M4 owns.
- **No-double-count anchor** — `energy_consumption.production_count_id` = the one shared `ProductionCount`; EnPI denominator == the tonnes under OEE/yield/quality.
- **Standards reconciled** — ISO 50001 (EnMS), ISO 50006 (EnB/EnPI), ISO 50015/IPMVP (M&V), GHG Protocol + ISO 14064 (carbon), ISO 14404 (steel CO₂), ISO 22400-2 (energy KPI), DOE Better Plants (SEU taxonomy).

\newpage

