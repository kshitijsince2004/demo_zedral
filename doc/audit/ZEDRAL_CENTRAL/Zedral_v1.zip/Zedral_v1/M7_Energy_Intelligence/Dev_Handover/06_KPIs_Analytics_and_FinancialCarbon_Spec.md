# 06 · KPIs, Analytics & Financial/Carbon Spec
**Build:** Phase M7-2/3 · deep-plan §9, §12

> M7's contribution to the shared KPI registry (doc 03), reconciled to ISO 22400 / ISO 50006 so no module disagrees, plus the dual-currency (₹ + kgCO₂e) financial story and the cross-module reconciliation tests.

## 1. KPI definitions (registry)

| KPI | Formula (SQL: SUM-then-divide) | Target / meaning |
|---|---|---|
| **SEC / EnPI** | Σenergy_gj ÷ Σoutput_t | ≤ benchmark GJ/t per process & grade |
| **Normalised EnPI** | actual ÷ baseline-expected | the real, volume-adjusted efficiency |
| **Energy performance improvement** | (baseline − actual)/baseline, normalised | the ISO 50001 number |
| **Avoided energy (M&V)** | Σ baseline-projected − Σ actual (IPMVP) | verified saving |
| **Absolute consumption** | Σ GJ / kWh per carrier×period | cash & carbon exposure |
| **Energy cost / tonne** | Σ energy ₹ ÷ Σ output_t | per-tonne energy cost |
| **CO₂ intensity** | Σ tCO₂e ÷ Σ output_t | Scope 1+2, ISO 14404 |
| **Max demand & load factor** | peak kVA; avg ÷ peak | demand exposure / peakiness |
| **Power factor** | kW ÷ kVA | ≥ 0.95 (avoid penalty) |
| **Energy balance gap** | Σ gap ÷ Σ boundary | metering coverage (data honesty) |
| **Avoidable waste** | Σ idle + leaks + demand + PF + off-baseline + embodied | ranked € + kgCO₂e |
| **Renewable / self-gen share** | Σ(solar+recovered) ÷ Σ total | decarbonisation |

## 2. The financial & carbon story (two axes)

Price each tariff component & avoidable-waste category in **₹** (rate-as-of, D7) **and** in **kgCO₂e**, and rank by both — because the cheapest and cleanest actions diverge (off-peak grid is cheap but maybe dirtier than midday solar; captive DG can be cheaper but pure Scope 1). `energy_waste_entry` categories: IDLE_STANDBY (tied to M4 idle), AIR_LEAK, DEMAND_PEAK, POWER_FACTOR, OFF_BASELINE (CUSUM), EMBODIED_SCRAP (M5/M6), ON_PEAK_SHIFTABLE. Each = a line with ₹, tCO₂ and an action owner. Turns "energy is just the price of steel" into a ranked, dual-currency, owner-assigned backlog.

## 3. Analytics surfaces

Sankey energy balance (carrier → SEU → process); EnPI/SEC trend vs baseline with CUSUM; demand curve vs cap + load duration; PF trend; carbon by scope (location vs market); waste Pareto by ₹ and by carbon; per-grade & per-coil SEC where genealogy allows.

## 4. Cross-module reconciliation (CI tests — the no-double-count proof)

1. **EnPI denominator == M4/M5/M6 tonnes**: Σ production on `energy_consumption.production_count_id` == the production number under OEE/yield/quality (one number).
2. **Idle-energy ↔ M4 state**: `energy_waste_entry(IDLE_STANDBY).state_interval_ref` references the **same** `canon.state_interval` M4 classified idle/down — same minutes, second cost.
3. **Embodied energy counted once**: Σ `energy_waste_entry` energy for loss/defect reasons == energy spent on the **same** `production_count`/`m5_loss_ref`/`m6_defect_ref` units; never a *separate* loss from M5's material loss.
4. **Energy balance closes**: purchased+generated == distributed+loss+gap within tolerance; gap = coverage, not waste.

## 5. Acceptance (this spec)

Each KPI computed via SUM-then-divide matches a hand-worked example; the four reconciliation tests pass on a back-test window; the waste register ranks identically whether sorted by ₹ or surfaces a different order by kgCO₂e (proving the dual-currency divergence); CO₂ intensity ties to ISO 14404 inputs.
