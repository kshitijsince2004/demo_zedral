# 04 · Carriers, SEU & Allocation Spec
**Build:** Phase M7-1/2 · deep-plan §6

> The carrier → SEU → allocation chain — M7's product. Getting the carrier model and the SEU register right is the difference between an actionable energy SoR and a single "the plant used X kWh".

## 1. The carrier model (all-utilities, multi-carrier)

`energy_carrier` seeds the full set, each with native unit, `gj_per_native_unit`, default emission scope, and `is_self_generated`:

| `carrier_kind` | Steel use | Native | Scope |
|---|---|---|---|
| ELECTRICITY_GRID | mill drives, utilities | kWh | Scope 2 (location + market) |
| ELECTRICITY_CAPTIVE | DG backup/peak | kWh+fuel | Scope 1 (fuel) |
| NATURAL_GAS / FUEL_OIL / LPG | **reheating furnace** | m³/L/kg | Scope 1 |
| STEAM | annealing/pickling | tonne/GJ | Scope 1 (fired) / 2 (purchased) |
| COMPRESSED_AIR | actuation, blow-off | Nm³ | via electricity |
| WATER | cooling, descaling | m³ | via electricity |
| SOLAR / RECOVERED_HEAT | self-gen / waste heat | kWh/GJ | zero / avoided |

## 2. The SEU register (ISO 50001 §6.3; DOE taxonomy)

`seu` holds the Significant Energy Uses — the systems carrying the bulk of consumption or improvement potential. `seu_class` uses the DOE energy-treasure-hunt taxonomy: PROCESS_HEATING, COMPRESSED_AIR, MOTOR_DRIVE, PUMPING, FAN, STEAM, HVAC, LIGHTING, PROCESS_COOLING, GENERAL_UNALLOCATED, OTHER. Each SEU carries `energy_share_pct` (the Pareto), `relevant_variables` (the normalisation set), `asset_node_ref` and `cost_centre_ref`, and links to its `enpi_definition`(s) + `energy_baseline`.

**Rules:** a handful of SEUs carry most energy (steel: **reheating furnace** + **mill drives** dominate; **compressed air** = classic hidden waste). The Pareto by energy share *is* the metering-and-action priority. Every SEU has ≥1 EnPI + relevant variables. Exactly one `GENERAL_UNALLOCATED` SEU exists; when it tops the Pareto or exceeds threshold, auto-prompt "sub-meter this load" (the coverage gap made actionable).

## 3. Allocation down the tree (push the boundary down to the coil)

Every `energy_consumption` carries `asset_node_ref`, `seu_ref`, the cost centre, the window, and — where fidelity & COIL_NO genealogy allow — `production_count_id` and `material_lot_ref`. This is what lets M7 state energy **per tonne / per coil / per grade / per state**. Where no per-coil sub-meter exists, M7 apportions the work-centre energy across the coils made in the window by `allocation_method` (RUNTIME / THROUGHPUT / CONNECTED_LOAD) and tags `APPORTIONED` — honest, useful, upgradeable to `METERED` when instrumented. Default `allocation_method` is an open decision (deep-plan §14).

## 4. The canonical mapping (makes energy add up)

Each carrier/SEU carries the GJ factor, the default emission factor + scope, the `cost_centre_ref`, the `seu_class`, and the asset node — so M7's energy splits **reconcile to M4's state time, M5's loss quantity and M6's defect** (same production context, one mapping) and carbon **reconciles to ISO 14404** plant intensity. Seeded by the sector template (Manifold), tunable per tenant.

## 5. Acceptance (this spec)

The seeded steel carrier set + SEU register loads; SEU energy shares sum across the metering tree without double counting; an SEU with no EnPI is rejected as incomplete; the GENERAL_UNALLOCATED bucket triggers the sub-meter prompt above threshold; a coil's energy is correctly apportioned across the window with the basis tagged.
