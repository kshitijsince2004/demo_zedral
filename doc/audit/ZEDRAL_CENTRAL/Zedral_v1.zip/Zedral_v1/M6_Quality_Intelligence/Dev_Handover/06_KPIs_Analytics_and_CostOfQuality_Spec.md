# 06 · KPIs, Analytics & Cost of Quality Spec
**Phase M6-2/3 · deep-plan §9**

## 1. KPI registry contributions (ISO 22400-reconciled)

| KPI | Formula | Source |
|---|---|---|
| First-Pass Yield | good first-time ÷ started | `canon.production_count` (== M5 FPY) |
| **Quality Ratio** | good ÷ produced | **== M4 Quality factor** (invariant) |
| Defect rate / DPU | defects ÷ units | `v_quality_rollup` |
| DPMO / ppm | (defects ÷ (units×opportunities))×10⁶ | `v_quality_rollup` |
| Cp/Cpk/Pp/Ppk | per characteristic | `control_chart` (target ≥1.33; critical ≥1.67) |
| % time in control | in-control subgroups ÷ total | `spc_signal` density |
| Disposition mix | scrap/rework/downgrade/use-as-is share | `v_quality_rollup` |
| Hold ageing | open holds by age | `quality_hold` |
| CAPA cycle time / recurrence | days to verified close; % recurring | `capa` |
| Right-First-Time | no defect & no rework ÷ total | derived |
| Cost of Quality | P + A + IF + EF | `v_coq_rollup` |

## 2. Cost of Quality — the PAF model (`coq_entry`, deep-plan §9)

Four buckets (`coq_category`): **Prevention** (FMEA, control plans, capable processes), **Appraisal** (inspection effort), **Internal Failure** (scrap/rework/downgrade — **priced via M5's loss bridge**, `is_from_m5_loss = TRUE`), **External Failure** (returns/claims/warranty — `defect_source='CUSTOMER'`). Priced with `canon.cost_rate` (D7, rate-as-of-detection). Exposes the **1-10-100** asymmetry (prevent ≪ internal fix ≪ external escape) and the **~15–20% of revenue** total. Output: "₹X/year COPQ, of which ₹Y removed by ₹Z prevention", Pareto & CAPA backlog ranked **by money**.

## 3. Reconciliation (the two CI tests, the discipline of the platform)

| Test | Assertion |
|---|---|
| **M6 ↔ M4** | M6 defect-driven Quality-loss == M4 Quality-factor loss (same good/total, same ISO 22400 mapping) |
| **M6 ↔ M5** | Σ M6 disposition material (scrap+rework+downgrade) for defect-driven records == Σ M5 priced loss for those DefectRecords; **the internal-failure € in COQ *is* M5's priced loss, counted once** |

Both run in CI (spec 09). They are the reason the platform can end the "quality says 3% defects, production says 96% good, finance says 4% scrap" argument: one defect truth, dispositioned once, priced once.

## 4. Steel reporting extras

Defect Pareto, control charts, COQ report, and the **certificate of analysis / mill test certificate** per shipped coil (characteristics + measured values + disposition + defect map), generated from `inspection`/`measurement`/`defect_record` joined on COIL_NO.
