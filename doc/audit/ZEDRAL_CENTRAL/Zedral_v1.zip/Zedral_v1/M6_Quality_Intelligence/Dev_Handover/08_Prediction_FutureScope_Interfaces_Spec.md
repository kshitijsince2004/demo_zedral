# 08 · Prediction / Future-scope Interfaces Spec
**Status: FUTURE SCOPE (architected now, build deferred) · deep-plan §8**

## 1. What is deferred

| Capability | v1 (now) | Future |
|---|---|---|
| Defect level | classify, disposition, Pareto, price | **defect-risk prediction** per route×grade from process params & incoming certs |
| SPC | charts, rules, capability (reactive signal) | **SPC-excursion forecasting** — predict the breach *before* it happens (drift extrapolation) |
| Surface inspection | manual / logged defects | **automated visual-defect classification (CV)** — encoder-located map, type/severity, auto-disposition |
| Incoming material | defect-by-supplier-lot (diagnostic) | **incoming-quality prediction** from lot certificates (shared with M5 incoming-yield) |
| Decision support | SPC + Pareto + alerts | **prescriptive** ("adjust setpoint to avoid drift"); auto-CAPA suggestion from similar past cases |

## 2. The stub (`quality_prediction`)

Present, `is_active = FALSE` (dark) until the History gate passes. Holds predicted defect ppm per characteristic×work-unit×grade + model version + horizon. No write path in v1.

## 3. Why v1 makes this a switch-on, not a rebuild

(a) **labelled measurements & defect records with verified root causes** from day one (the training labels — why CAPA D8 verification matters beyond compliance); (b) **MSA-qualified measurement streams** (real features, not gage noise); (c) defect records **joined to genealogy, grade, process params, supplier lot and cost** (features + objective); (d) the **History readiness gate** per characteristic×route.

## 4. One shared model surface (not four)

M6's defect/SPC prediction shares the platform's **one** ML-readiness substrate and model surface with **M2** (PdM), **M4** (loss) and **M5** (yield): a grade transition that predicts a yield-loss window (M5) *and* a defect-risk window (M6) is **one** model surface; the *Machine* leg of a fishbone that predicts a roll-mark defect (M6) is the same condition signal that predicts the roll failure (M2). The CV/vision path lands on the spec 03 automatic-capture interface. Build only when the shared History gate is green for the target characteristic×route (D9).
