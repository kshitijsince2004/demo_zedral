# Zedral — M6 · Quality Intelligence

### Deep Plan · v1 · Module Layer (Specify the standard → measure conformance → detect the drift → contain & disposition → resolve the root cause → price the cost of quality → act)

> **What M6 is.** M6 is Zedral's **Quality Intelligence** module — the platform's *conformance brain and quality system-of-record (SoR)*. Where M4 answers "how *effectively* did the equipment run?" and M5 answers "of every tonne we put in, how much became sellable product?", M6 answers the question that protects the brand and the customer: "**is it good, why is it bad, what do we do with it, and how do we stop it happening again?**" M6 takes the production counts, measurements and defect events standing on the **Canonical Event Spine** (`01_DataLake_and_Canonical_Model_DeepPlan.md`), holds quality in **two lenses at once** — the *variable* lens (measured characteristics → **SPC** control charts → process **capability** Cp/Cpk/Pp/Ppk, which catches the drift *before* a defect occurs) and the *attribute* lens (a unit is non-conforming → a governed **defect taxonomy** → **disposition**: scrap / rework / downgrade / use-as-is / return-to-supplier, governed by **NCR → MRB → CAPA**). It puts **quality holds** on suspect material, runs **root-cause** (5-Why / fishbone / 8D) and **corrective/preventive action (CAPA)** to closure, attaches a **currency value** to the whole picture through the **Cost of Quality** (Prevention + Appraisal + Internal-failure + External-failure), and serves a live "what is drifting right now, what is held, and what is it costing" view. M6 is the module that turns "defect count" — a number quality logs and production ignores — into a **governed, capability-monitored, dispositioned, root-caused, priced cost-of-poor-quality** an executive can act on.
>
> **Why it's high-value.** Quality failure is the most *asymmetric* cost in manufacturing: a defect costs roughly **1 to prevent, 10 to find and fix internally, 100 if it reaches the customer** (the 1-10-100 rule), and total Cost of Quality in a typical plant runs **15–20% of revenue** — most of it the *invisible* Cost of Poor Quality (scrap, rework, sorting, concessions, claims, recalls) that never appears as a line item. Quality's chronic disease is that it is run *reactively and in silos*: inspection finds defects after the money is spent, SPC charts (if they exist) live in a spreadsheet nobody watches, dispositions happen on paper, root-cause "investigations" repeat the same five fixes, and nobody can price what poor quality actually costs. M6's value is to make quality **preventive, governed, traceable and priced** — to catch the process drifting *before* it makes scrap (SPC), to govern every disposition on the *one* canonical defect record the whole platform shares, to drive every nonconformance to a *verified* root-cause closure, and to put a **€ figure on poor quality** so the prevention investment that removes it can be justified. It is also one of the **densest pull-through modules for connected data** (specs, measurements, defects, dispositions, lab/gauge/vision feeds) — the platform's core commercial wedge: the more quality sources are connected, the earlier the drift is caught.
>
> **What M6 is NOT.** It is **not a data-capture product** competing with M1 — it *consumes* the canonical `ProductionCount`, measurements and defect events that M1 (and future inline-gauge/lab/vision capture) produce, and adds the SPC, taxonomy, disposition, CAPA and Cost-of-Quality intelligence on top. It is **not the material-accounting engine** — M6 shares the *one* `DefectRecord` / `ProductionCount` with **M5**, but M5 owns *how much* material was lost and *what it cost* (material accounting & economics) while M6 owns *why it's bad and what we do about it* (the defect taxonomy, disposition, holds, SPC, root cause — the quality SoR). It is **not the OEE engine** — M4 computes the OEE **Quality factor** (Good ÷ Total at a work-unit, the time-effectiveness lens) and M6's defect-driven quality loss reconciles to it by construction. And it is **not the planning system** — M3 owns the plan; M6 *feeds* it the **quality holds** that say which material may not ship or be planned. M6 is a **conformance-and-intelligence layer over a shared truth**, never a parallel truth.
>
> **Standards anchors.** Quality KPI definitions (First-Pass Yield, Scrap/Rework/Quality ratio, Fall-off ratio) from **ISO 22400-2**, reconciled to the platform's existing registry so M6, M5 and M4 speak one number; the **ISO 9001** QMS backbone (control of nonconforming output cl. 8.7; corrective action & continual improvement cl. 10.2; control of monitoring & measuring resources cl. 7.1.5); the **IATF 16949 + AIAG core tools** — **APQP**, **PPAP**, **FMEA** (PFMEA → the **Control Plan**, M6's specify layer), **MSA** (Gage R&R — the data SPC depends on must be trustworthy), and **SPC**; **statistical process control** — variable charts (X̄-R, X̄-s, I-MR) and attribute charts (p, np, c, u), **Western Electric / Nelson** run rules, and process-capability indices **Cp/Cpk/Pp/Ppk**; **ISO 2859-1** AQL acceptance sampling by attributes (inspection levels; critical/major/minor defect classification); the **8D / CAPA** corrective-action discipline (Ford TOPS D0–D8; 5-Why; Ishikawa fishbone; effectiveness verification); and the **Cost of Quality / COPQ** PAF model (Prevention, Appraisal, Internal Failure, External Failure). Steel-specific anchors: surface/dimensional/mechanical characteristic and defect catalogs, **grade-downgrade** disposition (prime → second), and the **certificate of analysis / mill test certificate** per coil. Links in §15.

---

## 0. How M6 relates to the rest of the platform

M6 is an **intelligence contributor, a synthesiser, *and* the quality system-of-record** — it reads the canonical count/measurement/defect stream through the Serving zone, runs the SPC, taxonomy, disposition, CAPA and Cost-of-Quality engines, and writes its derived and transactional quality facts (control charts, signals, defect records, dispositions, holds, CAPAs, COQ) back so every other layer can reuse them. Unlike M4/M5 (which are almost pure thin-write calc layers), M6 *owns* genuinely new transactional data — the conformance record — but it still anchors every row to the *one* shared `ProductionCount` so quality, yield and OEE never disagree.

| Platform piece (doc) | What M6 consumes from it | What M6 gives back |
|---|---|---|
| **Data Lake · Canonical Model** (01) | `ProductionCount` (good/scrap/rework/total + weight), `DefectCode`/`DefectRecord` scaffolding, `Material`/`Grade`, material-lot genealogy (COIL_NO), `Shift/Calendar`, Asset hierarchy, `LossCategory`/`ReasonCode` reference | New quality entities (Characteristic, SpecLimit, InspectionPlan, Inspection, Measurement, ControlChart, SpcSignal, DefectRecord, QualityHold, Nonconformance/MRB, CAPA, CoQ); **brings to life** the `DefectCode`/`DefectRecord` spine the canonical model catalogued for quality |
| **Manifold** (02) | Connector to an existing QMS/LIMS/lab/gauge source; field-mapping of measurements, specs and defect reasons; the defect-reason→category→disposition mapping; sector templates; readiness/unlock | The M6 data contract; a seeded **quality sector template** (steel surface/dimensional/mechanical characteristics, spec limits, control plan, defect catalog, sampling plan) |
| **M1 · Shopfloor Digitization** (M1 blueprint) | First-party **inline checks** (go/no-go, gauge readings), operator **defect logging**, lab/QC results entered, the slit/surface defect capture M1 already does, `shift_log` time spine — the **v1 bootstrap source** | Conformance & SPC per process/coil/grade/shift back into M1's reporting; the held-material list that stops bad coils moving |
| **M5 · Yield Intelligence** | the **priced material/yield loss** of each disposition (scrap/rework/downgrade) — *how much* a defect cost | the `DefectRecord` + disposition (*why* a unit is bad and *what was decided*) so M5 attributes and prices the right loss; the defect Pareto M5 ranks by € |
| **M4 · OEE & Downtime** | the OEE **Quality factor** + quality-loss minutes context (L5 defect / L6 startup) | the **defect taxonomy, disposition and SPC** behind the Quality factor (M6's defect-driven quality loss reconciles to M4's Quality factor) |
| **M3 · Shopfloor Planning & Management** | the plan/route/grade mix; which lots are running | **Quality holds** (`QUALITY_HOLD`) — which coils/lots may not ship or be planned — for shift-handover carryover and MRP netting |
| **M2 · Maintenance Intelligence** | the failure/condition that caused a defect (worn roll → roll mark) | the **defect that a failure produced** — equipment-attributable quality loss, defect→work-order link |
| **M7 · Energy Intelligence** | — | the **good vs defective** split so M7 attributes embedded-energy waste to scrap |
| **Unified Intelligence Layer** (03) | KPI registry, cross-module synthesis | FPY/Quality-ratio, defect ppm/DPMO, Cpk, COQ, hold/CAPA status into the shared KPI registry |
| **Operational Monitoring** (03) | live count/measurement cache off the streaming path | live **SPC tile**, out-of-control & defect-rate alerts, open-hold and overdue-CAPA boards |
| **Financial Impact Layer** (07 spec) | `CostRate` (scrap/rework/inspection/concession/claim) "rate-as-of" (D7); M5's priced internal-failure loss | the priced **Cost of Quality** — Prevention + Appraisal + Internal-failure + External-failure, ranked, with the prevention ROI |
| **Reporting Layer** (05) | Same canonical KPI numbers | quality report, defect Pareto, control charts, COQ report, **certificate of analysis / mill test certificate** per coil |

**The golden rule (inherited):** consumers never write M6's tables and M6 never writes another module's — everything moves through the canonical model and versioned Serving APIs. A produced quantity is recorded **once** as a canonical `ProductionCount`, and a bad unit is recorded **once** as a `DefectRecord` (M6-owned, registered on the Event Spine); **M4 reads it** as the OEE Quality factor, **M5 reads it** as priced material loss, **M6 reads it** as the conformance/disposition SoR. One count truth, one defect truth — never double-counted (§12).

---

## 1. Responsibilities & principles

M6 owns nine responsibilities: **(1)** maintain the **quality reference & policy data** (the characteristic & specification catalog with versioned limits, the control plan, the inspection/sampling plan, the governed defect taxonomy, disposition rules, SPC rule-sets and capability targets, the Cost-of-Quality category map); **(2)** **capture/ingest conformance** — inspection results, variable measurements and defect occurrences — capture-agnostic across M1 manual, ingested QMS/LIMS, and future inline-gauge/lab/vision; **(3)** **run SPC** — build control charts per characteristic×work-unit, apply Western Electric/Nelson rules, compute process capability Cp/Cpk/Pp/Ppk, and raise an out-of-control **signal before a defect occurs**; **(4)** **classify the defect** against the governed taxonomy (category → type → root-detail, with criticality); **(5)** **contain & disposition** — place a **quality hold**, run the **MRB/NCR** decision, and record the disposition (scrap / rework / downgrade / use-as-is / return-to-supplier); **(6)** **resolve the root cause** — drive **CAPA / 8D** (5-Why, fishbone) to a *verified* closure and feed the lesson back to the FMEA/control plan; **(7)** **price the cost of quality** through Financial Impact — Prevention, Appraisal, Internal-failure, External-failure — and rank quality projects by money; **(8)** surface a **live SPC / hold / CAPA board & alerts**; **(9)** stand **prediction-ready** (defect-risk, SPC-excursion and automated visual-defect classification) without a data re-model.

Principles:

1. **Prevention over detection — catch the drift, not just the defect.** Quality's highest leverage is *upstream of the defect*. M6 is built so the **variable lens (SPC + capability)** is first-class, not an afterthought: a measured characteristic trending toward a limit raises a signal and a containment *before* a single non-conforming unit is made. Inspection that only finds defects after the fact is the expensive path (the 1-10-100 rule); M6 exists to move spend from appraisal/failure to prevention.
2. **Two lenses by design — attribute *and* variable, at parity.** Quality data is fundamentally two types and each is blind where the other sees. The **attribute / discrete** lens (a unit is non-conforming → defect → disposition, count/occurrence based, NCR/MRB/CAPA) catches the reject that a measurement in tolerance would miss; the **variable / measured** lens (a characteristic value → SPC → Cpk) catches the *drift toward* a defect that a pass/fail check declares "still good." M6 carries **both** — neither is a second-class citizen — exactly as M5 carries mass and count at parity.
3. **One defect truth, governed and dispositioned once.** Quality's other chronic disease is that "defects" are counted differently by inspection, production and finance, and dispositions happen on paper nobody can audit. M6 records each non-conformance **once** as the canonical `DefectRecord`, classifies it against a **governed taxonomy**, and drives **one** disposition through MRB — so M4's Quality factor, M5's priced loss and M6's defect Pareto all reconcile to the same event. The disposition is the platform's single answer to "what did we do with the bad material?"
4. **Separate special cause from common cause.** SPC's foundational discipline is sacred. A point outside the control limits or matching a run rule is a **special (assignable) cause** — investigate and act; variation *within* limits is **common cause** — do not tamper (over-adjusting a stable process makes it worse). M6 surfaces special-cause signals explicitly and refuses to let common-cause noise trigger an investigation, so the floor never chases a "problem" that is really normal variation — the quality analogue of M5 refusing to let a metrology gap masquerade as yield loss.
5. **Trust the measurement before you trust the chart (MSA).** An SPC chart or a capability index is only as honest as the **measurement system** under it. No characteristic is put under SPC or capability without an **MSA / Gage R&R** status flag; a high-variation gage is surfaced as a data-quality deviation, not a process discovery. Capability (Cpk) is reported with the gage status beside it, so a falsely-precise number is never published.
6. **Every defect has a disposition, a cost *and* a root cause owner.** No `DefectRecord` is recorded without the hooks to **disposition** it (and, in steel, to **downgrade** the grade rather than only scrap/rework), to **price** it through Cost of Quality (internal vs external failure), and — when it recurs or crosses a threshold — to **own** it through CAPA to a verified closure. A defect that is dispositioned but never root-caused is a defect that will return.
7. **Capture-agnostic, governance-faithful.** M6 does not care *how* a measurement or defect arrived — operator inline check (M1), a lab result, an inline thickness/flatness gauge, a surface-vision system, or an ingested QMS/LIMS record. It treats every source through the same canonical contract (Measurement + DefectRecord) and governs identically. v1 **bootstraps from M1's inline checks, operator defect logging and entered lab/QC results** (already live at Hero Steels) and is **architected for automatic gauge/lab/vision capture** as the high-fidelity path (§5).
8. **Sector-neutral core, sector-specific skin.** The characteristic/spec/inspection/SPC/defect/disposition/CAPA/COQ model is generic; a **sector template** instantiates it concretely (Hero Steels surface/dimensional/mechanical catalog, grade-downgrade disposition, certificate of analysis in §10) and reuses across clients via Manifold. The same engine serves a steel surface-defect world and a discrete machined-part world by switching the characteristic set and the chart types, not the code.
9. **Prediction by design, not by rebuild.** v1 is descriptive/diagnostic (what is drifting, what is bad, what we did, what it cost). The SPC + measurement + defect + disposition + cost substrate *is* the training data for later defect-risk prediction, SPC-excursion forecasting and automated visual-defect classification; we future-proof now and gate the ML build on accumulated quality history (§8), sharing the *one* platform model surface with M2 (PdM), M4 (loss) and M5 (yield).

---

## 2. The quality conceptual frame (the scope map)

Everything M6 does sits on one closed loop — the **quality / conformance lifecycle** — viewed through **two lenses** (Principle 2). The loop *is* M6's scope map.

**The quality loop (the spine of conformance).** Every characteristic and every lot moves through six stages; the loop closes when the lesson feeds back into the standard:

```mermaid
flowchart LR
  SPEC["1 · SPECIFY<br/>characteristic · spec limits · control plan · inspection/sampling plan"]
  MEAS["2 · MEASURE / INSPECT<br/>measurements (variable) + checks/defects (attribute) — capture-agnostic"]
  DET["3 · DETECT<br/>SPC rules + capability (variable) · defect + Pareto (attribute) → conformance event"]
  CONT["4 · CONTAIN & DISPOSITION<br/>quality hold · NCR · MRB → scrap/rework/downgrade/use-as-is/RTV"]
  RES["5 · RESOLVE<br/>root cause (5-Why/fishbone/8D) → CAPA → verify effectiveness"]
  COST["6 · COST & LEARN<br/>Cost of Quality (P·A·IF·EF) → quality projects → feedback to FMEA/control plan"]
  SPEC --> MEAS --> DET --> CONT --> RES --> COST
  COST -. "lesson learned" .-> SPEC
  DET -. "in spec, stable" .-> MEAS
  classDef spec fill:#ede9fe,stroke:#7c3aed;
  classDef det fill:#dbeafe,stroke:#2563eb;
  classDef cont fill:#fee2e2,stroke:#dc2626;
  classDef cost fill:#dcfce7,stroke:#16a34a;
  class SPEC spec; class DET det; class CONT,RES cont; class COST cost;
```

**The two lenses (equal-weight, per scoping).**

| Lens | What it is | Native to | Catches | Misses alone |
|---|---|---|---|---|
| **Variable / measured** | a measured characteristic value → SPC control chart → capability Cp/Cpk/Pp/Ppk | continuous / process / dimensional & mechanical | the **drift toward** a defect *before* it occurs; a slowly-decentring process | a discrete reject that is in-tolerance-but-wrong (wrong grade, surface flaw) |
| **Attribute / discrete** | a unit is conforming / non-conforming → defect → disposition (count/occurrence) | discrete / surface / pass-fail | the **reject event**, the defect Pareto, the disposition decision | the process quietly drifting inside the tolerance band |

M6 carries both because each is blind where the other sees. The **lens** (`VARIABLE` / `ATTRIBUTE`) is per-characteristic configuration; a characteristic can be both (a thickness is a variable measurement *and* an out-of-tolerance generates a defect).

**The conformance → disposition → cost chain (the why and the so-what).** Once a conformance event is raised, it is contained, dispositioned, root-caused and priced. This chain *is* the M6 product:

```mermaid
flowchart TD
  EV["Conformance event (SPC signal OR inspection fail OR defect logged)"] --> HOLD["Quality hold (quarantine suspect lot)"]
  HOLD --> NCR["Nonconformance (NCR) · severity · scope"]
  NCR --> MRB["Material Review Board decision"]
  MRB --> D1["Scrap"]
  MRB --> D2["Rework / re-process"]
  MRB --> D3["Downgrade (prime → second grade)"]
  MRB --> D4["Use-as-is / concession"]
  MRB --> D5["Return to supplier (incoming)"]
  D1 & D2 & D3 & D4 & D5 --> CAPA["CAPA / 8D — root cause → corrective + preventive → verify"]
  D1 & D2 & D3 --> COST["Cost of Quality: internal-failure € (via M5 priced loss)"]
  D5 --> EXT["External/supplier failure €"]
  CAPA -. "feedback" .-> FMEA["FMEA / control plan update"]
  classDef ev fill:#dbeafe,stroke:#2563eb;
  classDef cont fill:#fee2e2,stroke:#dc2626;
  classDef cost fill:#dcfce7,stroke:#16a34a;
  class EV ev; class HOLD,NCR,MRB,D1,D2,D3,D4,D5 cont; class COST,EXT cost;
```

**Mapping defects to OEE Quality, yield loss and the Six Big Losses (the M6↔M4↔M5 seam).** Every defect/disposition carries the canonical mapping so the three modules close to the same numbers:

| Conformance outcome | ISO 22400 quantity | Six Big Loss | M5 recoverability | Cost-of-Quality class | Canonical carrier |
|---|---|---|---|---|---|
| In-spec, stable (SPC in control) | Good (GQ) | — | — | (prevention/appraisal) | `ProductionCount.good` |
| Off-gauge / off-profile (variable fail) | Scrap or Rework | L5 defect | salvage / recoverable | internal failure | `ProductionCount.scrap/rework` + `DefectRecord` |
| Surface defect (attribute) | Scrap or Downgrade | L5 defect | salvage / downgrade | internal failure | `DefectRecord` + disposition |
| Transition / startup off-spec | Scrap | L6 startup/yield | salvage / downgrade | internal failure | startup window + `DefectRecord` |
| Reworked & passed | Rework (RQ) | L5 defect | recoverable | internal failure (rework) | `ProductionCount.rework` |
| Customer return / claim | (post-ship) | — | — | **external failure** | `DefectRecord` source=CUSTOMER |
| Incoming/supplier reject | (incoming) | — | — | supplier/external failure | `DefectRecord` source=SUPPLIER |

**What's in v1 vs future.** v1 owns the full dual-lens conformance: characteristic/spec/control-plan/inspection reference, SPC + capability, the governed defect taxonomy, quality holds, NCR + MRB disposition (incl. grade-downgrade), CAPA/8D root-cause linkage, and Cost-of-Quality pricing — descriptive/diagnostic. The **yellow** capability — *predicting* defect risk and SPC excursions, automated visual-defect classification, and prescriptive "adjust the setpoint to avoid the drift" — is architected now and built later (§8), gated on accumulated quality history. **Future-proofed interfaces only** (not v1 build): supplier-quality scorecards, audit management, document/training control — the data hooks (defect source=SUPPLIER, the policy/audit log) are present so these light up without a re-model.

---

## 3. M6 reference architecture

```mermaid
flowchart LR
  subgraph SRC["Measurement / defect / disposition sources — capture-agnostic"]
    A1["M1 first-party: inline checks, operator defect logging, entered lab/QC, slit/surface defects (v1 bootstrap)"]
    A2["Inline gauge / lab / surface-vision (future-proofed, §5)"]
    A3["Existing QMS / LIMS / lab record via Manifold (ingest on-ramp)"]
    A4["M5 priced loss · M4 quality-loss split · M3 plan/route · M2 failure link"]
  end
  subgraph M6["M6 · Quality engines"]
    E1["Quality Reference & Policy (characteristic · spec limits · control plan · inspection/sampling · defect taxonomy · disposition rules · SPC rules · COQ map)"]
    E2["Conformance Capture & Validation (inspection · measurement · attribute check; MSA-aware)"]
    E3["SPC & Capability engine (charts · WE/Nelson rules · Cp/Cpk/Pp/Ppk · special-cause signal)"]
    E4["Defect, Hold & Disposition engine (classify · hold · NCR · MRB → disposition)"]
    E5["CAPA / Root-cause engine (5-Why/fishbone/8D · effectiveness verify · FMEA feedback)"]
    E6["Quality KPI & Cost-of-Quality engine (FPY · ppm · Cpk · P·A·IF·EF, priced)"]
    E7["Defect/SPC PREDICTION · visual-defect classification — FUTURE SCOPE"]
  end
  CANON["Data Lake · Canonical Zone (Event Spine + new M6 quality entities)"]
  SERVE["Serving zone / KPI mart / live cache"]
  subgraph CONS["Consumers"]
    UIL["Unified Intelligence (KPI registry)"]
    MON["Operational Monitoring (live SPC / hold / CAPA board / alerts)"]
    FIN["Financial Impact (priced Cost of Quality)"]
    REP["Reporting (quality report, Pareto, control charts, COA/MTC)"]
    M5c["M5 (DefectRecord + disposition → priced loss)"]
    M4c["M4 (Quality factor reconciliation)"]
    M32["M3 quality holds / M2 defect→failure link"]
  end
  A1 --> E2
  A2 -. future .-> E2
  A3 --> E2
  A4 --> E4
  A4 --> E6
  E1 --> E2 --> E3
  E2 --> E4
  E3 --> E4 --> E5
  E1 --> E3
  E3 & E4 & E5 --> E6
  E7 -. future .-> E3
  E2 & E3 & E4 & E5 & E6 --> CANON
  CANON --> SERVE --> UIL & MON & FIN & REP & M5c & M4c & M32
```

**Reading it:** measurements/defects/inspections arrive from M1 (v1), from inline gauge/lab/vision (future-proofed), or from an ingested QMS/LIMS record; the **Conformance Capture** engine validates them (MSA-aware); the **SPC & Capability** engine charts the variables, applies the run rules, computes Cpk, and raises a special-cause signal; the **Defect, Hold & Disposition** engine classifies the non-conformance, quarantines the lot, and drives the MRB decision; the **CAPA engine** owns root cause to a verified closure and feeds the FMEA/control plan; the **KPI/Cost-of-Quality engine** prices the whole picture; everything is written to the canonical zone and served to the intelligence/monitoring/financial/reporting layers and back to the sibling modules. Engine **E7 (prediction/vision)** is wired in but dark until the quality history and the model build land.

---

## 4. The conformance, SPC & capability engine

M6's calculation core is deliberately exact and **standards-literal**, so a capability index is defensible to a customer auditor and a Quality factor reconciles to M4 to the unit.

**The SPC chart families (variable + attribute — the two lenses in code).** M6 selects the chart by data type and subgroup, exactly as SPC practice prescribes:

| Chart | Data | When | Plots |
|---|---|---|---|
| **X̄-R** | variable | subgroup size 2–~9 | subgroup mean & range |
| **X̄-s** | variable | subgroup size ≥ ~10 | subgroup mean & std-dev |
| **I-MR** | variable | individual values (n=1, e.g. one coil) | individual & moving range |
| **p / np** | attribute | proportion / number defective | fraction or count non-conforming |
| **c / u** | attribute | defects per unit / per area | count or rate of defects |

**The run-rule sets (special-cause detection).** A point is "out of control" when it breaks a control limit or matches a pattern. M6 ships the **Western Electric** and **Nelson** rule sets and a tenant-tunable subset (over-sensitive rule sets cause false alarms; under-sensitive ones miss drift):

- **Beyond 3σ** — one point outside the upper/lower control limit (the classic special cause).
- **Zone rules** — 2-of-3 beyond 2σ, 4-of-5 beyond 1σ (a shift the limit alone misses).
- **Run rules** — 8 (or 9) consecutive points on one side of the centre line (a sustained shift).
- **Trend** — 6–7 points steadily increasing or decreasing (drift — tool wear, temperature creep).
- **Stratification / mixture** — 15 points hugging the centre, or 8 avoiding it (a sampling or two-stream problem — also an MSA red flag).

**Process capability (the can-this-process-meet-spec question).** Once stable, M6 computes capability against the spec limits:

| Index | Formula | Meaning |
|---|---|---|
| **Cp** | (USL − LSL) ÷ 6σ_within | potential capability — spread only (process must be *in control* first) |
| **Cpk** | min[(USL − μ)÷3σ_within, (μ − LSL)÷3σ_within] | actual capability — spread *and* centring (the one that matters) |
| **Pp / Ppk** | same, using σ_overall (long-run) | performance — includes between-subgroup variation |

The **Cpk vs Ppk gap** is itself a diagnostic: a large gap exposes between-subgroup variation (shift change, coil-to-coil, multi-stream) that a single chart hides — M6 surfaces it. Capability is reported **only for an in-control process** and **only with an MSA status** (Principle 4 & 5), so the number is never falsely precise.

**Conformance & yield reconciliation (ISO 22400-literal, agrees with M4/M5 by construction).** M6's attribute lens computes the same quantities M4 and M5 read, from the *one* count:

| Metric | Formula | Plain meaning |
|---|---|---|
| **First-Pass Yield (FPY)** | Good first-time ÷ Started | right-first-time (reconciles to M5 FPY) |
| **Quality Ratio (ISO 22400)** | Good ÷ Produced | = M4's Quality factor by construction |
| **Scrap / Rework Ratio** | Scrap or Rework ÷ Produced | shared with M5's loss accounting |
| **Defect rate / DPU** | defects ÷ units | attribute-lens defect intensity |
| **DPMO / ppm** | (defects ÷ (units × opportunities)) × 10⁶ | defects per million opportunities (Six-Sigma framing) |
| **Defect Pareto** | defect count / cost by type × step × grade | where the quality loss actually is |

**Sampling (how much to inspect).** Inspection is governed by a **sampling plan** per characteristic: **100%** (critical / safety / vision-automated), **AQL by ISO 2859-1** (lot-by-lot attribute sampling, with critical/major/minor classes and inspection levels), **fixed-n** (e.g. one coupon per coil for mechanicals), or **continuous** (SPC subgroup at a frequency). The plan is part of the control plan and is itself versioned reference data.

```mermaid
flowchart LR
  MEAS["Measurement (variable) / check (attribute)"] --> VAL["MSA-aware validation"]
  VAL --> SUB["Subgroup / individual"]
  SUB --> CHART["Control chart (X̄-R / I-MR / p / c ...)"]
  CHART --> RULE["WE / Nelson rules"]
  RULE -- "special cause" --> SIG["SPC signal → containment"]
  CHART --> CAP["Capability Cp/Cpk/Pp/Ppk (in-control + MSA only)"]
  VAL -- "attribute fail / out of spec" --> DEF["DefectRecord → disposition (§ next)"]
  SIG & CAP & DEF --> MART["Quality interval store (counts · ppm · Cpk · signals)"]
```

---

## 5. Quality data capture & the on-ramp decision

Quality intelligence is only as good as the measurements and defect records underneath it. This is where M6's capture decision lives: **v1 bootstraps from M1's manual inline checks, operator defect logging and entered lab/QC results; automatic inline gauges, lab/spectrometer feeds and surface-vision are fully architected as the high-fidelity future path.** Same canonical contract, two fidelities.

**The control plan is the spine.** Conformance is meaningless without knowing *what to measure, where, how often, and against what limit*. M6 requires a **control plan** — characteristic × work-unit/operation × spec limit × method × sample × reaction — which is the IATF-16949 bridge from the PFMEA to the floor, and Hero Steels' process route already implies exactly this: thickness/width/flatness at the mill, surface at inspection, mechanicals at the lab, per grade. That plan tells M6 which measurements feed which control chart, which checks raise which defect, and what the reaction is when a limit breaks.

**Two capture fidelities, one contract.**

```mermaid
flowchart TD
  subgraph V1["v1 — Manual bootstrap (live at Hero Steels today)"]
    M1C["M1 inline checks (go/no-go, gauge reading) + operator defect logging"]
    M1L["M1-entered lab / QC results (mechanicals, composition) + slit/surface defects"]
  end
  subgraph FUT["Future-proofed — Automatic capture (switch-on)"]
    GAU["Inline gauge: thickness / width / flatness / profile → variable stream"]
    LAB["Lab / spectrometer / tensile auto-feed → mechanical & chemical characteristics"]
    VIS["Surface-vision: encoder-located defect map → attribute defects + area"]
  end
  CONTRACT["Canonical contract: Measurement (characteristic + value + in-spec) + DefectRecord (code + severity + location + disposition) + production_count / lot link"]
  M1C --> CONTRACT
  M1L --> CONTRACT
  GAU --> CONTRACT
  LAB --> CONTRACT
  VIS --> CONTRACT
  CONTRACT --> RES["SPC & Disposition engines (identical downstream)"]
```

**v1 — bootstrap from M1 (cheapest first value).** M1 already captures, at Hero Steels, inline operator checks, defect logging, entered lab/QC results, and the slit/surface defect data quality needs — exactly the conformance inputs M6 needs. M6 maps M1's defect categories onto the canonical defect taxonomy (category → type → criticality → default disposition), treats the entered gauge readings as the variable measurement stream feeding SPC, and computes the full dual-lens conformance per process/coil/grade immediately, with **no new hardware**. This is the on-ramp that makes M6 deliver value on day one for any M1 client.

**Future-proofed — automatic gauge/lab/vision (the fidelity upgrade).** Manual capture has known blind spots: **gauge readings are sampled and transcribed, surface defects are eyeballed and under-logged, and lab results lag the coil** — so SPC is coarse and some defects hide. M6 is architected so an **inline thickness/flatness gauge** can stream the variable measurement continuously (true SPC, not spot checks), a **lab/spectrometer auto-feed** can attach mechanicals and composition to the coil, and a **surface-vision system** can turn defect area into encoder-located attribute defects on the coil map — emitting the *same* canonical `Measurement`/`DefectRecord` rows at higher fidelity. None of M6's downstream engines change; only the fidelity (and the readiness/MSA confidence) rises. The sensor/vision mappings and collector interfaces are specified now (Dev_Handover spec 03/07) and built when a client instruments the line — exactly the M4/M5 "future-proof, switch-on" pattern, and the path on which CV-based automated defect classification (§8) later lands.

**Why MSA matters (the data-honesty seam).** Before a measurement is trusted for SPC or capability, the **measurement system** under it must be trusted (Principle 5). M6 carries an **MSA / Gage R&R status** per characteristic and gates: a characteristic whose gage is unqualified is charted with a *low-confidence* flag and excluded from a published Cpk, and a chart that shows stratification/mixture (rule 15-hugging-centre) is flagged as a possible measurement problem, not a process triumph. This is the quality analogue of M5's reconciliation-gap discipline — it is what lets a customer auditor trust the capability number.

---

## 6. Defect taxonomy, disposition & the quality system-of-record

The conformance → disposition chain is M6's product (Principle 3 & 6). Its leaves are **defect codes**, and getting the taxonomy and the disposition governance right is the difference between an actionable quality SoR and a "miscellaneous reject" black hole.

**The steel defect anatomy (grounded in mill practice).** Cold-rolled quality groups into **surface** (roll marks, scale pits, scratches, slivers, inclusions, oil/stain, coil breaks), **dimensional/profile** (off-gauge thickness, off-width, crown/wedge, flatness/shape, edge wave/camber), **mechanical/metallurgical** (hardness, tensile/yield, elongation off-spec, grain), **edge** (edge crack, burr, slit-edge), and **chemical** (composition off-aim). M6 seeds these as the steel sector template's Layer-1/2 defect tree, each with a criticality and a default disposition.

**Three-layer defect hierarchy (operator-first, mirrors M4's downtime tree and M5's loss tree).**

```mermaid
flowchart TD
  L1["Layer 1 · Defect category (fast tap; 6–8 max)<br/>Surface · Dimensional · Mechanical · Edge · Chemical · Other"]
  L2["Layer 2 · Defect type (filtered by parent, 15–25)<br/>e.g. Surface → roll mark / scale pit / scratch / sliver / coil break"]
  L3["Layer 3 · Root-cause detail (optional small, required critical)<br/>e.g. roll mark → worn work-roll / debris / setup (links to M2)"]
  L1 --> L2 --> L3
  L1 --> MIN["Minimum-viable data captured even if only Layer 1 is entered"]
  L3 --> MAP["Each leaf → DefectCode + criticality (critical/major/minor) + default disposition + LossCategory + OEE component (canonical mapping)"]
```

Design rules M6 enforces, drawn from practice and shared with M4/M5's reason-tree discipline:

- **6–8 top categories, never more.** An operator (or a vision system) selects a primary category in seconds; that alone is minimum-viable data.
- **No more than 15–20 types at any one level**, filtered by parent.
- **Criticality on every code** — critical / major / minor (ISO 2859 classes) drives the sampling plan, the default disposition, and whether Layer-3 root detail is mandatory.
- **Capture the symptom, not the diagnosis** at log time — *the diagnosis is CAPA's job* (§5 below feeds the root-cause engine). This raises the chance the right code is picked.
- **Govern the "Other / unclassified" bucket.** Exactly one "Other" exists; when it climbs into the defect-Pareto top-3 or above ~10%, M6 auto-prompts "split your Other bucket."

**The disposition model (the quality SoR's decisive act).** Every non-conformance gets exactly one **disposition**, decided by the **Material Review Board (MRB)** for anything above a severity/authority threshold and by rule for routine cases:

| Disposition | Meaning | Material outcome | Cost-of-Quality |
|---|---|---|---|
| **Scrap** | unrecoverable, discard/recycle | `ProductionCount.scrap` (M5 prices pure/salvage) | internal failure |
| **Rework / re-process** | recoverable by added processing | `ProductionCount.rework` (M5 prices net of recovery) | internal failure (rework) |
| **Downgrade** | reclassify prime → second/commercial grade | grade change + price delta | internal failure (margin loss) |
| **Use-as-is / concession** | accept against a documented deviation | good, with concession record | (appraisal / deviation) |
| **Return to supplier (RTV)** | incoming non-conformance sent back | supplier debit | supplier/external failure |

**Grade-downgrade is first-class (the steel reality).** In metals, the dominant disposition is *not* scrap or rework — it is **downgrade**: a coil with a surface flaw is reclassified from prime to second/commercial and sold at a lower price. M6 models downgrade explicitly (from-grade → to-grade, price delta), so the disposition is captured truthfully and M5 prices the **margin loss** rather than mis-recording it as scrap. This is the disposition that flat "defect count" systems miss entirely.

**Quality holds (containment).** Suspect material is placed on a **quality hold** (quarantine) — a coil/lot/batch is blocked from shipping or planning until released or dispositioned. The hold is the artifact M3 reads for `QUALITY_HOLD` shift-handover carryover and MRP netting (M6 publishes the hold/release event; it never writes M3's tables). Hold ageing (how long material sits held) is a monitored KPI.

**The canonical mapping (the bit that makes quality add up).** Every defect code carries, in canonical reference data: a `loss_category_ref`, an **ISO 22400 quantity class** (SQ / RQ via the disposition), a **criticality**, a **default disposition**, and an `oee_component` (Quality, L5/L6). This is what lets M6's defect-driven quality loss **reconcile to M4's Quality factor** (same units, one mapping) and lets **M5 attribute and price** the exact disposition. The mapping is seeded by the sector template and tunable per tenant.

---

## 7. NCR, MRB, root cause & CAPA (the close-the-loop intelligence)

The two things plants under-manage most in quality are **driving a nonconformance to a *verified* root-cause closure** (not just dispositioning the material) and **stopping it recurring**. M6 makes both first-class — this section is M6's deepest differentiation over a flat "defect log."

**Nonconformance (NCR) & the Material Review Board (MRB).** A `DefectRecord` (or a cluster of them, or an SPC special-cause signal) opens a **Nonconformance (NCR)** — the *case* that groups the affected material, records severity and scope, drives the **MRB disposition** (§6), and triggers a CAPA when warranted. The NCR is the governed, audit-trailed record ISO 9001 cl. 8.7 requires: what was wrong, what was decided, who authorised it, and what happened to the material.

**Root cause & CAPA / 8D (the recurrence-killer).** A disposition fixes *this* material; a **CAPA** fixes the *process* so it does not recur. M6 drives CAPA through the **8D** discipline that dominates automotive and metals supply chains, with the structured analytical tools attached:

```mermaid
flowchart LR
  TRIG["Trigger: NCR · recurring defect · SPC signal · customer complaint · audit finding"] --> D2["D2 Define problem (is/is-not)"]
  D2 --> D3["D3 Containment (protect customer now)"]
  D3 --> D4["D4 Root cause — 5-Why + fishbone (Ishikawa 6M)"]
  D4 --> D5["D5 Choose corrective action"]
  D5 --> D6["D6 Implement & validate"]
  D6 --> D7["D7 Prevent recurrence (preventive action) → FMEA/control-plan update"]
  D7 --> D8["D8 Verify effectiveness → close"]
  D8 -. "recurs?" .-> TRIG
  classDef t fill:#dbeafe,stroke:#2563eb;
  classDef rc fill:#fef9c3,stroke:#ca8a04;
  classDef cl fill:#dcfce7,stroke:#16a34a;
  class TRIG t; class D4,D5,D6 rc; class D8 cl;
```

- **5-Why** drills the most likely causal branch; **fishbone (Ishikawa)** maps the landscape across the 6M (Machine, Method, Material, Man, Measurement, Environment) — and the *Machine* and *Measurement* legs link directly to **M2** (equipment condition) and **M6's own MSA** (gage). M6 stores the chosen method and the verified root cause, not a free-text guess.
- **Corrective vs preventive** are distinct (the C and the P of CAPA): corrective removes *this* root cause; preventive removes the *class* of cause elsewhere. Both are tracked to an owner and a due date.
- **Effectiveness verification is mandatory** (D8): a CAPA is not closed until the metric (defect rate, Cpk, ppm) demonstrably improves over a verification window. **CAPA recurrence rate** and **cycle time** are monitored KPIs — a high recurrence rate means root causes are being guessed, not found.
- **Feedback to the standard (the loop closes):** a verified CAPA updates the **FMEA** (raise the detection/occurrence rating) and the **control plan** (add the control), so the lesson is institutionalised — the link back from stage 6 to stage 1 of the quality loop (§2).

**Defect intelligence by every dimension.** From the governed records M6 serves defect rate, ppm, Cpk and disposition mix sliced by **defect type, process step, grade, route, work-unit, shift, crew, and — for incoming — supplier lot** (the supplier-defect spread that pre-stages the future supplier scorecard). The defect Pareto by **count *and* by cost** (they rank differently — a rare downgrade of premium grade can cost more than a common minor scratch) is the target list, ranked the way the executive needs: by money.

**The supplier & external-failure hooks (future-proofed, captured now).** A `DefectRecord` carries a **source** (`IN_PROCESS` / `FINAL` / `INCOMING` / `SUPPLIER` / `CUSTOMER`), so incoming rejects, customer returns and warranty claims ride the same governed record and the same Cost-of-Quality engine. v1 captures and prices them; the full **supplier scorecard** and **complaint-management workflow** are the future-scope build that lights up from this data without a re-model (§1, §8).

---

## 8. Predictive / ML — FUTURE SCOPE (architected now)

Predicting and *designing out* defects is the operating-model's post-6-month → prescriptive horizon, **gated on accumulated quality history**. v1 is descriptive/diagnostic; we design so prediction is a switch-on.

| Capability | v1 | Future scope |
|---|---|---|
| Defect level | classify, disposition, Pareto, price (descriptive) | **defect-risk prediction** per route×grade from process parameters & incoming certs |
| SPC | charts, rules, capability (reactive signal) | **SPC-excursion forecasting** — predict the out-of-control *before* it breaches (drift extrapolation) |
| Surface inspection | manual / logged defects | **automated visual-defect classification (CV)** — encoder-located defect map, type & severity, auto-disposition |
| Incoming material | defect-by-supplier-lot (diagnostic) | **incoming-quality prediction** from lot certificates (composition/thickness) → sort/contain before processing (shared with M5 incoming-yield) |
| Decision support | SPC + Pareto + alerts (diagnostic) | **prescriptive**: "this setpoint will drift you out — adjust now"; auto-CAPA suggestion from similar past cases (2–3 yr) |

**What v1 must get right so this is a switch-on, not a rebuild:** (a) **labelled measurements & defect records with verified root causes** from day one (the training labels — this is why CAPA effectiveness-verification matters beyond compliance); (b) **MSA-qualified measurement streams** (so the variable features are real, not gage noise); (c) **defect records joined to genealogy, grade, process parameters, supplier lot and cost** (the features and the objective); (d) a **prediction-readiness (History) gate** in the readiness model (§11) reporting per characteristic×route when there is enough labelled history to train. No prediction *promises* in v1 — only prediction *readiness*. M6's defect/SPC prediction shares the platform's **one** ML-readiness substrate and model surface with **M2** (PdM), **M4** (loss) and **M5** (yield): a grade transition that predicts a yield-loss window (M5) *and* a defect-risk window (M6) is **one** model surface, not two — and the *Machine* leg of a fishbone that predicts a roll-mark defect (M6) is the same condition signal that predicts the roll failure (M2). The CV/vision path lands on the §5 automatic-capture interface.

---

## 9. Quality KPIs, analytics & Cost of Quality

M6's contribution to the **shared KPI registry** (doc 03), all reconciled to the platform's **ISO 22400** definitions so no module disagrees.

| KPI | Formula | Meaning / target |
|---|---|---|
| **First-Pass Yield (FPY)** | Good first-time ÷ Started | right-first-time (reconciles to M5 FPY) |
| **Quality Ratio (ISO 22400)** | Good ÷ Produced | = M4's Quality factor by construction |
| **Defect rate / DPU** | defects ÷ units | attribute-lens defect intensity |
| **DPMO / ppm** | (defects ÷ (units × opportunities)) × 10⁶ | Six-Sigma defect density |
| **Process capability** | Cp / Cpk / Pp / Ppk per characteristic | can the process meet spec? (target Cpk ≥ 1.33; critical ≥ 1.67) |
| **% time in control** | in-control subgroups ÷ total | SPC stability (special-cause frequency) |
| **Disposition mix** | scrap / rework / downgrade / use-as-is share | where non-conformance goes (downgrade is the steel signal) |
| **Hold ageing** | open holds by age | containment latency (material stuck in quarantine) |
| **CAPA cycle time & recurrence rate** | days to verified close; % recurring | are root causes found or guessed? |
| **Right-First-Time (RFT)** | units with no defect & no rework ÷ total | the customer-felt quality number |
| **Cost of Quality (COQ)** | Prevention + Appraisal + Internal-failure + External-failure | the € quality is really worth (target: shift to prevention) |

**The financial story (per Principle 6 — the Cost of Quality / PAF model).** Quality is where the platform's Financial Impact Layer reframes the entire conversation, because the economics are stark and counter-intuitive. Total Cost of Quality runs **~15–20% of revenue** in a typical plant, and the four buckets trade against each other: spending on **Prevention** (FMEA, control plans, capable processes) and the right amount of **Appraisal** (inspection) *reduces* the far larger **Internal Failure** (scrap, rework, downgrade — priced via M5's loss bridge) and **External Failure** (returns, claims, warranty, recall — the catastrophic tail) costs. M6 prices each bucket using `CostRate` (D7, rate-as-of-event) and M5's priced internal-failure loss, and exposes the **1-10-100** asymmetry: a defect caught by an SPC signal (prevention) costs a fraction of the same defect caught at final inspection (appraisal/internal failure), which costs a fraction of the coil that ships and comes back (external failure). This turns "defects are 3%" into "₹X/year Cost of Poor Quality, of which ₹Y would be removed by ₹Z of prevention" — and ranks the defect Pareto and the CAPA backlog **by money**, the version that changes the budget. M6's COQ and M5's loss bridge are the *same* internal-failure €, counted once (§12).

```mermaid
flowchart LR
  MEAS["Measurements + DefectRecords + dispositions"] --> KPI["FPY · Quality ratio · ppm · Cpk"]
  DEF["Defect Pareto (count)"] --> COQ["Cost of Quality engine"]
  RATE["CostRate: scrap · rework · downgrade Δ · inspection · concession · claim"] --> COQ
  M5L["M5 priced internal-failure loss (one €)"] --> COQ
  COQ --> PAF["P · A · Internal-failure · External-failure (priced, ranked, 1-10-100)"]
  KPI & PAF --> REG["Shared KPI Registry (UIL, doc 03)"]
  REG --> MON["Monitoring: live SPC tile + out-of-control / defect-rate / overdue-CAPA alerts"]
  REG --> REP["Reporting: quality report, Pareto, control charts, COQ, COA/MTC"]
  REG --> SIB["M4 Quality reconciliation · M5 priced defect loss · M3 holds"]
```

---

## 10. Sector-neutral model + Hero Steels instantiation

The model is **generic** and an instantiation makes it **concrete** — the same primitives (characteristic/spec, SPC/capability, defect/disposition, NCR/CAPA, Cost of Quality) describe any plant; a sector template fills them in.

**Generic quality archetypes** (any sector): variable-dominant (dimensional/mechanical, SPC & Cpk lead — process industries, machining) vs attribute-dominant (surface/visual, defect & disposition lead — metals finishing, assembly); the appropriate disposition set (discrete plants lean scrap/rework/use-as-is; metals lean **downgrade**); the sampling regime (100% / AQL / fixed-n / continuous); whether external failure is warranty (durable goods) or claim/return (commodities).

**Hero Steels cold-rolling instantiation** (anchors the model to the real M1 plant; reuses the M1 inline checks, defect logging, lab results and COIL_NO genealogy it already captures):

| Quality concept | Generic | Hero Steels cold-rolling |
|---|---|---|
| Characteristic set | variable + attribute | **dimensional** (thickness, width, flatness/shape, crown), **mechanical** (hardness, tensile, yield, elongation per grade), **surface** (roll mark, scale pit, scratch, sliver, coil break), **chemical** (composition) |
| Spec limits | USL/LSL/nominal per grade | gauge tolerance, width tolerance, mechanical bands per grade & customer spec (versioned) |
| Control plan | char × op × method × sample | thickness/flatness at mill (inline gauge / spot), surface at inspection, mechanicals at lab per coil/coupon |
| SPC charts | X̄-R / I-MR / p / c | **I-MR** per coil for gauge; **p/u** for surface defect rate; capability Cpk on thickness per grade |
| Defect taxonomy | category→type→detail | Surface / Dimensional / Mechanical / Edge / Chemical (steel catalog) |
| **Dominant disposition** | scrap/rework/downgrade | **downgrade prime → second/commercial** (the metals signal) + rework (re-roll/re-temper) + scrap |
| Genealogy link | lot → defect | **COIL_NO**: defect & disposition attached to the coil through slitting/annealing lineage |
| Hold | quarantine | coil/lot quality hold → M3 `QUALITY_HOLD` carryover |
| External failure | claim/warranty | customer claim / returned coil; **certificate of analysis / mill test certificate** per shipped coil |
| Capture | manual / auto | v1 M1 inline + lab; future inline gauge + surface-vision (encoder defect map) |

**Reusing M1.** M1's inline checks become the variable measurement stream; M1's defect logging and slit/surface categories become canonical defect codes (M6 governs and classifies them); M1's entered lab results attach mechanicals to the coil; M1's COIL_NO genealogy is the lineage M6 uses to put the defect and disposition on the right coil through its whole life. The **steel quality sector template** (seeded in Manifold, doc 02) carries the characteristic/spec set, the control plan, the defect catalog, the disposition rules (incl. grade-downgrade), and the sampling plan — so the next steel client's quality lights up with no re-modelling. **D11 note:** because the core is sector-neutral, validating M6 on a **discrete** client (variable-dominant, Cpk-led, scrap/rework dispositions, AQL sampling) is a clean way to exercise the *variable lens and capability* hard and retire the "only-tested-on-Hero-Steels" risk (R1/W1, doc 04) — the dual-lens design means M6 covers both the attribute-heavy surface world and the variable-heavy dimensional world from one engine.

---

## 11. Data contract & readiness (the M6 row)

M6's machine-readable data contract (the basis for Manifold's module-unlocking, doc 01 §15). ● Required · ○ Additional.

| Canonical entity / group | M6 need | Notes |
|---|:--:|---|
| **ProductionCount** (good/scrap/rework/total + weight) | ● | the conformance denominator (shared with M4/M5/M3) |
| **DefectCode / DefectRecord** (Event-Spine spec.) | ● | the defect/disposition SoR M6 brings to life |
| **Characteristic + SpecLimit** (versioned, per grade) | ● | *new M6 entity* — defines "in spec"; the SPC/capability baseline |
| **Material / Grade** reference | ● | quality is grade-relative; downgrade is grade→grade |
| **Inspection/Control plan + sampling** | ● | *new M6 entity* — what to measure, where, how often |
| **Measurement** (variable values) | ● | *new M6 entity* — the SPC input stream |
| **Shift / Calendar** | ● | the time bucket for SPC subgroups & windows |
| Asset hierarchy (Site→WorkCenter→WorkUnit) | ● | the chart & roll-up tree |
| Material-lot genealogy (COIL_NO) | ● | attaches defect & disposition to the coil through its life |
| MSA / Gage status | ○ | gates trustworthy SPC/capability (strongly recommended) |
| CostRate (scrap/rework/downgrade Δ/inspection/claim) | ○ | unlocks Cost of Quality — strongly recommended |
| Maintenance/condition link (M2) | ○ | ties equipment-caused defects to failures |

**New canonical/derived entities M6 introduces** (additive, per doc 01 §14 versioning rule): `QualityConfig` (per-tenant policy: disposition rules, SPC rule-set, sampling defaults, COQ map), `Characteristic` (variable/attribute, criticality, unit, MSA status), `SpecLimit` (nominal/USL/LSL per characteristic×grade, versioned), `InspectionPlan` (control plan: characteristics × work-unit × sampling × reaction), `Inspection` + `Measurement` (executed inspection & variable values), `ControlChart` (definition, limits, capability), `SpcSignal` (special-cause violation), `DefectRecord` (the Event-Spine specialization M6 owns + disposition), `QualityHold`, `Nonconformance` (NCR/MRB), `Capa` (root cause + corrective/preventive + verify), `CoqEntry` (priced P/A/IF/EF), `QualityTarget`, `PolicyChangeLog`, `ReadinessSnapshot`, `QualityPrediction` (stub). The canonical `DefectCode`/`DefectRecord` scaffolding **already exists** in the canonical catalog (doc 01 §10) — M6 is the module that finally **brings the conformance side to life**. Unlike M4/M5, M6 *does* own genuinely new transactional data (the conformance record), but it anchors every row to the *one* shared `ProductionCount` for no-double-count.

**On-ramps to readiness** (capture-fidelity-aware, §5):

```mermaid
flowchart TD
  Q{"How are measurements & defects captured today?"}
  Q -- "M1 first-party capture" --> M1B["Bootstrap: M1 inline checks → measurements · defect logging → defect codes · COIL_NO → lineage (v1, no hardware)"]
  Q -- "Existing QMS/LIMS/lab record" --> ING["Manifold connector + quality sector template → ingest measurements/specs/defects"]
  Q -- "Inline gauge / lab / vision available" --> AUTO["Edge collectors → high-fidelity measurement & encoder defect map (future-proofed switch-on)"]
  Q -- "Nothing yet" --> FP["First-party quality capture (reuse M1 UX/RBAC)"]
  M1B & ING & AUTO & FP --> RDY["Readiness scoring (doc 01 §16): Required gate + Quality + Fidelity(MSA) + History"]
  RDY --> UNLOCK["Unlock: dual-lens SPC + disposition + CAPA + COQ now · auto-gauge/vision when instrumented · prediction when History gate passes"]
```

The readiness model is the platform's existing one (doc 01 §16) with **two M6-specific sub-gates**: a **Fidelity/MSA gate** (manual vs inline gauge? is the gage qualified (Gage R&R)? is the spec versioned & calibrated? is the defect taxonomy governed or is "Other" runaway?) that drives the *confidence* shown beside every Cpk and defect number (Principle 5/7), and a **prediction-readiness (History) gate** that reports when a characteristic×route has enough labelled quality history to train the §8 models. So the UI honestly shows "Cpk here is indicative (gage unqualified, spot-sampled)" rather than a falsely precise figure.

---

## 12. Integration & boundaries

| Boundary | M6 owns | The other side owns | Shared artifact |
|---|---|---|---|
| **M6 ↔ M5 (Yield)** | the **defect taxonomy, disposition, holds, SPC, root cause** (the quality SoR — *why* it's bad, *what we decided*) | *how much* material was lost & what it **cost** (material accounting & economics) | the single `DefectRecord` / `ProductionCount` (M6 classifies & dispositions, M5 accounts & prices) |
| **M6 ↔ M4 (OEE)** | the defect taxonomy, disposition, SPC behind the Quality factor | the OEE **Quality factor** (Good÷Total, time-effectiveness) + quality-loss minutes split | the single `ProductionCount` / `DefectRecord` (agree by construction) |
| **M6 ↔ M3 (Planning)** | **quality holds** (what may not ship/plan), conformance status of a lot | the plan/route/sequence; MRP netting; handover carryover | `QualityHold` → `QUALITY_HOLD`; M6 publishes, never writes ops.* |
| **M6 ↔ M1** | quality calculation, governance & the SoR | first-party capture of checks/measurements/defects at source | `Measurement`, `DefectRecord`, COIL_NO lineage |
| **M6 ↔ M2 (Maintenance)** | the **defect** an equipment condition produced | the failure/condition (worn roll → roll mark) | `DefectRecord` ↔ `WorkOrder`/condition |
| **M6 ↔ M7 (Energy)** | the good/defective split | energy-per-good-unit, embedded-energy waste in scrap | `ProductionCount.good/scrap` |
| **M6 ↔ Manifold** | the M6 data contract + quality sector template | QMS/LIMS/lab/gauge connectors, field-mapping, readiness | sector template library |
| **M6 ↔ UIL** | FPY/quality-ratio/ppm/Cpk/COQ + hold/CAPA status | cross-module synthesis (quality↔yield↔OEE↔plan↔cost), exec rollups | shared KPI registry |
| **M6 ↔ Monitoring** | live SPC tile, hold board, CAPA board, out-of-control alerts | live cache, alert delivery | streaming path |
| **M6 ↔ Financial Impact** | what to price (every defect/disposition; the four COQ buckets) | the cost-rate engine & "rate-as-of" provenance (D7) | `CostRate` |

The **two lines to get right** are with M5 and M4, and both follow one discipline: **the count/defect is recorded once; M6 governs and dispositions it, the sibling reads its own view.** A produced quantity is one `ProductionCount` — **M4 reads it as the OEE Quality factor**, **M5 reads it as material yield**, **M6 reads it as the conformance denominator**; M6's defect-driven quality loss and M4's Quality factor are computed from the *same* good/total with the *same* ISO 22400 mapping, so they **agree by construction** — never two quality numbers. A bad unit is one `DefectRecord` — **M6 classifies the defect and decides the disposition** (scrap/rework/downgrade), **M5 accounts the material and prices the loss** of that disposition; the **internal-failure € in M6's Cost of Quality *is* M5's priced loss for the same records, counted once** (M6 reconciliation test: Σ M6 disposition quantities for defect-driven reasons == Σ M5 loss attributed to those `DefectRecords`; M5 spec 06 §4). Neither double-counts. This single-truth discipline is the whole reason the platform can finally end the "quality says 3% defects, production says 96% good, finance says 4% scrap" argument: there is one defect truth, dispositioned once, priced once.

---

## 13. RBAC & operations (brief)

Roles extend M1's model (Operator / Supervisor / Plant-Head / Admin) with quality-specific personas: **Operator / Inspector** (records inline checks & measurements, logs defects, sees the live SPC tile and the reaction plan for their line), **Shift Supervisor** (shift quality, defect Pareto, validates defect coding, raises/clears holds within authority), **Quality Engineer** (configures characteristics, spec limits, control plan, defect taxonomy, SPC rule-sets, sampling; runs SPC/capability analysis; chairs routine disposition), **MRB member** (authorises non-routine dispositions incl. downgrade/use-as-is), **CAPA owner / Quality Manager** (owns root-cause cases to verified closure, manages the CAPA backlog, reads COQ), **Cost / Finance analyst** (reads the priced Cost of Quality — read-only), **Plant Manager** (quality trends, COQ, hold/CAPA status; read-only analytics), **Admin** (masters, integration, capture/MSA config, quality policy). Because quality configuration (spec limits, control limits, disposition rules, defect taxonomy) directly moves the conformance and COQ numbers, **every policy change is audit-logged** with effective dating (ISO 9001 traceability), so a Cpk or defect trend is never silently broken by a re-definition, and a disposition is always attributable to an authoriser. First-party/edge capture is **offline-tolerant** like M1 (queue locally, sync on reconnect). The SPC and disposition engines run on the streaming path for the live tile and as scheduled rollups for the mart; recomputation is **deterministic and replayable** from the canonical events (a corrected measurement or re-coded defect re-derives the affected charts, dispositions and COQ without manual patching). Row-level scoping by site/area as in M1. The quality SoR (NCR, MRB decisions, CAPA) is **append-only / audit-trailed** to satisfy ISO 9001 / IATF 16949 record-retention.

---

## 14. MVP migration bridge, build sequence & open decisions

**MVP migration bridge (target design + migration).** The operating model notes M6 **dashboards & insights are already built**. This plan describes the **target** M6 against the canonical model; the existing build is the head-start, not the constraint. The bridge:

| Existing M6 today (dashboards + insights) | Target M6 | Migration path |
|---|---|---|
| Defect counts / quality % from its own query or a direct M1/QMS feed | Conformance from the **canonical ProductionCount + DefectRecord** (one shared truth) | repoint the calc onto `canon.*` ProductionCount/DefectRecord via the Serving API; keep the existing dashboards |
| Flat defect categories / ad-hoc reasons | 3-layer **governed taxonomy** → DefectCode + criticality + default disposition + LossCategory | migrate existing categories as Layer-1/2 leaves; backfill criticality & disposition; keep historical codes as aliases |
| SPC in spreadsheets (or none) | registry **control charts** (chart type, limits, WE/Nelson rules) + capability Cpk | seed limits from current data; attach MSA status; surface special-cause signals |
| Disposition on paper / spreadsheet | governed **NCR → MRB → disposition** (incl. grade-downgrade) | model the disposition workflow; backfill open holds; capture authoriser |
| Quality % in app code | quality KPIs in the shared **ISO 22400 KPI registry** | move definitions into the registry so M4/M5/UIL read the same numbers; reconcile existing output (acceptance test) |
| Standalone quality dashboard | quality as a synthesised layer (UIL/Monitoring/Reporting/Financial) | publish conformance, holds, CAPA & COQ to the canonical zone; the existing screen becomes one consumer |

The migration is **non-destructive and incremental**: the existing dashboards keep running while the calc is repointed to the canonical events and the definitions move into the shared registry; the first acceptance gate is *"existing defect rate / FPY / scrap-disposition mix and the canonical figures agree to tolerance on a back-test window, and M6's Quality-loss reconciles to M4's Quality factor and M5's priced loss."* No data is thrown away; existing defect codes and history are mapped forward.

**Suggested build order (bootstrap-first — closest to M1 & cheapest value, then up the fidelity/intelligence ladder):**

1. **Quality reference & policy + canonical wiring** — characteristic/spec catalog, control plan, defect taxonomy → criticality/disposition/LossCategory mapping, sampling, quality config; bring the canonical DefectCode/DefectRecord to life; repoint the existing dashboards onto `canon.*`.
2. **Conformance capture + attribute conformance** — inspection/measurement/defect capture from M1, the governed defect record, FPY/quality-ratio/defect-rate per process/coil/grade (fastest first value); the M6↔M4 (Quality factor) reconciliation test.
3. **SPC & capability + holds & disposition** — control charts, WE/Nelson rules, Cpk (MSA-gated); quality holds → M3 `QUALITY_HOLD`; NCR → MRB → disposition (incl. grade-downgrade); the M6↔M5 (priced disposition) reconciliation test.
4. **CAPA/8D + Cost of Quality + Monitoring board** — root-cause cases to verified closure, FMEA/control-plan feedback; priced P/A/IF/EF (internal failure == M5 loss, counted once); live SPC tile + out-of-control/defect-rate/overdue-CAPA alerts; reporting pack incl. certificate of analysis / mill test certificate.
5. **Automatic capture (inline gauge / lab / vision) — switch-on** — edge collectors, true continuous SPC, encoder-located surface defect map; Fidelity/MSA gate rises (no re-model).
6. **Prediction / ML (E7) — FUTURE, gated:** defect-risk & SPC-excursion prediction, automated visual-defect classification when the History gate passes; prescriptive later (shares the M2/M4/M5 ML-readiness substrate & one model surface).

**Open decisions (need your call):**

- **SPC rule-set default** — adopt **Western Electric**, **Nelson**, or a tuned subset as the platform default out-of-control rule set (per-characteristic overridable; trades false alarms vs missed drift)?
- **Capability targets** — platform default **Cpk ≥ 1.33** (and **≥ 1.67 for critical/safety** characteristics), or a different floor per the first clients' customer specs?
- **Disposition authority threshold** — which severities route to a full **MRB** vs auto-disposition by rule, and who sits on the MRB (quality only, or quality + production + metallurgy)?
- **Downgrade pricing ownership** — who owns the prime→second **price delta** that prices a downgrade (metallurgy/commercial vs finance), and is downgrade margin loss reported inside Cost-of-Quality internal failure by default (recommended)?
- **Sampling default** — for surface vs dimensional vs mechanical, what is the default regime (100% / **AQL ISO 2859** / fixed-n / continuous-SPC) per characteristic class?
- **MSA gate strictness** — does an **unqualified gage** block a *published* Cpk (recommended) or only flag it low-confidence? what Gage R&R threshold qualifies a characteristic?
- **CAPA trigger thresholds** — what defect-rate / recurrence / SPC-signal frequency auto-opens a CAPA vs leaves it to judgement?
- **Cost-of-Quality scope in v1** — price all four PAF buckets, or start with Internal Failure (== M5 loss) + Appraisal and add External Failure when complaint/return data connects?
- **First connector after M1** — which QMS/LIMS/lab/gauge source first for the ingest on-ramp (ties to D4)?
- **MVP reconciliation tolerance** — what back-test agreement (e.g. defect rate / FPY within ε over a 30-day window, *and* M6 Quality-loss == M4 Quality factor, *and* M6 disposition == M5 priced loss) is the acceptance gate for repointing the existing dashboards onto canonical events?
- **Prediction build gate** — what labelled-quality-history threshold per characteristic×route flips it to "prediction-ready" (share the platform ML-readiness gate with M2/M4/M5)?
- **Second-sector validation (ties to D11)** — use M6 on a **discrete / variable-dominant** client (Cpk-led, AQL sampling, scrap/rework dispositions) to exercise the variable lens & capability and retire the only-Hero-Steels risk?

---

### Sources (standards & product grounding)

- **Quality KPI definitions (FPY, scrap/rework/quality ratio, fall-off)** — ISO 22400-2, reconciled to M4/M5: [ISO 22400-2:2014](https://www.iso.org/standard/54497.html), [ISO 22400 KPI structure — quantities](https://connect981.com/blog-posts/iso-22400-kpi-structure-time-states-quantities), [first-pass yield (Wikipedia)](https://en.wikipedia.org/wiki/First-pass_yield), [ISO 22400 KPI overview](https://connect981.com/blog-posts/iso-22400-overview-manufacturing-kpis-basics)
- **QMS backbone & nonconforming output / corrective action** — ISO 9001 cl. 8.7 (control of nonconforming output), cl. 10.2 (nonconformity & corrective action), cl. 7.1.5 (monitoring & measuring resources): [nonconformance management](https://simplerqms.com/non-conformance/), [CAPA & non-conformance software (Qualio)](https://www.qualio.com/product/capa-management-software), [eQMS overview (MasterControl)](https://www.mastercontrol.com/quality/electronic-quality-management-system/)
- **IATF 16949 + AIAG core tools (APQP, PPAP, FMEA→control plan, MSA, SPC)** — the specify & data-integrity layer: [automotive core tools (BSI)](https://www.bsigroup.com/en-ID/iatf-16949/iso-ts-16949-training-courses/automotive-core-tools-for-auditors-apqp-ppap-fmea-spc-msa/), [navigating the core tools](https://msmatter.co.uk/iatf-16949-navigating-the-core-tools-apqp-ppap-fmea-msa-and-spc/), [quality core tools (AIAG)](https://www.aiag.org/expertise-areas/quality/quality-core-tools), [5 core tools of IATF 16949](https://www.ipqcco.com/blog/5-core-tools-of-iatf16949-qsm-apqp-ppap-fmea-msa-spc)
- **SPC — control charts, run rules & process capability** — variable (X̄-R, X̄-s, I-MR) & attribute (p, np, c, u) charts; Western Electric / Nelson rules; Cp/Cpk/Pp/Ppk; common vs special cause: [SPC charts ultimate guide (6sigma.us)](https://www.6sigma.us/six-sigma-in-focus/spc-charts/), [Western Electric & Nelson rules (Quality Gurus)](https://www.qualitygurus.com/nelson-rules-and-western-electric-rules-for-control-charts/), [control chart rules (MetricGate)](https://metricgate.com/docs/control-chart-rules/), [understanding Cp, Cpk, Pp, Ppk (Lab Wizard)](https://lab-wizard.com/en/resources/knowledge/understanding-spc-parameters/), [SPC in manufacturing (Augmentir)](https://www.augmentir.com/glossary/statistical-process-control-spc)
- **Acceptance sampling (AQL) & defect classification** — ISO 2859-1 single/double/multiple plans, inspection levels, critical/major/minor: [AQL sampling guide (Qarma)](https://www.qarmainspect.com/blog/aql-sample-plan-the-ultimate-guide-to-ensuring-quality-control-and-compliance), [ISO 2859-1 AQL sampling (ANSI)](https://blog.ansi.org/ansi/iso-2859-1-2026-aql-sampling/), [ISO 2859-1 (ISO)](https://www.iso.org/obp/ui/#iso:std:iso:2859:-1:ed-2:v1:en)
- **8D / CAPA / root cause** — Ford TOPS D0–D8; containment vs corrective vs preventive; 5-Why; Ishikawa fishbone (6M); effectiveness verification: [8D problem solving (ASQ)](https://asq.org/quality-resources/eight-disciplines-8d), [mastering 8D (AssurX)](https://www.assurx.com/mastering-the-8d-problem-solving-methodology-a-guide-to-root-cause-analysis-in-manufacturing/), [root cause analysis guide — 5 Whys/fishbone/8D/FMEA (PRIZ)](https://www.priz.guru/root-cause-analysis-guide/), [CAPA management (Manufacturo)](https://manufacturo.com/manufacturo-manufacturing-management-software/capa-management-software/)
- **Cost of Quality / COPQ (PAF model)** — Prevention + Appraisal + Internal-failure + External-failure; ~15–20% of revenue; 1-10-100 rule: [what is Cost of Quality (ASQ)](https://asq.org/quality-resources/cost-of-quality), [CoQ categories & calculation (SimplerQMS)](https://simplerqms.com/cost-of-quality/), [Cost of Quality (ComplianceQuest)](https://www.compliancequest.com/what-is-cost-of-quality-coq/), [CoQ in manufacturing (Tulip)](https://tulip.co/blog/cost-of-quality/)
- **Steel quality — surface/dimensional defects, grade-downgrade disposition, vision, certificate** — 2–5% to second/reject; encoder-located vision; per-coil quality certificate / defect map: [steel surface defect management](https://oxmaint.com/industries/steel-plant/steel-surface-defect-management-software), [computer vision for steel surface defects](https://oxmaint.com/industries/steel-plant/computer-vision-steel-defect-detection), [coil quality inspection with vision AI](https://oxmaint.com/industries/steel-plant/coil-quality-inspection-ai), [steel surface quality inspection (ISRA Vision)](https://www.isravision.com/en-en/industries/metals/steel-surface-quality-inspection), [coil break defect (Metal Zenith)](https://metalzenith.com/blogs/defects-inspection-testing-terms/coil-break-key-defect-in-steel-quality-control-and-testing)
- **eQMS product grounding (how it's implemented on the ground)** — integrated SPC↔NCR↔CAPA loop, MRB disposition, supplier quality, audit/doc control as the broader QMS surround: [eQMS (MasterControl)](https://www.mastercontrol.com/glossary-page/electronic-quality-management-system/), [ETQ/MasterControl/Qualio comparison](https://intuitionlabs.ai/articles/biotech-eqms-comparison-trackwise-mastercontrol-qualio), [AI in manufacturing quality (Qualityze)](https://www.qualityze.com/blogs/ai-manufacturing-quality-management)
- **Platform-internal** — `01_DataLake_and_Canonical_Model_DeepPlan.md` (canonical model, Event Spine §10 incl. DefectRecord, ISO 22400 quantities §9, §15 contract, §16 readiness), `02_Manifold_DeepPlan.md` (connectors, sector templates), `03_UnifiedIntelligence_and_OperationalMonitoring_DeepPlan.md` (KPI registry, monitoring), `04_Consolidated_Review_and_Traceability.md` (D7, D11, R1/W1), `05_Reporting_Layer_DeepPlan.md`, `M4_OEE_Downtime_DeepPlan.md` (the shared ProductionCount; Quality factor = M6 Quality-ratio; the L5/L6 quality-loss split), `M5_Yield_Intelligence_DeepPlan.md` (the shared DefectRecord; M6 classifies/dispositions, M5 accounts/prices; the internal-failure € counted once; spec 06 §4 reconciliation), `M3_Shopfloor_Planning_Management_DeepPlan.md` (the `QUALITY_HOLD` carryover), `M2_Maintenance_Intelligence_DeepPlan.md` (defect↔failure link; shared ML model surface), M1 Technical Blueprint (inline checks, defect logging, lab results, COIL_NO genealogy, capture patterns)
