# Zedral — M7 · Energy Intelligence

### Deep Plan · v1 · Module Layer (Meter every carrier → normalise to one unit → baseline & set the EnPI → detect the variance → contain demand & cost → price the energy and the carbon → act)

> **What M7 is.** M7 is Zedral's **Energy Intelligence** module — the platform's *energy-and-carbon system-of-record and the energy management information system (EnMIS)* over the shopfloor. Where M4 answers "how *effectively* did the equipment run?", M5 "of every tonne in, how much became sellable?", and M6 "is it good and what did poor quality cost?", M7 answers the question that is becoming the third axis of competitiveness after cost and quality: "**how much energy and carbon does every tonne cost, where is it wasted, and what is the cheapest way to use less?**" M7 takes consumption from **every energy carrier** the plant buys or makes — purchased and captive **electricity**, **natural gas / fuel** (the reheating furnace), **steam / thermal**, **compressed air**, and **water** — meters or ingests it, converts it to a **common energy unit** (GJ) and a **common carbon unit** (kgCO₂e), and holds energy in **two lenses at once**: the **absolute** lens (the kWh, the GJ, the ₹ on the bill, the tonnes of CO₂ — what you actually spent) and the **normalised** lens (the **energy intensity / EnPI** — GJ per tonne, regression-adjusted for production and weather — *whether you are actually getting more efficient*). It builds the **energy baseline (EnB)** every improvement is measured against, runs the **measurement & verification (M&V)** that says how much energy was *avoided*, watches **maximum demand, power factor and time-of-use** so the demand and tariff penalties are managed not discovered, registers the **Significant Energy Uses (SEUs)** where the energy actually goes, and serves a live "what is drawing power right now, what is drifting off its baseline, and what is it costing in money *and* carbon" view. M7 is the module that turns "the energy bill" — a monthly number finance pays and operations never sees — into a **metered, baselined, normalised, demand-managed, carbon-accounted, priced energy model** an executive can act on.
>
> **Why it's high-value.** Energy is the manufacturing cost line that is simultaneously **large, volatile and almost completely unmanaged at the point of use**. For an integrated or re-rolling steel plant energy is **15–40% of conversion cost**; a cold-charged rebar mill burns roughly **1.75 GJ/t of gas and ~90 kWh/t of electricity**, and best-practice hot rolling reaches **~1.3 GJ/t** — the gap between a typical and a best-practice mill is *real money per tonne, every tonne*. Yet energy's chronic disease is that it is **invisible below the utility meter**: the bill arrives monthly at the plant boundary, nobody can say which furnace, mill, motor or compressor drew it, idle and standby load runs all weekend unmetered, compressed-air leaks waste **1–1.5 GWh/year** on a single header, the **maximum-demand charge can be ~40% of the electricity bill** and is set by a few unmanaged 15-minute peaks, and a poor **power factor** quietly draws a kVA penalty. M7's value is to make energy **visible, normalised, demand-managed, carbon-priced and prescriptive** — to push the meter boundary *down to the SEU*, to separate "we used more energy because we made more steel" (fine) from "we used more energy **per tonne**" (a real regression), to catch a process drifting off its energy baseline *before* the month-end bill, to manage the demand peak and the power factor instead of paying the penalty, and to put **two currencies — ₹ and kgCO₂e — on every tonne** so the efficiency investment that removes the waste can be justified. It is also one of the **densest pull-through modules for connected data** (meters, sub-meters, bills, fuel logs, SCADA tags): the more carriers and feeders are connected, the lower the meter boundary drops and the sharper every number gets — the platform's core commercial wedge.
>
> **What M7 is NOT.** It is **not a data-capture product** competing with M1 — it *consumes* the meter readings, fuel logs, bills and (future) SCADA energy tags that M1 and the metering layer produce, and adds the normalisation, baseline, M&V, demand, carbon and cost intelligence on top. It is **not the material-accounting engine** — M7 shares the *one* `ProductionCount` (and COIL_NO genealogy) with M4/M5/M6, but M5 owns *how much material was lost*, while M7 owns *the energy embedded in making it* (the embodied-energy view of scrap). It is **not the OEE engine** — M4 owns the machine **state and time** (running / idle / down); M7 *reads that state* to split energy into productive vs idle/standby draw, and never recomputes the state itself. It is **not the planning system** — M3 owns the schedule; M7 *feeds it* the time-of-use cost surface and the demand headroom so energy-intensive campaigns can be sequenced into off-peak windows. And in its full EnMS reach — meter device management, real-time monitoring, demand response, tariff optimisation — M7 is designed as the **target**, with the heavy real-time/automated rungs **future-proofed and switch-on** (§5, §8) exactly as the platform builds every module: analytics depth now, automation and ML as metering and history accumulate. M7 is an **energy-and-carbon intelligence layer over a shared production truth**, never a parallel truth.
>
> **Standards anchors.** The **ISO 50001** energy-management-system backbone (the **energy review** → **Significant Energy Uses (SEU)** → **energy baseline (EnB)** → **energy performance indicators (EnPI)** → objectives → action plan loop, and the *Plan-Do-Check-Act* that drives continual energy-performance improvement); **ISO 50006** for the *method* of building EnBs and EnPIs and **normalising** them to relevant variables (production volume, weather/HDD-CDD, product mix); **ISO 50015 + the IPMVP** (Options A/B/C/D — retrofit-isolation vs whole-facility, regression-baseline adjustment) for **measurement & verification** of energy savings — *avoided energy* against the projected baseline, not raw before/after; the **GHG Protocol** corporate standard and **Scope 2 guidance** (Scope 1 direct combustion; Scope 2 purchased electricity/steam computed **both location-based and market-based**; Scope 3 future) with **ISO 14064** as the assurance frame; **ISO 14404 (Parts 1–4)** for the *steel-specific* CO₂-emission-intensity calculation (tCO₂ per tonne of crude/rolled steel, boundary + import/export method); **ISO 22400-2** for the energy KPI definitions (energy per unit) reconciled to the platform's shared registry so M7, M4 and M5 speak one number; and the **DOE Better Plants / energy-treasure-hunt** system taxonomy for the SEU classes (process heating, compressed air, motor/drive, pumping, fans, steam, HVAC, lighting, process cooling). Electrical-demand practice anchors the demand/tariff engine: **maximum demand (15/30-min)**, **time-of-use** tariff windows, and **power-factor / kVA** correction. Steel-specific anchors: **specific energy consumption (SEC, GJ/t and kWh/t)** benchmarks per process (reheating furnace, rolling mill), hot- vs cold-charging, and the captive-power / DG-vs-grid mix. Links in §15.

---

## 0. How M7 relates to the rest of the platform

M7 is an **intelligence contributor, a synthesiser, *and* the energy-and-carbon system-of-record** — it reads the canonical production/state/genealogy stream through the Serving zone, reads or meters every energy carrier, runs the normalisation, baseline, M&V, demand, carbon and cost engines, and writes its derived and transactional energy facts (consumption, EnPI, baselines, demand events, emissions, energy cost) back so every other layer can reuse them. Like M6 (and unlike the pure thin-write M4/M5), M7 *owns* genuinely new transactional data — the **energy consumption record and the meter** — but it still anchors every consumption row to the *one* shared `ProductionCount` / `Shift` / asset node so energy, OEE, yield and quality never disagree about *what was being made when the energy was drawn*.

| Platform piece (doc) | What M7 consumes from it | What M7 gives back |
|---|---|---|
| **Data Lake · Canonical Model** (01) | `ProductionCount` (good/scrap/rework/total + weight — the EnPI denominator), Asset hierarchy (Site→Area→WorkCenter→WorkUnit — the metering tree), `Shift/Calendar` (the period spine), `StateInterval` (running/idle/down from M4), `Material`/`Grade` + COIL_NO genealogy, `CostRate`/`LossCategory` reference | New energy entities (EnergyCarrier, Meter, MeterReading, EnergyConsumption, UtilityBill, Tariff, SEU, EnPI, EnergyBaseline, EnergyBalance, DemandInterval, EmissionFactor, EmissionEntry, EnergyCostEntry); a metered, normalised energy layer over the existing spine |
| **Manifold** (02) | Connector to meters / SCADA historian / utility-bill / fuel-log / BMS source; field-mapping of meter tags, carriers and tariff structures; the carrier→common-unit and carrier→CO₂-factor maps; sector templates; readiness/unlock | The M7 data contract; a seeded **energy sector template** (steel carriers, SEU classes, SEC EnPIs, tariff shape, CO₂ factors) |
| **M1 · Shopfloor Digitization** (M1 blueprint) | First-party **manual meter readings**, **fuel/DG logs**, **utility-bill entry**, the `shift_log` time spine — the **v1 bootstrap source** | Per-shift/feeder energy & intensity back into M1's reporting; the demand/PF/anomaly flags operators can act on |
| **M4 · OEE & Downtime** | the machine **`StateInterval`** (running / idle / standby / down) + run-time — *what state the equipment was in* | energy split by state (**productive vs idle/standby/no-load** draw); the standing/idle-energy loss tied to the same downtime windows M4 already classified |
| **M5 · Yield Intelligence** | the **priced material/yield loss** + the loss quantities by stage | the **embodied energy of the loss** — the kWh/GJ and kgCO₂e *already spent* making material that became scrap/off-cut (energy hits twice: the lost material *and* the energy to make it) |
| **M6 · Quality Intelligence** | the **good vs defective / downgraded** split (the `DefectRecord` + disposition) | the **embedded-energy waste in defective product** — energy spent on units that were scrapped or downgraded |
| **M3 · Shopfloor Planning & Management** | the plan/route/grade mix and the running sequence | the **time-of-use cost surface + demand headroom** so energy-intensive ops are scheduled into off-peak / under the demand cap (energy-aware scheduling) |
| **M2 · Maintenance Intelligence** | the equipment condition/failure context | the **energy-signature degradation** signal (a rising specific consumption / falling efficiency = a fouled furnace, a worn compressor, a degrading motor) → condition/maintenance trigger |
| **Unified Intelligence Layer** (03) | KPI registry, cross-module synthesis | energy intensity (EnPI), absolute consumption, energy cost/tonne, kgCO₂e/tonne, demand & PF status into the shared KPI registry |
| **Operational Monitoring** (03) | live meter/consumption cache off the streaming path | live **load & demand tile**, peak-approach / PF-penalty / baseline-excursion alerts, SEU watch board |
| **Financial Impact Layer** (07 spec) | `CostRate` / `Tariff` (energy ToU, demand charge, PF penalty, fuel price, carbon price) "rate-as-of" (D7) | the priced **energy waste** — idle/standby energy, air leaks, demand-peak penalty, PF penalty, off-baseline excess, embodied energy of scrap — ranked, with the efficiency ROI |
| **Reporting Layer** (05) | Same canonical KPI numbers | energy report, EnPI/SEC trend, Sankey energy balance, demand/PF report, **ISO 50001 management-review pack** and the **GHG/CO₂ (ISO 14404) statement** |

**The golden rule (inherited):** consumers never write M7's tables and M7 never writes another module's — everything moves through the canonical model and versioned Serving APIs. A produced quantity is recorded **once** as a canonical `ProductionCount`; **M4 reads it** for OEE, **M5 reads it** for yield, **M6 reads it** for conformance, and **M7 reads it** as the EnPI denominator. A unit of energy is recorded **once** as an `EnergyConsumption` (M7-owned, anchored to the meter and the production/state context); the bill reconciles to it, the carbon is derived from it, and the cost is priced on it — one count truth, one energy truth, never double-counted (§12).

---

## 1. Responsibilities & principles

M7 owns ten responsibilities: **(1)** maintain the **energy reference & policy data** (the carrier catalog with common-unit and CO₂ conversion factors, the metering hierarchy, the SEU register, the EnPI definitions and targets, the energy baselines, the tariff structures, the emission-factor library, the energy-policy/normalisation config); **(2)** **capture/ingest consumption** across every carrier — capture-agnostic across M1 manual readings/bills/fuel-logs, ingested SCADA/historian/BMS, and future automatic interval metering; **(3)** **normalise** every carrier to a **common energy unit (GJ)** and allocate consumption down the metering tree to **SEU, cost-centre, work-unit, process and — where genealogy allows — COIL_NO**; **(4)** **close the energy balance** — purchased + generated = distributed + losses + unmetered gap, per carrier (the M7 analogue of M5's mass balance), so the metering-coverage gap is named honestly and never mistaken for waste; **(5)** **build the baseline & compute the EnPI** — establish the energy baseline (EnB) and the normalised intensity (EnPI/SEC) per ISO 50006, regression-adjusted for production and weather; **(6)** **run M&V** — detect variance from baseline (CUSUM/expected-vs-actual), quantify **avoided energy** per IPMVP, and flag excess-consumption anomalies; **(7)** **manage demand & power quality** — track maximum demand against the contracted cap, watch the time-of-use window and the power factor, and raise a **peak-approach / PF-penalty** signal *before* the penalty is incurred; **(8)** **account the carbon** — Scope 1 (combustion) and Scope 2 (purchased electricity/steam, location- *and* market-based) per the GHG Protocol, reconciled to the steel-specific ISO 14404 intensity; **(9)** **price the energy** through Financial Impact — energy charge (ToU), demand charge, PF penalty, fuel cost and carbon cost — and rank energy-saving projects by money *and* carbon; **(10)** stand **prediction-ready** (load/demand forecasting, anomaly detection, energy-signature condition monitoring, tariff/load optimisation) without a data re-model, and surface a **live load/demand/baseline board & alerts**.

Principles:

1. **Two lenses by design — absolute *and* normalised, at parity.** Energy data is fundamentally two questions and each is blind where the other sees. The **absolute** lens (kWh, GJ, ₹, kgCO₂e — *what we actually drew and spent*) is what finance and the carbon ledger need; the **normalised** lens (the **EnPI / specific energy consumption** — GJ per tonne, regression-adjusted for output and weather — *whether we are actually more efficient*) is what tells you the truth a raw bill hides: total energy rose because you made 20% more steel, but **energy per tonne fell** — a *win* the absolute number calls a loss, or vice-versa. M7 carries **both** at equal weight — exactly as M5 carries mass and count, and M6 carries attribute and variable. Neither is a second-class citizen.
2. **One common unit, every carrier — the energy balance must close.** Electricity in kWh, gas in m³ or GJ, steam in tonnes, air in Nm³, water in m³ are not comparable until they are converted to **one energy unit (GJ)** and (for the carbon view) **one emission unit (kgCO₂e)**. M7 converts every carrier through versioned factors and then **balances** it: what was purchased and self-generated must equal what was sub-metered to the SEUs plus distribution losses plus a named **unmetered gap**. The gap is a **metering-coverage / data-deviation** figure, surfaced honestly — *never* silently booked as either waste or saving. This is the energy analogue of M5's mass-balance honesty.
3. **Push the meter boundary down — but be honest about how far it reached.** Energy's whole problem is that it is invisible below the utility meter. M7's job is to **allocate consumption down the asset tree** — site → area → work-centre → work-unit → SEU — using whatever fidelity exists: a true sub-meter where present, an apportionment by run-time/connected-load where not. Every consumption row therefore carries a **basis** (`METERED` / `BILLED` / `CALCULATED` / `APPORTIONED` / `ESTIMATED`) and a **fidelity**, so a number derived by apportioning the main meter is never shown with the false confidence of a real sub-meter.
4. **Normalise before you judge — separate volume from efficiency.** The cardinal sin of energy reporting is comparing this month's raw consumption to last month's and calling the difference performance. M7 follows ISO 50006: an EnPI is computed **against its relevant variables** (production volume, product/grade mix, weather), and performance is the variance of *actual* vs the *baseline-projected* value at this period's conditions (the M&V / regression discipline). "We used 8% more energy" is meaningless until normalised; "we used 8% more energy at constant output and ambient" is a real, investigable regression.
5. **Manage the demand and the power factor, don't discover them.** A large share of the electricity bill is **not** energy (kWh) — it is the **maximum-demand charge** (set by the worst 15/30-minute peak in the month) and the **power-factor / kVA penalty**. These are *managed* quantities: M7 watches the rolling demand against the contracted cap and raises a **peak-approach** signal while there is still time to shed or shift load, watches the power factor against the penalty threshold, and watches the **time-of-use** clock so shiftable load is moved off-peak. Catching the peak *after* it sets the month's demand charge is worthless — the value is entirely in the *before*.
6. **Two currencies on every joule — money *and* carbon.** Every consumption row is priced in **₹** (via the tariff: energy ToU + demand + PF + fuel) *and* in **kgCO₂e** (via the emission factor: Scope 1 combustion, Scope 2 location- and market-based). Carbon is a first-class parallel currency, not an afterthought — because the cheapest-cost action and the lowest-carbon action are not always the same (grid vs captive DG), and the plant increasingly answers to both. The steel CO₂ intensity (tCO₂/t, ISO 14404) is the headline the absolute and normalised lenses both feed.
7. **Capture-agnostic, governance-faithful.** M7 does not care *how* a kWh or a GJ arrived — a manually-read meter, a typed-in utility bill, a fuel/DG log, an ingested SCADA historian tag, or a future automatic interval meter on Modbus/OPC-UA/IEC 61850. It treats every source through the same canonical contract (`MeterReading` → `EnergyConsumption`) and governs identically. v1 **bootstraps from M1's manual readings, bills and fuel logs** (cheapest first value, no hardware) and is **architected for automatic interval metering and SCADA/BMS integration** as the high-fidelity path (§5).
8. **Sector-neutral core, sector-specific skin.** The carrier / meter / consumption / SEU / EnPI / baseline / tariff / emission model is generic; a **sector template** instantiates it concretely (Hero Steels: electricity + furnace gas + compressed air + water, the reheating-furnace and rolling-mill SEUs, the GJ/t and kWh/t EnPIs, the grade-relative SEC, the captive-DG mix, the ISO 14404 boundary in §10) and reuses across clients via Manifold. The same engine serves a steel mill and a discrete-parts plant by switching the carrier set, the SEU classes and the EnPI denominators, not the code.
9. **Prediction by design, not by rebuild.** v1 is descriptive/diagnostic (what we drew, what it cost in money and carbon, where it drifted off baseline, where demand and PF bite). The metered consumption + baseline + production + weather + tariff substrate *is* the training data for later **load/demand forecasting, excess-consumption anomaly detection, energy-signature condition monitoring, and prescriptive tariff/load optimisation**; we future-proof now and gate the ML build on accumulated interval history (§8), sharing the *one* platform model surface with M2 (PdM), M4 (loss), M5 (yield) and M6 (defect).
10. **Energy is a shared truth, never a parallel one.** Every EnPI denominator is the *one* canonical `ProductionCount`; every state-split reads M4's *one* `StateInterval`; the embodied energy of scrap rides M5's *one* loss quantity and M6's *one* `DefectRecord`. M7 publishes energy facts and reads everyone else's; it never recomputes production, state, yield or defect. One production truth; one energy truth on top of it.

---

## 2. The energy conceptual frame (the scope map)

Everything M7 does sits on one closed loop — the **ISO 50001 energy-management lifecycle** — viewed through **two lenses** (Principle 1). The loop *is* M7's scope map.

**The energy loop (the spine of energy management).** Every carrier and every period moves through six stages; the loop closes when the lesson feeds back into the baseline and the plan:

```mermaid
flowchart LR
  METER["1 · METER / MEASURE<br/>every carrier: electricity · gas · steam · air · water — capture-agnostic"]
  NORM["2 · NORMALISE & ALLOCATE<br/>common unit (GJ) + CO2e · down the metering tree to SEU / cost-centre / COIL_NO · close the energy balance"]
  BASE["3 · BASELINE & EnPI<br/>energy review -> SEU -> energy baseline (EnB) -> EnPI/SEC, regression-normalised (ISO 50006)"]
  DET["4 · DETECT / VERIFY<br/>variance vs baseline (M&V/CUSUM) · excess anomaly · demand-peak approach · power-factor"]
  ACT["5 · ACT / OPTIMISE<br/>demand mgmt (peak-shave / load-shift ToU) · SEU action · tariff & DG-vs-grid choice"]
  COST["6 · COST & CARBON<br/>price (ToU + demand + PF + fuel) AND kgCO2e (Scope 1/2) -> projects -> feedback to baseline/plan"]
  METER --> NORM --> BASE --> DET --> ACT --> COST
  COST -. "lesson learned / re-baseline" .-> BASE
  DET -. "on baseline, in cap" .-> METER
  classDef meter fill:#ede9fe,stroke:#7c3aed;
  classDef det fill:#dbeafe,stroke:#2563eb;
  classDef act fill:#fee2e2,stroke:#dc2626;
  classDef cost fill:#dcfce7,stroke:#16a34a;
  class METER,NORM meter; class DET det; class ACT act; class COST cost;
```

**The two lenses (equal-weight, per scoping).**

| Lens | What it is | Answers | Catches | Misses alone |
|---|---|---|---|---|
| **Absolute / consumption** | metered quantity → GJ, ₹, kgCO₂e | "what did we draw and spend?" | the bill, the demand peak, the carbon total, the cash | calls a *win* a loss when output rises (more steel = more total energy) |
| **Normalised / intensity (EnPI)** | energy ÷ driver, regression-adjusted (SEC) | "are we actually more efficient?" | the real efficiency regression hidden inside a volume change | the absolute cash & carbon exposure (a low-intensity month can still be a huge bill) |

M7 carries both because each is blind where the other sees. The **lens** is a reporting choice on the same `EnergyConsumption` spine; an EnPI is just consumption divided by a normalised driver.

**The metering & allocation tree (push the boundary down).** Energy enters at the plant boundary and is allocated down the asset hierarchy to where it is actually used:

```mermaid
flowchart TD
  GRID["Purchased: grid electricity · gas · water"] --> BNDRY["Plant boundary meter / utility bill"]
  GEN["Self-generated: captive DG · solar · recovered heat"] --> BNDRY
  BNDRY --> AREA["Area / cost-centre sub-meter (or apportioned)"]
  AREA --> WC["Work-centre (reheat furnace · rolling mill · utilities)"]
  WC --> SEU["SEU (process heating · motor/drive · compressed air · pumping · fans · steam · HVAC · lighting)"]
  SEU --> PROD["Production context: ProductionCount · StateInterval · COIL_NO (genealogy)"]
  classDef src fill:#ede9fe,stroke:#7c3aed;
  classDef seu fill:#dbeafe,stroke:#2563eb;
  class GRID,GEN src; class SEU seu;
```

**The carrier → balance → intensity → cost/carbon chain (the so-what).** Once consumption is captured it is balanced, normalised, priced and carbon-accounted. This chain *is* the M7 product:

```mermaid
flowchart TD
  C["EnergyConsumption per carrier (metered / billed / apportioned)"] --> BAL["Energy balance: purchased + generated = distributed + losses + unmetered gap"]
  BAL --> ALLOC["Allocate to SEU / cost-centre / work-unit / COIL_NO"]
  ALLOC --> ENPI["EnPI / SEC (GJ per tonne, regression-normalised)"]
  ENPI --> MV["M&V vs baseline -> avoided energy / excess"]
  ALLOC --> COST["Price: energy ToU + demand + power-factor + fuel"]
  ALLOC --> CO2["Carbon: Scope 1 combustion + Scope 2 location/market"]
  MV & COST & CO2 --> RANK["Ranked energy-waste & saving register (₹ and kgCO2e)"]
  classDef bal fill:#dbeafe,stroke:#2563eb;
  classDef cost fill:#dcfce7,stroke:#16a34a;
  class BAL,ALLOC bal; class COST,CO2,RANK cost;
```

**Mapping energy to the OEE state, the yield loss and the defect (the M7↔M4↔M5↔M6 seam).** Energy carries the canonical context so the modules close to the same denominators:

| Energy situation | Production/state context | Other-module truth | M7 treatment | Cost/carbon class |
|---|---|---|---|---|
| Energy while **running & making good** | `StateInterval=RUNNING`, `ProductionCount.good` | M4 productive time | productive energy → the *real* EnPI numerator | direct energy cost + Scope 1/2 |
| Energy while **idle / standby / no-load** | `StateInterval=IDLE/DOWN` (M4) | M4 idle/down minutes | **standing/idle energy loss** (avoidable) | avoidable waste |
| Energy embedded in **scrap / yield loss** | `ProductionCount.scrap`, M5 loss qty | M5 priced material loss | **embodied energy of loss** (energy hits twice) | avoidable waste (energy + carbon) |
| Energy embedded in **defective / downgraded** | M6 `DefectRecord` + disposition | M6 good/defective split | **embedded-energy waste** on rejected units | avoidable waste |
| **Demand peak** beyond contracted cap | the 15/30-min window | — | demand-charge exposure | demand penalty (managed) |
| **Poor power factor** below threshold | feeder kVAr/kVA | — | PF / kVA penalty | power-quality penalty (managed) |
| **Off-peak shiftable** load run on-peak | the ToU clock + M3 schedule | M3 schedule | tariff-arbitrage opportunity | avoidable cost (not energy) |

**What's in v1 vs future.** v1 owns the full dual-lens energy model: the carrier catalog + common-unit/CO₂ conversion, the metering hierarchy and allocation, the energy balance, SEU register, the EnB + EnPI/SEC (regression-normalised), M&V variance, demand & power-factor tracking, Scope 1/2 carbon, and energy cost pricing — descriptive/diagnostic, **from manual readings/bills/fuel-logs on day one**. The **yellow** capability — *forecasting* load and demand, excess-consumption anomaly ML, energy-signature condition monitoring, and prescriptive tariff/load/DG optimisation and automated demand response — is architected now and built later (§8), gated on accumulated interval history. **Full-EnMS rungs future-proofed (target, switch-on, not v1 build):** automatic interval metering & meter device management, real-time SCADA/BMS streaming, automated **demand response / load control**, and the **tariff-optimisation engine** — the data hooks (`meter`, `tariff`, `demand_interval`, the streaming interface) are present so these light up without a re-model (§5, §8).

---

## 3. M7 reference architecture

```mermaid
flowchart LR
  subgraph SRC["Energy / production sources — capture-agnostic"]
    A1["M1 first-party: manual meter readings · fuel/DG logs · utility-bill entry (v1 bootstrap)"]
    A2["Automatic interval meters · SCADA/historian · BMS (future-proofed, §5)"]
    A3["Existing energy/EMS/utility-portal record via Manifold (ingest on-ramp)"]
    A4["M4 StateInterval · M5 loss qty · M6 DefectRecord · M3 plan · ProductionCount/COIL_NO"]
  end
  subgraph M7["M7 · Energy engines"]
    E1["Energy Reference & Policy (carrier + common-unit/CO2 factors · metering tree · SEU register · EnPI defs · tariff · emission factors · config)"]
    E2["Consumption Capture & Normalisation (reading -> consumption · GJ + CO2e · allocate down the tree · basis/fidelity)"]
    E3["Energy Balance & EnPI engine (purchased=distributed+loss+gap · EnB · EnPI/SEC regression-normalised)"]
    E4["M&V, Demand & Power-Quality engine (variance vs baseline/CUSUM · avoided energy · max-demand · power factor · ToU)"]
    E5["Carbon engine (Scope 1 combustion · Scope 2 location/market · ISO 14404 intensity)"]
    E6["Energy KPI & Cost engine (EnPI · ₹ energy/demand/PF/fuel · kgCO2e, priced & ranked)"]
    E7["FORECAST / OPTIMISE · demand response · tariff optimisation — FUTURE SCOPE"]
  end
  CANON["Data Lake · Canonical Zone (Event Spine + new M7 energy entities)"]
  SERVE["Serving zone / KPI mart / live cache"]
  subgraph CONS["Consumers"]
    UIL["Unified Intelligence (KPI registry)"]
    MON["Operational Monitoring (live load/demand tile · baseline & PF alerts)"]
    FIN["Financial Impact (priced energy waste, ₹ + CO2e)"]
    REP["Reporting (energy report · EnPI/Sankey · ISO 50001 review · ISO 14404 CO2 statement)"]
    M5c["M5 (embodied energy of loss)"]
    M4c["M4 (energy by state / idle-energy loss)"]
    M32["M3 ToU & demand headroom · M2 energy-signature condition · M6 embedded-energy waste"]
  end
  A1 --> E2
  A2 -. future .-> E2
  A3 --> E2
  A4 --> E3
  A4 --> E6
  E1 --> E2 --> E3
  E3 --> E4
  E2 --> E5
  E1 --> E5
  E3 & E4 & E5 --> E6
  E7 -. future .-> E4
  E2 & E3 & E4 & E5 & E6 --> CANON
  CANON --> SERVE --> UIL & MON & FIN & REP & M5c & M4c & M32
```

**Reading it:** readings/bills/fuel-logs arrive from M1 (v1), from automatic interval meters / SCADA / BMS (future-proofed), or from an ingested EMS/utility-portal record; the **Consumption Capture & Normalisation** engine turns each reading into a canonical `EnergyConsumption` in GJ and kgCO₂e and allocates it down the metering tree with a basis/fidelity tag; the **Energy Balance & EnPI** engine closes the carrier balance (naming the unmetered gap) and computes the regression-normalised EnPI/SEC against the energy baseline; the **M&V, Demand & Power-Quality** engine quantifies avoided energy and excess versus baseline and watches maximum demand, power factor and the time-of-use clock; the **Carbon** engine derives Scope 1/2 and the ISO 14404 steel intensity; the **KPI/Cost** engine prices everything in money and carbon and ranks the waste; all of it is written to the canonical zone and served to the intelligence/monitoring/financial/reporting layers and back to the sibling modules. Engine **E7 (forecast/optimise/demand-response)** is wired in but dark until the interval history and the model build land.

---

## 4. The normalisation, baseline & M&V engine

M7's calculation core is deliberately exact and **standards-literal**, so an EnPI is defensible to an ISO 50001 auditor, a saving is defensible to finance under IPMVP, and a CO₂ intensity reconciles to ISO 14404.

**Common-unit conversion (the precondition for everything).** No carrier is comparable until it is in one unit. M7 converts each carrier to **GJ** (primary/site energy, with the primary-vs-final convention configurable) and to **kgCO₂e** through versioned factors:

| Carrier | Native unit | → Energy (GJ) via | → Carbon via |
|---|---|---|---|
| Electricity (grid) | kWh | calorific/primary factor (kWh→GJ; ×3.6e-3 final, or source-primary) | grid emission factor (Scope 2, location & market) |
| Electricity (captive DG) | kWh (+ fuel L) | from the fuel burned | Scope 1 (the DG fuel) |
| Natural gas / fuel | m³ / kg / L | net calorific value (NCV) | Scope 1 combustion factor |
| Steam / thermal | tonne / GJ | enthalpy / boiler NCV | Scope 1 (if fired) or Scope 2 (if purchased) |
| Compressed air | Nm³ | specific power (kWh/Nm³) → back to electricity | via the electricity |
| Water | m³ | pumping/treatment energy (kWh/m³) | via the electricity |

Conversion factors (NCV, grid factor) are **effective-dated reference data** (they change year to year), so a historical GJ or kgCO₂e is always computed with the factor in force *then* — the same "rate-as-of" discipline as D7 cost rates.

**The energy balance (close it, name the gap — the M5 mass-balance analogue).** For each carrier and period: **purchased + self-generated = distributed to sub-meters + measured losses + unmetered gap.** The unmetered gap is the share of boundary energy that no sub-meter or apportionment accounted for — a pure **metering-coverage** figure. M7 surfaces it explicitly (as % of boundary energy) and *never* lets it masquerade as either waste or efficiency: a falling gap means better metering, not less energy. Exactly as M5 refuses to call a mass-balance gap "yield loss", M7 refuses to call a metering gap "waste".

**The energy baseline (EnB) & EnPI — ISO 50006-literal.** An EnPI is energy normalised by its **relevant variables**, and performance is measured against a fixed **baseline**:

| Construct | Definition | Steel example |
|---|---|---|
| **EnPI (simple)** | energy ÷ output (SEC) | GJ/t, kWh/t at a process or the plant |
| **EnPI (normalised)** | regression: Energy = β₀ + β₁·Production + β₂·Weather(HDD/CDD) + β₃·Mix … | furnace gas vs throughput & charge temperature |
| **Energy baseline (EnB)** | the model fitted over a representative reference period (≥ 12 months, ISO 50006) | last full year of furnace GJ vs tonnes |
| **Expected energy** | the baseline model evaluated at *this* period's variables | "at this output & ambient you should have used X GJ" |
| **Performance** | actual − expected (the residual) | the real, normalised regression |

The discipline (Principle 4): you do not compare raw consumption across periods — you compare actual to the **baseline-projected** value at the current period's drivers. A simple ratio (GJ/t) is the entry point; a **regression baseline** (energy as a function of production volume and weather) is the ISO 50006 / IPMVP standard, because at low utilisation the *fixed* (no-load) energy inflates GJ/t in a way a ratio misrepresents and a regression captures (the intercept β₀ *is* the standing load).

**Measurement & Verification (IPMVP — how much did we actually save?).** A saving is **avoided energy** = baseline-projected energy at current conditions − actual energy, *not* a naïve before/after (which would credit a production drop as a saving). M7 supports the IPMVP option per situation:

| IPMVP option | Boundary | M7 use |
|---|---|---|
| **A — retrofit isolation, key-parameter** | the affected system, some values stipulated | a single SEU upgrade (e.g. VFD on a fan) with spot measurement |
| **B — retrofit isolation, all-parameter** | the affected system, fully measured | a sub-metered SEU before/after |
| **C — whole facility** | the utility meter | plant-level regression baseline; savings > ~10% of total |
| **D — calibrated simulation** | modelled | no baseline data / new line (future) |

**CUSUM (the drift detector — the M7 analogue of SPC).** The cumulative sum of (actual − expected) energy is M7's control signal: a flat CUSUM means the process is tracking its baseline; a **change in slope** pinpoints *when* a process drifted off its energy baseline (a fouling furnace, a stuck damper, a developing air leak) — often weeks before the monthly bill would reveal it. This is to energy what the SPC control chart (M6 §4) is to quality: catch the drift, not just the month-end surprise.

```mermaid
flowchart LR
  CON["EnergyConsumption (GJ) + drivers (production, weather, mix)"] --> EXP["Baseline model -> expected energy"]
  EXP --> RES["Residual = actual - expected"]
  RES --> CUSUM["CUSUM of residuals"]
  CUSUM -- "slope change" --> SIG["Excess / drift signal -> investigate SEU"]
  RES --> MV["M&V avoided energy (IPMVP) vs reporting baseline"]
  CON --> ENPI["EnPI / SEC (normalised)"]
  SIG & MV & ENPI --> MART["Energy interval store (GJ · EnPI · variance · CO2e · ₹)"]
```

**Demand, time-of-use & power factor (the electricity-bill engine).** A large part of the electricity bill is not energy:

- **Maximum demand** — the highest average power over a rolling **15- or 30-minute** window in the billing period sets the **demand charge** (often a very large share of the bill). M7 tracks the rolling demand against the **contracted cap** and raises a **peak-approach** signal with enough lead time to shed or shift load (peak-shaving) — value is entirely *before* the peak sets.
- **Time-of-use (ToU)** — energy is priced by **peak / shoulder / off-peak** windows. M7 exposes the ToU surface so shiftable load (and, via M3, energy-intensive campaigns) moves to cheaper windows.
- **Power factor** — a low PF (lagging, inductive motor load) draws a **kVA / kVAr penalty**; M7 watches PF against the penalty threshold and quantifies the correction (capacitor) opportunity. Raising PF above ~0.95 typically removes the penalty.

---

## 5. Energy data capture & the on-ramp decision

Energy intelligence is only as good as the meters and logs underneath it. This is where M7's capture decision lives: **v1 bootstraps from M1's manual meter readings, typed utility bills and fuel/DG logs; automatic interval metering, SCADA/historian tags and BMS feeds are fully architected as the high-fidelity future path.** Same canonical contract (`MeterReading` → `EnergyConsumption`), two fidelities — and the whole **full-EnMS metering platform** (meter device management, real-time streaming, demand control) is the *target* this on-ramp grows into.

**The metering hierarchy is the spine.** Allocation is meaningless without knowing *which meter sits where in the asset tree and what it feeds*. M7 requires a **meter model** — meter × carrier × asset node × parent-meter × multiplier × (for electricity) the demand/PF registers — which is the bridge from the boundary bill down to the SEU. Hero Steels' single-line electrical diagram and utility layout already imply exactly this hierarchy (incoming feeder → furnace transformer → mill drives → utilities → lighting), and the gas/air/water headers the same.

**Two capture fidelities, one contract.**

```mermaid
flowchart TD
  subgraph V1["v1 — Manual bootstrap (live at Hero Steels today)"]
    M1R["M1 manual meter readings (electricity / gas / water, periodic)"]
    M1B["M1 utility-bill entry (kWh · max demand · PF · ₹ · tariff) + fuel/DG logs"]
  end
  subgraph FUT["Future-proofed — Automatic capture (switch-on; the full-EnMS target)"]
    AMI["Automatic interval meters: 15-min kWh/kVA/PF per feeder (Modbus/DNP3/IEC 61850/DLMS)"]
    SCADA["SCADA / historian / data-concentrator tags (OPC-UA) -> continuous"]
    BMS["BMS / flow meters: gas · steam · compressed-air · water headers"]
  end
  CONTRACT["Canonical contract: MeterReading (meter + ts + value/interval) -> EnergyConsumption (carrier + GJ + CO2e + SEU/cost-centre + production/state link + basis/fidelity)"]
  M1R --> CONTRACT
  M1B --> CONTRACT
  AMI --> CONTRACT
  SCADA --> CONTRACT
  BMS --> CONTRACT
  CONTRACT --> RES["Balance · EnPI · M&V · Demand · Carbon engines (identical downstream)"]
```

**v1 — bootstrap from M1 (cheapest first value).** M1 already captures, at Hero Steels, periodic manual meter readings, the monthly utility bill (kWh, maximum demand, power factor, tariff, ₹) and fuel/DG logs — exactly the consumption inputs M7 needs to produce a real energy model with **no new hardware**. M7 converts each to GJ and kgCO₂e, apportions the boundary/area energy down to work-centre and SEU by run-time and connected load, computes the EnPI/SEC per process and grade, builds the regression baseline from a year of bills, and lights up the demand/PF/ToU view straight off the bill — the on-ramp that makes M7 deliver value on day one for any M1 client. Manual capture's known blind spots are named honestly via the `basis`/`fidelity` tags (a bill-derived furnace SEC is `APPORTIONED`, not `METERED`).

**Future-proofed — automatic interval metering & SCADA/BMS (the fidelity upgrade, and the full-EnMS reach).** Manual capture is coarse (monthly bills, periodic reads, apportioned sub-loads). M7 is architected so **automatic interval meters** stream 15-minute kWh / kVA / power-factor per feeder over the standard industrial protocols (**Modbus, DNP3, IEC 61850, DLMS/COSEM**) into a data concentrator and on via **OPC-UA** to the historian/edge; **flow meters** on the gas, steam, compressed-air and water headers stream the thermal carriers; and a **BMS** feeds utilities — emitting the *same* canonical `MeterReading`/`EnergyConsumption` rows at far higher fidelity and time-resolution. This is the layer that turns the demand engine from *retrospective* (off the bill) into *real-time* (peak-shave before the peak sets), unlocks true sub-metered M&V (IPMVP B), and enables the meter-device-management, real-time-monitoring and demand-response rungs of the full EnMS target. None of M7's downstream engines change; only the fidelity (and the readiness confidence) rises. The collector/protocol interfaces are specified now (Dev_Handover spec 03/07) and built when a client instruments the line — exactly the M4/M5/M6 "future-proof, switch-on" pattern, and the path on which §8's forecasting and automated demand response later land.

**Meter device management & data quality (the metering-fidelity seam).** Before a meter reading is trusted, the **meter** under it must be trusted (Principle 3). M7 carries per meter a **calibration / health status**, a **multiplier/CT-PT ratio**, a **comms-health** flag (for automatic meters), and the **basis** it produces — and gates: a reading from an uncalibrated or stale-comms meter is flagged low-confidence and excluded from a published EnPI baseline fit; an apportioned consumption is shown with its apportionment method, never as a hard sub-meter. The energy-balance **gap** (§4) is the aggregate honesty check — a large gap means the metering coverage is thin, surfaced as a readiness deduction, not hidden. This is the energy analogue of M6's MSA gate and M5's reconciliation-gap discipline — it is what lets an ISO 50001 auditor trust the EnPI.

---

## 6. Carriers, SEUs & the energy system-of-record

The carrier → SEU → allocation chain is M7's product (Principles 2 & 3). Its leaves are **Significant Energy Uses (SEUs)**, and getting the carrier model and the SEU register right is the difference between an actionable energy SoR and a single "the plant used X kWh" number.

**The carrier model (multi-carrier by design — the user's all-utilities scope).** A steel plant is not an electricity consumer; it is a multi-carrier energy system. M7 seeds the full carrier set, each with its native unit, common-unit (GJ) factor, default emission scope, and whether it is purchased or self-generated:

| Carrier | Typical steel use | Native unit | GJ basis | Carbon scope |
|---|---|---|---|---|
| **Electricity — grid** | rolling-mill drives, motors, utilities | kWh | primary/final factor | Scope 2 (location + market) |
| **Electricity — captive DG** | backup / peak / islanded | kWh + fuel | from fuel NCV | Scope 1 (fuel) |
| **Natural gas / fuel oil / LPG** | **reheating furnace** (the dominant thermal load) | m³ / L / kg | NCV | Scope 1 combustion |
| **Steam / thermal** | annealing, pickling, heating | tonne / GJ | enthalpy / boiler | Scope 1 (fired) / Scope 2 (purchased) |
| **Compressed air** | actuation, blow-off, instrumentation | Nm³ | specific power → electricity | via electricity |
| **Water** | cooling, descaling, effluent | m³ | pumping/treatment energy | via electricity |
| **Solar / recovered heat** | self-generation, waste-heat recovery | kWh / GJ | direct | zero / avoided |

**The SEU register (where the energy actually goes — ISO 50001 §6.3).** ISO 50001 requires the **energy review** to identify the **Significant Energy Uses** — the systems/equipment that account for the bulk of consumption or hold the biggest improvement potential. M7 maintains the SEU register, each SEU with its **energy share**, its **relevant variables**, its **EnPI(s)**, and its **baseline** — using the DOE energy-treasure-hunt system taxonomy:

```mermaid
flowchart TD
  L1["Layer 1 · SEU class (DOE system taxonomy)<br/>Process heating · Compressed air · Motor/drive · Pumping · Fans · Steam · HVAC · Lighting · Process cooling"]
  L2["Layer 2 · SEU instance (the actual asset/system)<br/>e.g. Process heating -> Reheating furnace #1 · Motor/drive -> Mill main drive"]
  L3["Layer 3 · Relevant variables & EnPI<br/>e.g. furnace -> GJ/t vs throughput & charge temp · air -> kWh/Nm3 & leak load"]
  L1 --> L2 --> L3
  L2 --> SHARE["Energy share of the SEU (Pareto) -> where to meter & act first"]
  L3 --> BASE["Each SEU -> EnPI + energy baseline + target (ISO 50006)"]
```

Design rules M7 enforces, drawn from ISO 50001 practice and shared with M4/M5/M6's reason-tree discipline:

- **A handful of SEUs carry most of the energy** — in steel the **reheating furnace (process heating)** and the **mill drives (motor systems)** dominate; **compressed air** is the classic hidden waste (leaks, over-pressure, no-load running). The Pareto by energy share *is* the metering-and-action priority list.
- **Every SEU has at least one EnPI and a relevant-variable set** — without it, an SEU's consumption cannot be normalised or judged (Principle 4).
- **Capture the carrier and the SEU at log/ingest time**, not the diagnosis — the *why it drifted* is the M&V/condition engine's job (§4, §8).
- **Govern the "unallocated / general" bucket.** Exactly one "general services / unallocated" SEU exists; when it climbs into the energy-Pareto top-3 or above a threshold, M7 auto-prompts "sub-meter this load" (the metering-coverage gap made actionable).

**Allocation & genealogy (push the boundary down to the coil).** Every `EnergyConsumption` carries the asset node, the SEU, the cost-centre, the time window, and — where the metering fidelity and COIL_NO genealogy allow — the **production link** (`ProductionCount`) and the **lot/coil**. This is what lets M7 state energy *per tonne*, energy *per coil*, energy *per grade* and energy *per state* — and it is the join that makes the cross-module embodied-energy views (§12) possible. Where a true per-coil sub-meter does not exist, M7 **apportions** the work-centre energy across the coils made in the window by run-time/throughput and tags the result `APPORTIONED` — honest, useful, and upgradeable to `METERED` when the line is instrumented.

**The canonical mapping (the bit that makes energy add up).** Every carrier and SEU carries, in canonical reference data: a common-unit GJ factor, a default emission factor + scope, a `cost_centre_ref`, an `seu_class`, and the asset node — so M7's energy splits **reconcile to M4's state time, M5's loss quantity and M6's defect** (same production context, one mapping) and the carbon **reconciles to the ISO 14404 plant intensity**. The mapping is seeded by the sector template and tunable per tenant.

---

## 7. Demand, tariff, carbon & the energy economics (close-the-loop intelligence)

The two things plants under-manage most in energy are **the demand/power-quality charges that are set by a handful of unmanaged moments** and **the carbon that no one priced until a customer or a regulator asked.** M7 makes both first-class — this section is M7's deepest differentiation over a flat "kWh dashboard."

**The tariff model (the bill is not one number).** M7 models the **tariff structure** so the bill can be decomposed, predicted and optimised — not just recorded:

| Tariff component | Driver | M7 lever |
|---|---|---|
| **Energy charge (ToU)** | kWh × peak/shoulder/off-peak rate | shift load to off-peak (with M3) |
| **Demand charge** | max 15/30-min kVA × rate | peak-shave / stagger heavy loads |
| **Power-factor / kVA penalty** | PF below threshold | capacitor correction |
| **Fuel / gas charge** | GJ × price (± surcharge) | furnace efficiency, hot-charging |
| **Fixed / capacity** | contracted capacity | right-size the contract |
| **Carbon price / tax / credit** | tCO₂ × price | the carbon lever (parallel currency) |

**Demand management (manage the moment, don't pay for it).** The demand engine (§4) is operationalised here: M7 watches the **rolling maximum demand** against the contracted cap and the **historical monthly peak**, and raises a **peak-approach** alert with lead time to **shed or shift** load; it watches **power factor** against the penalty threshold and quantifies the correction; and it exposes the **ToU** clock so the shiftable share of load (and, via M3, the energy-intensive campaigns) is moved off-peak. In v1 these are *signals and decision support* off the bill and the manual/early-metered reads; the **automated demand-response / load-control** rung (act on the signal automatically) is the future-proofed full-EnMS target that lights up on the real-time metering interface (§5, §8).

**Carbon accounting (two-scope, steel-literal).** M7 derives carbon from the *same* consumption, in two scopes per the GHG Protocol, and reconciles to the steel-specific intensity standard:

```mermaid
flowchart LR
  CON["EnergyConsumption per carrier (GJ)"] --> S1["Scope 1: on-site combustion (furnace gas · DG fuel) x emission factor"]
  CON --> S2L["Scope 2 location-based: purchased electricity/steam x grid average factor"]
  CON --> S2M["Scope 2 market-based: x contractual/supplier factor (PPA/REC residual)"]
  S1 & S2L & S2M --> INT["Plant CO2 intensity tCO2 / t steel (ISO 14404 boundary)"]
  INT --> RANK["Carbon ranked alongside ₹ — the dual-currency waste register"]
  classDef s fill:#dbeafe,stroke:#2563eb;
  classDef i fill:#dcfce7,stroke:#16a34a;
  class S1,S2L,S2M s; class INT,RANK i;
```

- **Scope 1** — direct emissions from on-site **combustion**: the reheating-furnace gas, the captive-DG fuel. Computed from the carrier GJ × the combustion emission factor.
- **Scope 2** — indirect emissions from **purchased electricity and steam**, computed **both ways** per the GHG Protocol Scope 2 guidance: **location-based** (the grid average factor — physical grid reality) and **market-based** (the contractual factor — PPAs/RECs, with the residual-mix remainder). The two disagree by exactly the amount of the plant's clean-energy procurement — and M7 shows both so the claim is honest.
- **ISO 14404 intensity** — the steel headline: **tCO₂ per tonne** of crude/rolled steel, on the standard import/export boundary (Part 2 for EAF, Part 1 for blast furnace, Part 3 for EAF+DRI). M7 produces the universal-calculation-sheet inputs from the metered carriers, so the CO₂ statement is auditable, not estimated.
- **Scope 3** is a **future-proofed hook** (the `ghg_scope` enum carries it) — purchased-material and logistics emissions light up when that data connects, without a re-model.

**Defect/loss-aware energy (the embodied-energy view — the M7↔M5↔M6 seam).** Energy spent making material that is then scrapped or downgraded is **wasted twice** — the material *and* the energy that transformed it. M7 computes the **embodied energy of loss**: the kWh/GJ and kgCO₂e attributable (by the per-process SEC × the lost/defective quantity) to M5's yield loss and M6's defective/downgraded units. This is the figure that makes "a 2% yield loss" suddenly also "X GJ and Y tCO₂ of furnace gas burned for nothing" — and it ranks the yield/quality projects by their *energy-and-carbon* return, not just their material return.

**The financial story (per Principle 6 — money *and* carbon).** Energy is where the platform's Financial Impact Layer reframes a cost everyone treats as fixed into a **stack of managed, avoidable line items**. M7 prices, using `Tariff`/`CostRate` (D7, rate-as-of-event) and the emission factors: the **energy charge** (ToU), the **demand charge** (the managed peak), the **power-factor penalty**, the **fuel cost**, and the **carbon cost** — and exposes the **avoidable** share: **idle/standby energy** (running but not making, tied to M4's idle state), **compressed-air leaks and over-pressure**, the **demand-peak penalty** a few unmanaged moments set, the **PF penalty** a capacitor removes, the **off-baseline excess** the CUSUM caught, the **on-peak load** that could be off-peak, and the **embodied energy of scrap/downgrade**. This turns "energy is 25% of conversion cost and that's just the price of making steel" into "₹X/year of energy, of which ₹Y is avoidable waste removable by ₹Z of action, also cutting W tCO₂" — and ranks the energy register **by money and by carbon**, the version that changes the budget. M7's avoidable-waste € and M5's/M6's loss € are the *same* embodied energy, counted once (§12).

```mermaid
flowchart LR
  CON["Consumption (GJ) + demand + PF + carrier"] --> KPI["EnPI/SEC · absolute kWh/GJ · max demand · PF · CO2 intensity"]
  TAR["Tariff/CostRate: ToU · demand · PF penalty · fuel · carbon price"] --> COST["Energy cost engine"]
  KPI --> COST
  M5L["M5 loss qty · M6 defective (embodied energy)"] --> COST
  COST --> WASTE["Avoidable waste: idle energy · air leaks · demand peak · PF · off-baseline · embodied scrap (₹ + kgCO2e)"]
  KPI & WASTE --> REG["Shared KPI Registry (UIL, doc 03)"]
  REG --> MON["Monitoring: live load/demand tile + peak-approach / PF / baseline-excursion alerts"]
  REG --> REP["Reporting: energy report · EnPI/Sankey · ISO 50001 review · ISO 14404 CO2 statement"]
  REG --> SIB["M4 idle-energy · M5/M6 embodied energy · M3 ToU & demand headroom · M2 energy-signature"]
```

---

## 8. Predictive / ML — FUTURE SCOPE (architected now)

Forecasting load, *predicting* the demand peak, and *prescribing* the cheapest-and-cleanest energy choice is the operating-model's post-6-month → prescriptive horizon, **gated on accumulated interval history**. v1 is descriptive/diagnostic; we design so prediction is a switch-on.

| Capability | v1 | Future scope |
|---|---|---|
| Consumption | meter, normalise, EnPI, balance (descriptive) | **load & consumption forecasting** per SEU×grade from production plan & weather |
| Demand | track max-demand & PF vs cap (reactive signal off the bill / early meters) | **demand-peak forecasting + automated demand response / load control** — shed/shift *before* the peak sets (needs real-time metering) |
| Baseline variance | CUSUM excess signal (diagnostic) | **excess-consumption anomaly ML** — detect off-baseline drift automatically, attribute to SEU |
| Condition | energy-signature trend (diagnostic) | **energy-signature condition monitoring** — rising SEC / falling efficiency → fouled furnace / worn compressor / degrading motor (shared with M2 PdM) |
| Tariff / sourcing | ToU surface + DG-vs-grid view (decision support) | **prescriptive tariff & load optimisation** — optimal load schedule, DG-vs-grid dispatch, battery/storage, contract right-sizing |
| Design | SEC by grade (diagnostic) | **design-to-energy** — predicted SEC per route×grade → lowest-energy process choice (shared with M5 design-to-yield) |

**What v1 must get right so this is a switch-on, not a rebuild:** (a) **time-stamped consumption joined to production, state, grade, weather and tariff** from day one (the features and the objective); (b) **meter-calibration / comms-health status** on every stream (so the features are real, not meter noise — the §5 metering-fidelity gate); (c) **interval data where it exists** (the demand-response and anomaly models need sub-hourly, not monthly — which is exactly why the automatic-metering interface is future-proofed now); (d) a **prediction-readiness (History) gate** in the readiness model (§11) reporting per SEU×route when there is enough interval history to train. No prediction *promises* in v1 — only prediction *readiness*. M7's energy/demand prediction shares the platform's **one** ML-readiness substrate and model surface with **M2** (PdM), **M4** (loss), **M5** (yield) and **M6** (defect): the **energy-signature** that predicts a compressor failure (M7) *is* the condition signal M2 reads; a grade transition that predicts a yield-loss window (M5) and a defect-risk window (M6) is the *same* window that predicts an energy-intensity spike (M7) — **one** model surface, not five. The automated demand-response and tariff-optimisation rungs land on the §5 real-time metering interface.

---

## 9. Energy KPIs, analytics & financial/carbon impact

M7's contribution to the **shared KPI registry** (doc 03), all reconciled to the platform's **ISO 22400 / ISO 50006** definitions so no module disagrees.

| KPI | Formula | Meaning / target |
|---|---|---|
| **Specific Energy Consumption (SEC / EnPI)** | energy (GJ) ÷ output (t) | the headline intensity (target: ≤ benchmark GJ/t per process & grade) |
| **Normalised EnPI** | actual ÷ baseline-expected at current drivers | the real, volume-adjusted efficiency (ISO 50006) |
| **Energy performance improvement** | (baseline − actual) ÷ baseline, normalised | the ISO 50001 continual-improvement number |
| **Avoided energy (M&V)** | baseline-projected − actual (IPMVP) | verified saving (not naïve before/after) |
| **Absolute consumption** | Σ GJ / kWh per carrier × period | the cash & carbon exposure |
| **Energy cost per tonne** | energy ₹ ÷ output (t) | the per-tonne energy cost (ToU + demand + PF + fuel) |
| **CO₂ intensity** | tCO₂e ÷ output (t) | Scope 1+2, reconciled to ISO 14404 |
| **Maximum demand & load factor** | peak kVA; avg ÷ peak | demand exposure & how peaky the load is |
| **Power factor** | kW ÷ kVA | power-quality (target ≥ 0.95 to avoid penalty) |
| **Energy balance gap** | unmetered ÷ boundary energy | **metering coverage** (data-honesty, not waste) |
| **Avoidable energy waste** | idle + leaks + demand penalty + PF + off-baseline + embodied scrap | the ranked € + kgCO₂e target list |
| **Renewable / self-gen share** | (solar + recovered) ÷ total | decarbonisation progress |

**The financial & carbon story (per Principle 6).** Energy is the cost line that hides the most avoidable money *and* the most reducible carbon behind a single fixed-looking number. M7's Financial Impact contribution reframes it on two axes at once: it prices each tariff component and each avoidable-waste category in **₹** (rate-as-of-event, D7) *and* in **kgCO₂e**, and it ranks the saving register by both — because the cheapest action and the cleanest action diverge (off-peak grid power is cheap but may be dirtier than midday solar; captive DG can be cheaper than grid but is pure Scope 1). The **idle/standby energy** (tied to M4's idle minutes — the same downtime, now also an energy loss), the **compressed-air leak load**, the **demand-peak penalty**, the **PF penalty**, the **off-baseline excess** (CUSUM), and the **embodied energy of scrap/downgrade** (M5/M6) are each a line with a ₹ and a tCO₂ figure and an action owner. M7's avoidable-waste € and M5's/M6's loss € are the *same* embodied energy, counted once (§12). This is what turns "energy is just the price of steel" into a ranked, dual-currency, owner-assigned project backlog — the version that moves both the budget and the carbon number.

---

## 10. Sector-neutral model + Hero Steels instantiation

The model is **generic** and an instantiation makes it **concrete** — the same primitives (carrier/meter, consumption/balance, SEU/EnPI, baseline/M&V, demand/tariff, carbon) describe any plant; a sector template fills them in.

**Generic energy archetypes** (any sector): thermal-dominant (process heating leads — furnaces, kilns, boilers; gas/fuel is the big carrier) vs electricity-dominant (motor/drive systems lead — machining, assembly); the relevant-variable set (production volume always; weather for HVAC-heavy; product mix for multi-grade); the demand profile (peaky batch vs flat continuous); whether carbon is Scope-1-heavy (on-site combustion) or Scope-2-heavy (grid electricity).

**Hero Steels cold-rolling / re-rolling instantiation** (anchors the model to the real M1 plant; reuses the M1 manual reads, bills, fuel logs and COIL_NO genealogy it already captures):

| Energy concept | Generic | Hero Steels |
|---|---|---|
| Carriers | electricity + thermal + utilities | **grid electricity** (mill drives, utilities), **furnace gas/fuel** (reheating), **compressed air**, **water**, **captive DG** (backup/peak) |
| Dominant SEUs | process heating + motor systems | **reheating furnace** (process heating — the big GJ), **mill main & auxiliary drives** (motor systems — the big kWh), **compressed air** (hidden waste) |
| EnPI / SEC | energy ÷ output | **GJ/t furnace gas**, **kWh/t electricity**, plant **GJ/t**, per grade & per coil where genealogy allows |
| Relevant variables | production, weather, mix | throughput, **charge temperature (hot vs cold charging)**, grade mix, ambient |
| Baseline | regression over ≥12 mo | last year's furnace GJ vs tonnes & charge temp; mill kWh vs tonnes |
| Demand / tariff | ToU + demand + PF | utility **ToU**, **maximum-demand** charge, **power-factor** penalty, DG-vs-grid economics |
| Carbon | Scope 1 + 2 | Scope 1 (furnace gas, DG), Scope 2 (grid, location + market), **ISO 14404** rolled-steel intensity |
| Genealogy link | lot → energy | **COIL_NO**: energy apportioned/metered to the coil through reheat → roll → finish |
| Capture | manual / auto | v1 M1 reads + bills + fuel logs; future interval meters + furnace/air/water flow meters + SCADA |
| Benchmark | sector SEC | cold-charge ~1.75 GJ/t gas + ~90 kWh/t; best-practice hot-roll ~1.3 GJ/t (the improvement gap) |

**Reusing M1.** M1's manual meter readings become the consumption stream; M1's utility-bill entry becomes the tariff/demand/PF source and the regression-baseline history; M1's fuel/DG logs become the Scope 1 carrier; M1's COIL_NO genealogy is the lineage M7 uses to put energy on the right coil/grade through reheat → roll → finish. The **steel energy sector template** (seeded in Manifold, doc 02) carries the carrier set, the SEU register, the SEC EnPIs and relevant variables, the tariff shape, the emission factors and the ISO 14404 boundary — so the next steel client's energy lights up with no re-modelling. **D11 note:** because the core is sector-neutral, validating M7 on an **electricity-dominant discrete** client (motor-system-led, flat EnPI, Scope-2-heavy) exercises the *normalised-lens regression and demand engine* hard and retires the "only-tested-on-Hero-Steels" risk (R1/W1, doc 04) — the dual-lens design means M7 covers both the thermal-heavy furnace world and the electricity-heavy drive world from one engine.

---

## 11. Data contract & readiness (the M7 row)

M7's machine-readable data contract (the basis for Manifold's module-unlocking, doc 01 §15). ● Required · ○ Additional.

| Canonical entity / group | M7 need | Notes |
|---|:--:|---|
| **ProductionCount** (good/scrap/rework/total + weight) | ● | the EnPI **denominator** (shared with M4/M5/M6) |
| **Meter + MeterReading** (carrier, asset node, multiplier) | ● | *new M7 entity* — the metering spine (incl. manual bootstrap) |
| **EnergyConsumption** (carrier, GJ, basis, fidelity) | ● | *new M7 entity* — the energy SoR M7 brings to life |
| **EnergyCarrier + conversion/emission factors** | ● | *new M7 entity* — common-unit GJ + CO₂ factor (versioned) |
| Asset hierarchy (Site→Area→WorkCenter→WorkUnit) | ● | the metering & allocation tree |
| **Shift / Calendar** | ● | the period spine for EnPI & baseline windows |
| **Tariff / UtilityBill** (ToU, demand, PF, fuel) | ● | *new M7 entity* — pricing & the demand/PF source |
| StateInterval (running/idle/down, M4) | ○ | unlocks energy-by-state (idle-energy loss) — strongly recommended |
| Material / Grade + COIL_NO genealogy | ○ | unlocks per-grade / per-coil SEC and embodied-energy views |
| Weather (HDD/CDD, ambient) | ○ | the ISO 50006 normalisation variable — strongly recommended |
| M5 loss qty / M6 DefectRecord | ○ | unlocks embodied-energy-of-loss attribution |
| CostRate / carbon price | ○ | unlocks priced waste (₹ + carbon) — strongly recommended |

**New canonical/derived entities M7 introduces** (additive, per doc 01 §14 versioning rule): `EnergyConfig` (per-tenant policy: baseline method, normalisation drivers, demand window, reporting period, primary-vs-final convention), `EnergyCarrier` (carrier + GJ factor + default emission factor/scope), `Meter` (device, carrier, asset node, parent-meter, multiplier, calibration/comms health), `MeterReading` (raw/interval reading), `EnergyConsumption` (the canonical consumption fact — carrier, GJ, CO₂e, SEU/cost-centre, production/state link, basis, fidelity), `UtilityBill` (invoice decomposition), `Tariff` + `TariffPeriod` (ToU/demand/PF/fuel/carbon structure), `SEU` (significant-energy-use register), `EnpiDefinition` + `EnpiValue` (definition + computed actual/expected/variance), `EnergyBaseline` (the EnB regression model), `EnergyBalance` (per-carrier balance + gap), `DemandInterval` (max-demand & PF tracking), `EmissionFactor` + `EmissionEntry` (CO₂ factor + computed Scope 1/2), `EnergyCostEntry` (priced consumption), `EnergyTarget`, `PolicyChangeLog`, `ReadinessSnapshot`, `EnergyPrediction` (stub). The canonical model already carries the `Meter`/`MeterReading` scaffolding (doc 01 catalogued it for M2 condition meters); **M7 is the module that brings the energy side to life**. Like M6, M7 *does* own genuinely new transactional data (the consumption record and the meter), but it anchors every consumption row to the *one* shared `ProductionCount` / `StateInterval` for no-double-count.

**On-ramps to readiness** (capture-fidelity-aware, §5):

```mermaid
flowchart TD
  Q{"How is energy captured today?"}
  Q -- "M1 first-party reads + bills + fuel logs" --> M1B["Bootstrap: manual reads/bills -> consumption · regression baseline from a year of bills · apportion to SEU (v1, no hardware)"]
  Q -- "Existing EMS / utility portal / historian" --> ING["Manifold connector + energy sector template -> ingest meters/bills/tags"]
  Q -- "Automatic interval meters / SCADA / BMS" --> AUTO["Edge collectors (Modbus/IEC 61850/OPC-UA) -> 15-min sub-metered streams (future-proofed switch-on)"]
  Q -- "Nothing yet" --> FP["First-party energy capture (reuse M1 UX/RBAC) + portable meter campaign"]
  M1B & ING & AUTO & FP --> RDY["Readiness scoring (doc 01 §16): Required gate + Coverage + Fidelity(meter/calibration) + History"]
  RDY --> UNLOCK["Unlock: EnPI + balance + M&V + demand + carbon now · sub-metered/real-time when instrumented · forecast/DR when History gate passes"]
```

The readiness model is the platform's existing one (doc 01 §16) with **two M7-specific sub-gates**: a **Coverage/Fidelity gate** (what share of boundary energy is actually sub-metered vs apportioned? are the meters calibrated and comms-healthy? is the carrier-to-GJ/CO₂ factor set current? is the energy-balance gap small?) that drives the *confidence* shown beside every EnPI and CO₂ number (Principle 3/7), and a **prediction-readiness (History) gate** that reports when an SEU×route has enough interval history to train the §8 models. So the UI honestly shows "this furnace SEC is indicative (bill-apportioned, no sub-meter)" rather than a falsely precise figure.

---

## 12. Integration & boundaries

| Boundary | M7 owns | The other side owns | Shared artifact |
|---|---|---|---|
| **M7 ↔ M4 (OEE)** | the **energy drawn in each state** (productive vs idle/standby), the idle-energy loss | the machine **`StateInterval`** (running/idle/down) + run-time | the single `StateInterval` (M4 classifies the state, M7 attributes the energy to it) |
| **M7 ↔ M5 (Yield)** | the **embodied energy** of the lost material (kWh/GJ + CO₂e to make it) | *how much* material was lost & what it **cost** (material accounting) | the single `ProductionCount` loss qty (M5 accounts material, M7 attributes embodied energy) |
| **M7 ↔ M6 (Quality)** | the **embedded-energy waste** in defective/downgraded units | the good/defective split & disposition (`DefectRecord`) | the single `DefectRecord` (M6 classifies, M7 attributes embedded energy) |
| **M7 ↔ M3 (Planning)** | the **ToU cost surface + demand headroom** (when energy is cheap / how much demand is free) | the plan/route/sequence; the campaign | M7 publishes the cost/demand signal; M3 schedules; M7 never writes ops.* |
| **M7 ↔ M2 (Maintenance)** | the **energy-signature degradation** (rising SEC / falling efficiency) | the equipment condition/failure & work order | energy-signature → condition trigger; shared ML model surface |
| **M7 ↔ M1** | energy calculation, governance & the SoR | first-party capture of reads/bills/fuel-logs at source | `MeterReading`, `EnergyConsumption`, COIL_NO lineage |
| **M7 ↔ Manifold** | the M7 data contract + energy sector template | meter/SCADA/bill/historian connectors, field-mapping, readiness | sector template library |
| **M7 ↔ UIL** | EnPI/SEC, absolute consumption, ₹/t, CO₂/t, demand & PF status | cross-module synthesis (energy↔OEE↔yield↔quality↔plan↔cost), exec rollups | shared KPI registry |
| **M7 ↔ Monitoring** | live load/demand tile, peak-approach / PF / baseline-excursion alerts | live cache, alert delivery | streaming path |
| **M7 ↔ Financial Impact** | what to price (each tariff component & avoidable-waste category, ₹ + carbon) | the cost-rate/tariff engine & "rate-as-of" provenance (D7) | `Tariff` / `CostRate` |

The **lines to get right** are with M4, M5 and M6, and all follow one discipline: **the production/state/defect is recorded once by its owner; M7 reads it and lays energy on top.** A machine-state is one `StateInterval` — **M4 owns it** (running/idle/down), **M7 reads it** to split energy into productive vs idle/standby draw; M7 never recomputes the state, so the idle-energy loss is tied to the *same* minutes M4 already classified as downtime — one state truth, two costs (lost time *and* idle energy). A lost tonne is one `ProductionCount`/M5 loss — **M5 owns the material accounting**, **M7 attributes the embodied energy** already spent on it; the **embodied-energy € in M7's waste register *is* the energy component of M5's/M6's loss for the same units, counted once** (M7 reconciliation test: Σ M7 embodied-energy attributed to defect/loss-driven reasons == the energy spent on those `ProductionCount`/`DefectRecord` units; never re-priced as a *separate* loss from M5's material loss). An EnPI denominator is one `ProductionCount` — the *same* tonnes M4/M5/M6 use — so energy-per-tonne can never disagree with the production number underneath OEE, yield and quality. Neither double-counts. This single-truth discipline is the whole reason the platform can finally say, in one sentence with consistent numbers: *this coil took N minutes (M4), yielded M% (M5), graded prime/second (M6), and cost ₹X and Y kgCO₂ of energy (M7) — all off one production truth.*

---

## 13. RBAC & operations (brief)

Roles extend M1's model (Operator / Supervisor / Plant-Head / Admin) with energy-specific personas: **Operator / Utilities operator** (records manual meter reads & fuel logs, sees the live load/demand tile and the peak-approach alert for their area), **Shift Supervisor** (shift energy & intensity, demand & PF status, validates reads, acts on the load-shed/shift prompt), **Energy Manager / ISO 50001 lead** (configures carriers, meters, SEUs, EnPI definitions & targets, baselines and normalisation drivers; runs M&V; owns the energy review and the management-review pack), **Energy Engineer** (analyses SEU consumption, builds regression baselines, sizes corrections — capacitors, VFDs, leak fixes), **Sustainability / Carbon analyst** (Scope 1/2, location vs market, ISO 14404 intensity — read + factor config), **Cost / Finance analyst** (reads the priced energy waste — read-only), **Plant Manager** (energy trends, ₹ + CO₂, demand & baseline status; read-only analytics), **Admin** (masters, meter/connector integration, tariff & emission-factor config, energy policy). Because energy configuration (baselines, normalisation drivers, tariff structure, emission factors, carrier factors) directly moves the EnPI, cost and carbon numbers, **every policy change is audit-logged** with effective dating (ISO 50001 traceability), so an EnPI or CO₂ trend is never silently broken by a re-baseline or a factor revision, and a saving is always attributable to a baseline version. First-party/edge capture is **offline-tolerant** like M1 (queue local reads, sync on reconnect). The demand and EnPI engines run on the streaming path for the live tile (where automatic metering exists) and as scheduled rollups for the mart; recomputation is **deterministic and replayable** from the canonical readings (a corrected reading or re-versioned factor re-derives the affected consumption, EnPI, cost and CO₂ without manual patching — with the old baseline version preserved for audit). Row-level scoping by site/area as in M1. The energy SoR (consumption, bills, baselines, M&V results) is **append-only / audit-trailed** to satisfy ISO 50001 / ISO 14404 / GHG-assurance record-retention.

---

## 14. MVP migration bridge, build sequence & open decisions

**MVP migration bridge (target design + migration).** The operating model notes M7 **dashboards & insights are already built**. This plan describes the **target** M7 (the full-EnMS metering platform) against the canonical model; the existing build is the head-start, not the constraint. The bridge:

| Existing M7 today (dashboards + insights) | Target M7 | Migration path |
|---|---|---|
| kWh / energy totals from its own query or a direct bill/meter feed | Consumption from the **canonical EnergyConsumption** (one carrier-normalised truth) anchored to `ProductionCount` | repoint the calc onto `energy.*` consumption via the Serving API; keep the existing dashboards |
| Single "energy" number / electricity-only | full **multi-carrier** model (electricity + gas + steam + air + water) in **GJ + kgCO₂e**, balanced | add the carrier catalog + conversion/emission factors; map existing electricity into it; add the other carriers from bills/logs |
| Raw month-on-month comparison | **regression-normalised EnPI** + energy baseline + M&V | fit the baseline from existing bill history; switch reporting to normalised variance |
| Energy cost as one line | decomposed **tariff** (ToU + demand + PF + fuel) + **carbon** (Scope 1/2) | model the tariff; backfill demand/PF off the bill; add emission factors |
| Energy % in app code | energy KPIs in the shared **ISO 22400 / 50006 KPI registry** | move definitions into the registry so M4/M5/UIL read the same numbers; reconcile existing output (acceptance test) |
| Standalone energy dashboard | energy as a synthesised layer (UIL/Monitoring/Reporting/Financial) | publish consumption, EnPI, demand, carbon & cost to the canonical zone; the existing screen becomes one consumer |

The migration is **non-destructive and incremental**: the existing dashboards keep running while the calc is repointed to the canonical readings and the definitions move into the shared registry; the first acceptance gate is *"existing kWh / energy-cost / intensity figures and the canonical figures agree to tolerance on a back-test window, the energy balance closes within the metering-gap tolerance, and M7's embodied-energy reconciles to M5's loss and M6's defect for the same units."* No data is thrown away; existing meters and history are mapped forward.

**Suggested build order (bootstrap-first — closest to M1 & cheapest value, then up the fidelity/intelligence ladder):**

1. **Energy reference & policy + canonical wiring** — carrier catalog + conversion/emission factors, metering tree, SEU register, EnPI definitions, tariff structure, energy config; bring the canonical Meter/MeterReading/EnergyConsumption to life; repoint the existing dashboards onto `energy.*`.
2. **Consumption capture + balance + absolute lens** — manual reads/bills/fuel-logs → consumption in GJ + CO₂e, allocate down the tree, **close the energy balance** (name the gap), absolute consumption & cost per carrier/SEU/period (fastest first value).
3. **EnPI/baseline + normalised lens + M&V** — regression baseline from bill history, normalised EnPI/SEC per process & grade, CUSUM excess signal, IPMVP avoided energy; the M7↔M4 (energy-by-state) and M7↔M5/M6 (embodied energy) reconciliation tests.
4. **Demand, power-factor, carbon + cost + Monitoring board** — max-demand & PF tracking and peak-approach/PF alerts off the bill/early meters, ToU surface for M3; Scope 1/2 (location + market) + ISO 14404 intensity; priced waste (₹ + kgCO₂e); reporting pack incl. ISO 50001 management-review + CO₂ statement.
5. **Automatic interval metering / SCADA / BMS — switch-on (the full-EnMS reach)** — edge collectors (Modbus/IEC 61850/OPC-UA), 15-min sub-metered streams, true real-time demand & sub-metered M&V; meter device management; Coverage/Fidelity gate rises (no re-model).
6. **Prediction / ML (E7) — FUTURE, gated:** load/demand forecasting, excess-consumption anomaly ML, energy-signature condition monitoring, prescriptive tariff/load/DG optimisation & automated demand response when the History gate passes (shares the M2/M4/M5/M6 ML-readiness substrate & one model surface).

**Open decisions (need your call):**

- **Energy unit convention** — report in **GJ** primary-energy or final-energy (and the kWh↔GJ basis), and is the platform default **site** or **source/primary** energy?
- **Baseline method default** — start every client on a **simple SEC ratio** (GJ/t) and graduate to a **regression baseline** (ISO 50006 / IPMVP Option C) once ≥12 months of normalised data exist, or build the regression from day one where bill history allows?
- **Normalisation drivers** — the default relevant-variable set per EnPI (production volume always; add **weather (HDD/CDD)**? **charge temperature**? **grade mix**?) — which are in the v1 model?
- **Demand window & cap source** — **15-min or 30-min** maximum-demand window (utility-dependent), and is the contracted-demand cap a configured value or read from the bill/tariff?
- **Carbon scope in v1** — compute **Scope 1 + Scope 2 (both location and market)** now, with Scope 3 future-proofed — and which **emission-factor source** (national grid factor / supplier-specific / IEA) is the default?
- **ISO 14404 part** — which steel boundary applies to the first clients (**Part 1 blast furnace / Part 2 EAF / Part 3 EAF+DRI**) — Hero Steels is re-rolling, so confirm the boundary & whether crude-steel intensity is in scope or only rolling energy?
- **Allocation default** — when no sub-meter exists, apportion work-centre energy by **run-time**, **throughput (tonnes)**, or **connected load** — which is the default basis, and what energy-balance **gap tolerance** flags a coverage deficiency?
- **First metering connector** — which automatic source first for the switch-on on-ramp (a specific meter brand / SCADA historian / utility portal — ties to D4)?
- **Tariff / carbon pricing ownership** — who owns the **tariff structure and the carbon price** (energy manager / finance), and is carbon cost reported *inside* the energy waste register by default (recommended) or as a separate carbon view?
- **MVP reconciliation tolerance** — what back-test agreement (existing kWh / energy-cost / intensity within ε over a window, **energy balance closes within the gap tolerance**, *and* M7 embodied-energy == M5 loss energy == M6 defect energy) is the acceptance gate for repointing the existing dashboards onto canonical readings?
- **Prediction build gate** — what interval-history threshold per SEU×route flips it to "prediction-ready" (share the platform ML-readiness gate with M2/M4/M5/M6), and is automated **demand response** in scope once real-time metering exists or always operator-in-the-loop?
- **Second-sector validation (ties to D11)** — use M7 on an **electricity-dominant / discrete** client (motor-system-led, Scope-2-heavy, flat EnPI) to exercise the normalised-lens regression and the demand engine and retire the only-Hero-Steels risk?

---

### Sources (standards & product grounding)

- **EnMS backbone — energy review, SEU, EnB, EnPI, PDCA** — ISO 50001:2018 (energy management systems): [ISO 50001:2018](https://www.iso.org/standard/69426.html), [ISO 50001 implementation guide (Enity)](https://enity.io/en/blog-en/iso-50001-implementation-guide/), [ISO 50001 for manufacturing (oxmaint)](https://oxmaint.com/industries/manufacturing-plant/iso-50001-energy-management-system-manufacturing-guide), [EnPIs & baselines (nanoGrid)](https://www.nanogrid.com/blog/energy-management-system-iso-50001-enpis-energy-baselines), [50001 Ready Task 11 — EnPIs & baselines (LBNL)](https://navigator.lbl.gov/guidance/task/11)
- **EnPI & energy baseline method + normalisation** — ISO 50006 (measuring energy performance using EnB & EnPI): [ISO 50006:2014 (ISO)](https://www.iso.org/standard/51869.html), [ISO 50006 baseline & EnPI (EnerCoSS)](https://enercoss.com/iso-50006/), [ISO/DIS 50006 ed.2 (ISO OBP)](https://www.iso.org/obp/ui/#iso:std:iso:50006:dis:ed-2:v1:en:sec:3), [EMIS capabilities (US DOE FEMP)](https://www.energy.gov/cmei/femp/energy-management-information-system-capabilities)
- **Measurement & Verification (M&V) — avoided energy, options A/B/C/D, regression baseline** — IPMVP / ISO 50015: [IPMVP generally-accepted principles (EVO)](https://evo-world.org/images/corporate_documents/IPMVP-Generally-Accepted-Principles_Final_26OCT2018.pdf), [IPMVP volume I (2012)](https://www.eeperformance.org/uploads/8/6/5/0/8650231/ipmvp_volume_i__2012.pdf), [M&V option selection (BPA)](https://www.bpa.gov/-/media/Aep/energy-efficiency/measurement-verification/1-bpa-mv-selection-guide.pdf), [IPMVP measurement & verification (EnergyCAP)](https://www.energycap.com/energy-monitoring-software/features/ipmvp-energy-measurement-energy-verification/)
- **GHG accounting — Scope 1/2/3, location vs market-based** — GHG Protocol corporate standard + Scope 2 guidance: [GHG Protocol Scope 2 guidance (PDF)](https://ghgprotocol.org/sites/default/files/2023-03/Scope%202%20Guidance.pdf), [Scope 2 guidance overview (GHG Protocol)](https://ghgprotocol.org/scope-2-guidance), [location vs market-based (Sweep)](https://www.sweep.net/guides/location-vs-market-based-reporting), [electricity emissions accounting (Carbon Direct)](https://www.carbon-direct.com/insights/electricity-emissions-accounting-ghg-protocol-and-lca-explained)
- **Steel CO₂-emission intensity calculation** — ISO 14404 Parts 1–4 (blast furnace / EAF / EAF+DRI / guidance + universal calculation sheet): [ISO 14404-2:2024 EAF (ISO)](https://www.iso.org/standard/88111.html), [ISO 14404-1:2024 blast furnace (ISO)](https://www.iso.org/standard/88110.html), [ISO 14404-3:2017 EAF+DRI (ISO)](https://www.iso.org/standard/68430.html), [ISO 14404-4:2020 guidance (ISO)](https://www.iso.org/standard/77622.html)
- **Steel specific energy consumption (SEC) benchmarks** — GJ/t and kWh/t per process; hot vs cold charging; BAT reference: [steel energy consumption explained (oxmaint)](https://oxmaint.com/industries/steel-plant/energy-consumption-in-steel-plants-explained), [process-wise SEC breakdown (iFactory)](https://ifactoryapp.com/industries/steel-plant/sec-breakdown-process-energy-analytics), [reheating-furnace energy model (Scientific Reports)](https://www.nature.com/articles/s41598-025-95134-3), [UNIDO steel-sector benchmarking](https://www.unido.org/sites/default/files/files/2019-05/Benchmarking%20Report%20Steel%20Sector.pdf), [steel cost benchmarking (steelonthenet)](https://www.steelonthenet.com/methodology/steel-cost-benchmarking.html)
- **Demand management, time-of-use & power factor** — maximum demand (15/30-min), demand charge, peak shaving, ToU, PF/kVA correction: [demand charges & how to reduce them (Exro)](https://www.exro.com/industry-insights/demystifying-demand-charges), [peak demand charges (Vista Power)](https://www.vistapower.com/blog/peak-demand-charges-the-hidden-power-cost-and-how-batteries-fix-it), [maximum demand indicator (AllumiaX)](https://www.allumiax.com/blog/maximum-demand-indicator), [peak shaving (Socomec)](https://www.socomec.us/en-us/news/peak-shaving-reduce-electricity-costs-efficiently)
- **Significant Energy Uses & system assessments** — DOE Better Plants energy treasure hunt; compressed air / steam / motor / pump / fan systems; MEASUR: [DOE energy treasure hunt toolkit (ORNL)](https://energyefficiency.ornl.gov/wp-content/uploads/2019/01/US-DOE-Better-Plants-Program-Energy-Treasure-Hunt-Exchange-Toolkit.pdf), [DOE MEASUR tool](https://www.energy.gov/cmei/ito/measur), [compressed air systems (DOE)](https://www.energy.gov/eere/ito/compressed-air-systems), [Better Plants compressed air](https://www.airbestpractices.com/energy-manager/corporate-sustainability-programs/doe-better-plants-partners-get-serious-about-compressed-air-systems)
- **Metering architecture & protocols (how it's implemented on the ground)** — energy meters, submetering hierarchy, Modbus/DNP3/IEC 61850/OPC-UA/DLMS, SCADA/historian: [SCADA energy monitoring & protocols (IMD)](https://industrialmonitordirect.com/blogs/knowledgebase/scada-energy-monitoring-integrating-power-meters-via-modbus-dnp3-iec-61850), [IEC 61850 ↔ OPC-UA (OPC Foundation)](https://opcfoundation.org/markets-collaboration/iec61850/), [advanced power & energy meter (Accuenergy)](https://www.accuenergy.com/products/acuvim-ii-advanced-power-and-energy-meter/)
- **EMIS / energy-management software grounding (how it's implemented on the ground)** — real-time metering, dashboards, alarms, Sankey, power quality, energy modelling: [EcoStruxure Power Operation (Schneider)](https://www.se.com/us/en/product-range/65405-ecostruxure-power-operation/), [EcoStruxure Power Monitoring Expert (Schneider)](https://www.se.com/us/en/product-range/65404-ecostruxure-power-monitoring-expert/), [what is energy management software (nanoGrid)](https://www.nanogrid.com/blog/what-is-energy-management-software-types-features-benefits-explained), [energy monitoring platforms (MRI)](https://www.mrisoftware.com/blog/energy-monitoring-platforms-commercial-buildings/)
- **Energy KPI definitions** — ISO 22400-2 (energy per unit) reconciled to M4/M5/M6: [ISO 22400-2:2014](https://www.iso.org/standard/54497.html), [ISO 22400 KPI structure — quantities](https://connect981.com/blog-posts/iso-22400-kpi-structure-time-states-quantities)
- **Platform-internal** — `01_DataLake_and_Canonical_Model_DeepPlan.md` (canonical model, Event Spine, Meter/MeterReading §10, ISO 22400 quantities §9, §15 contract, §16 readiness), `02_Manifold_DeepPlan.md` (connectors, sector templates), `03_UnifiedIntelligence_and_OperationalMonitoring_DeepPlan.md` (KPI registry, monitoring), `04_Consolidated_Review_and_Traceability.md` (D4, D7, D11, R1/W1), `05_Reporting_Layer_DeepPlan.md`, `M4_OEE_Downtime_DeepPlan.md` (the shared `StateInterval` — energy by state / idle-energy loss), `M5_Yield_Intelligence_DeepPlan.md` (the shared loss quantity — embodied energy of loss; the mass-balance honesty M7's energy balance mirrors), `M6_Quality_Intelligence_DeepPlan.md` (the shared `DefectRecord` — embedded energy of defective/downgrade), `M3_Shopfloor_Planning_Management_DeepPlan.md` (the ToU/demand-aware scheduling signal), `M2_Maintenance_Intelligence_DeepPlan.md` (energy-signature condition monitoring; shared ML model surface), M1 Technical Blueprint (manual meter reads, bills, fuel/DG logs, COIL_NO genealogy, capture patterns)
