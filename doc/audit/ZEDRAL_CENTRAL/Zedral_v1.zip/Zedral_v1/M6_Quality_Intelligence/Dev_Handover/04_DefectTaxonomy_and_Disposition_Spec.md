# 04 · Defect Taxonomy & Disposition Spec
**Phase M6-1/2 · deep-plan §6**

## 1. Three-layer governed taxonomy (`defect_code`, self-referencing)

`parent_code_id` + `layer` (1–3): **Layer 1** category (6–8 max: Surface · Dimensional · Mechanical · Edge · Chemical · Other) → **Layer 2** type (15–25, filtered by parent) → **Layer 3** root-cause detail (optional small, required critical). Each leaf carries `criticality`, `default_disposition`, `loss_category_ref` (→ Six Big Losses / OEE component).

Design rules (shared with M4/M5 reason-tree discipline):
- 6–8 top categories; ≤ 15–20 types per level, filtered by parent.
- **Criticality on every code** (`CRITICAL`/`MAJOR`/`MINOR`, ISO 2859 classes) drives sampling, default disposition and whether Layer-3 detail is mandatory.
- Capture the **symptom** at log time; the **diagnosis** is CAPA's job (spec 05).
- Exactly **one governed "Other"** (`is_other_bucket = TRUE`); auto-prompt to split when it enters the Pareto top-3 or > ~10%.

## 2. The disposition model (`defect_record.disposition`)

| Disposition | Material outcome | Cost-of-Quality |
|---|---|---|
| `SCRAP` | `ProductionCount.scrap` (M5 prices pure/salvage) | internal failure |
| `REWORK` | `ProductionCount.rework` (M5 prices net of recovery) | internal failure (rework) |
| `DOWNGRADE` | grade change `from_grade_ref → to_grade_ref` + price delta | internal failure (margin loss) |
| `USE_AS_IS` | good, with concession record | appraisal / deviation |
| `RETURN_TO_SUPPLIER` | supplier debit | supplier/external failure |
| `PENDING` | awaiting MRB | — |

## 3. Grade-downgrade is first-class (the steel reality)

In metals the dominant disposition is **downgrade**, not scrap/rework: a flawed coil is reclassified prime → second/commercial and sold lower. M6 models it explicitly (`from_grade_ref`, `to_grade_ref`) so M5 prices the **margin loss** rather than mis-recording scrap. Flat defect-count systems miss this entirely.

## 4. Quality holds (containment, `quality_hold`)

Suspect material is placed on a hold (quarantine) — blocked from ship/plan until released or dispositioned. M6 **publishes** the hold/release event; M3 reads it for `QUALITY_HOLD` shift-handover carryover & MRP netting (spec 07). M6 never writes `ops.*`. **Hold ageing** is a monitored KPI (spec 06).

## 5. The canonical mapping (makes quality add up)

Every `defect_code` carries `loss_category_ref` + criticality + default disposition; the resulting `defect_record` carries the disposition's ISO 22400 quantity class (SQ/RQ) and OEE component (Quality, L5/L6). This is what lets M6's defect-driven Quality-loss **reconcile to M4's Quality factor** and lets **M5 attribute and price** the exact disposition (spec 06 §4). Seeded by the sector template, tunable per tenant.
