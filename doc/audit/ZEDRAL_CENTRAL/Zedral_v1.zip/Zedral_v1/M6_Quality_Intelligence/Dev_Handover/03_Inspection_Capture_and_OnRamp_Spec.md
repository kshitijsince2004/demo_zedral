# 03 · Inspection Capture, Genealogy & On-ramp Spec
**Phase M6-1 · deep-plan §5**

## 1. The control plan is the spine

Conformance is meaningless without **what to measure, where, how often, against what limit**. The control plan = `inspection_plan` (header, per work-unit/route) + `inspection_plan_item` (characteristic × sampling × reaction). This is the IATF-16949 bridge from PFMEA to the floor. Each item ties a `characteristic` to a `spec_limit` (the in/out-of-spec test) and a `sampling_basis`.

## 2. Two capture fidelities, one contract

| Fidelity (`capture_fidelity`) | Source | Contract rows |
|---|---|---|
| **MANUAL (v1)** | M1 inline checks (gauge readings), operator defect logging, entered lab/QC, slit/surface defects | `inspection` + `measurement` (variable) + `defect_record` (attribute) |
| **INGESTED** | existing QMS/LIMS/lab record via Manifold + quality sector template | same contract, mapped through review queue (D5) |
| **AUTOMATIC (future-proofed)** | inline thickness/flatness/width gauge; lab/spectrometer auto-feed; surface-vision encoder defect map | same contract, higher fidelity & frequency |

**None of the downstream engines change** between fidelities — only the fidelity, frequency and MSA confidence rise. The collector/sensor interfaces are specified here + spec 07 and built when a client instruments the line (the M4/M5 "switch-on" pattern; the CV path lands here per spec 08).

## 3. v1 bootstrap from M1 (cheapest first value)

Map M1's defect categories → `defect_code` (criticality + default disposition); treat entered gauge readings → `measurement` feeding SPC; attach entered lab results → `measurement` (mechanicals/composition); walk M1's **COIL_NO genealogy** (`canon.material_lot`) so a defect/disposition stays attached to the coil through slitting/annealing lineage. Computes full dual-lens conformance per process/coil/grade with **no new hardware**.

## 4. The MSA gate (data-honesty seam)

Before a measurement is trusted for SPC/capability, the **measurement system** must be trusted. `characteristic.msa_status` (+ `gage_rr_pct`) gates: an `UNACCEPTABLE` gage → SPC chart flagged low-confidence and **excluded from a published Cpk** (when `quality_config.msa_blocks_capability`); a chart showing stratification/mixture (Nelson rule) is flagged a possible measurement problem, not a process triumph. This is the quality analogue of M5's reconciliation-gap discipline.

## 5. Readiness on-ramps (`readiness_snapshot`, deep-plan §11)

Four gates: **Required** (is the control plan + spec + count present?), **Quality** (is the taxonomy governed — is "Other" runaway?), **Fidelity/MSA** (manual vs inline gauge? gage qualified? spec versioned?), **History** (enough labelled quality history per characteristic×route to train §8). The Fidelity/MSA gate drives the *confidence* shown beside every Cpk and defect number, so the UI honestly shows "Cpk indicative (gage unqualified, spot-sampled)" rather than a false precision.
