---
title: "Zedral · M6 Quality Intelligence — Developer Handover"
subtitle: "v1 for build · dual-lens conformance (ATTRIBUTE defect/disposition + VARIABLE measurement/SPC/capability) · governed defect taxonomy · NCR/MRB/CAPA · Cost of Quality"
date: "2026-06-19"
toc: true
toc-depth: 2
---

\newpage

# Zedral · M6 Quality Intelligence — Developer Handover
### 00 · Master Index, Architecture, Stack & Conventions
**Audience:** engineering team · **Status:** v1 for build (dual-lens conformance: ATTRIBUTE defect/disposition + VARIABLE measurement/SPC/capability; governed defect taxonomy; quality holds; NCR → MRB → disposition incl. grade-downgrade; CAPA/8D; Cost of Quality; auto-capture & prediction = interfaces only) · **Date:** 2026-06-19

> This is the build-ready specification set for **M6 · Quality Intelligence**, the platform's quality system-of-record and conformance module (the foundation layers — Data Lake, Canonical Model, Manifold, Unified Intelligence, Monitoring, Reporting, Financial Impact, Platform/Security — are specified in `../../Dev_Handover/`; sibling modules are in `../../M2_Maintenance_Intelligence/`, `../../M3_Shopfloor_Planning_Management/`, `../../M4_OEE_Downtime/`, `../../M5_Yield_Intelligence/`). Read this index first: module scope, the architecture, which **platform decisions (D1–D11)** bind M6, the **stack** M6 inherits, M6-specific conventions, and the **build roadmap**. The *why* behind every spec is the Quality deep-plan one level up: `../M6_Quality_Intelligence_DeepPlan.md`.

---

## 1. Document set & reading order

| # | Spec | Build priority |
|---|------|----------------|
| 00 | **This index** — architecture, stack, conventions, roadmap | Read first |
| 01 | **Data Model & Schema** — new quality entities, DDL dictionary (`qual_schema.sql`), the no-double-count anchor | Phase M6-0 |
| 02 | **Conformance, SPC & Capability** — chart families, WE/Nelson rules, Cp/Cpk/Pp/Ppk, ISO 22400 reconciliation | Phase M6-1/2 |
| 03 | **Inspection Capture, Genealogy & On-ramp** — control plan, capture fidelities, MSA gate | Phase M6-1 |
| 04 | **Defect Taxonomy & Disposition** — 3-layer codes, criticality, MRB disposition, grade-downgrade | Phase M6-1/2 |
| 05 | **NCR, CAPA & Aggregation Pipeline** — NCR/MRB workflow, 8D, events, rollup pipeline | Phase M6-2/3 |
| 06 | **KPIs, Analytics & Cost of Quality** — formulas + SQL, registry, M6↔M4 / M6↔M5 reconciliation, PAF | Phase M6-2/3 |
| 07 | **APIs, Events & Integration** — Serving APIs, published events, sibling contracts | Phase M6-2 |
| 08 | **Prediction / Future-scope Interfaces** — defect-risk, SPC-excursion, CV; the shared ML gate | Future |
| 09 | **Security, RBAC, NFRs & Acceptance** — roles, audit, NFRs, acceptance tests | All phases |
| 10 | **Glossary** | Reference |

---

## 2. Module scope (what M6 is, in one screen)

M6 is the **conformance-and-intelligence layer over a shared truth** — it consumes the canonical `ProductionCount` + measurements + defect events, and adds SPC, the governed defect taxonomy, disposition, CAPA and Cost of Quality. Unlike M4/M5 (pure thin-write), M6 **owns the conformance record** (`qual.defect_record`, `qual.inspection`, `qual.measurement`) — but anchors every row to the *one* shared `ProductionCount` so quality, yield and OEE never disagree.

**Two lenses (deep-plan §2, the M6 equivalent of M5's dual-basis):** the **VARIABLE** lens (measured characteristic → SPC → Cp/Cpk/Pp/Ppk — catches the *drift before* a defect) and the **ATTRIBUTE** lens (non-conformance → defect → disposition — catches the *reject event*). Both first-class.

**Non-goals (neighbouring modules/systems):** data capture itself (M1 owns first-party capture; M6 consumes canonical measurements/defects); **material accounting & economics** (M5 owns *how much* was lost and *what it cost* on the *shared* DefectRecord; M6 owns *why* it's bad and *what we decided*); the **OEE Quality factor** (M4 owns it on the *shared* ProductionCount; M6 supplies the defect taxonomy/disposition behind it); the plan/route/sequence (M3 — M6 *feeds* quality holds); the financial ledger (M6 *feeds* Financial Impact, doesn't own cost accounting). **Future-proofed interfaces only, not v1 build:** supplier-quality scorecards, audit management, document/training control (hooks present: `defect_source`, `policy_change_log`).

---

## 3. Architecture (engines & data flow)

```mermaid
flowchart LR
  SRC["M1 inline checks/defects/lab · ingested QMS/LIMS · inline gauge/vision (future)"] --> CAP["E2 Conformance Capture (MSA-aware)"]
  REF["E1 Quality Reference & Policy (characteristic·spec·control plan·taxonomy·SPC rules·COQ map)"] --> CAP
  CAP --> SPC["E3 SPC & Capability (charts·WE/Nelson·Cpk·signal)"]
  CAP --> DISP["E4 Defect·Hold·Disposition (classify·hold·NCR·MRB)"]
  SPC --> DISP --> CAPA["E5 CAPA / Root-cause (5-Why·fishbone·8D·verify)"]
  SPC & DISP & CAPA --> KPI["E6 KPI & Cost-of-Quality"]
  KPI --> CANON["Canonical zone + Serving"]
  CANON --> SIB["M4 Q-factor · M5 priced loss · M3 holds · UIL · Monitoring · Financial · Reporting"]
  PRED["E7 prediction / CV — FUTURE"] -. future .-> SPC
```

Engines map 1:1 to deep-plan §3. E7 (prediction/CV) is wired but dark (spec 08).

---

## 4. Platform decisions that bind M6 (D1–D11, doc 04)

- **D2** near-real-time minutes default → SPC tile & out-of-control alerts on the streaming path; capability recompute as scheduled rollup.
- **D5** conservative auto-map + review queue → defect-code & spec mapping from an ingested QMS goes through Manifold's review queue, never blind.
- **D6** "Standard" KPI tier → v1 publishes FPY, Quality-ratio, defect ppm, Cpk, COQ (descriptive/diagnostic); prediction later.
- **D7** cost-rates client-owned, "rate-as-of-event" → Cost of Quality prices against the rate effective at detection; internal-failure € is M5's priced loss (counted once).
- **D9** rules now / ML later → SPC run-rules & disposition rules are deterministic in v1; defect/excursion prediction is spec 08, gated.
- **D11** second-sector validation → exercise the VARIABLE lens & capability on a discrete/Cpk-led client (deep-plan §10).

---

## 5. Stack (inherited; no new infra)

Postgres (`qual` schema; OLTP conformance SoR — append-only NCR/CAPA), TimescaleDB/ClickHouse for measurement & SPC time-series and capability rollups, Kafka/Flink for the live SPC tile & alerts, Redis for the live cache, Airflow for scheduled capability recompute, FastAPI Serving APIs, React UI, Keycloak RBAC. Same as M4/M5 — M6 adds no new infrastructure.

---

## 6. M6-specific conventions

- **Schema `qual`** — not a reserved word (unlike M5's `"yield"`); no quoting needed.
- **DefectCode/DefectRecord are MASTERED here** (M6 is the SoR) but `defect_record` is **registered on the canonical Event Spine** (`event_id`) and anchored to `canon.production_count_id` — the no-double-count rule. M4/M5 read it via the Serving DefectRecord projection (spec 07), never by querying `qual.*` directly (golden rule).
- **Soft refs** (`route_ref` → M3 `ops.route`, equipment-condition → M2 `maint.work_order`) are plain BIGINT, no cross-schema FK. Hard FK only to `canon.*` and within `qual.*`.
- **SUM-then-divide** roll-ups (`v_quality_rollup`) — never average sub-ratios (the Simpson's-paradox trap, as in M4/M5).
- **MSA gate** — no published Cpk for an unqualified gage (deep-plan §5, `quality_config.msa_blocks_capability`).
- **Reconciliation is a CI test** — M6 Quality-loss == M4 Quality factor; M6 disposition material == M5 priced loss (spec 06 §4, spec 09).

---

## 7. Build roadmap

| Phase | Scope | Specs |
|---|---|---|
| **M6-0** | Quality reference & policy + canonical wiring (characteristic/spec/control-plan/taxonomy → criticality/disposition/LossCategory map); bring canonical DefectCode/DefectRecord to life; repoint existing dashboards onto `canon.*` | 01, 03, 04 |
| **M6-1** | Conformance capture + attribute conformance (inspection/measurement/defect from M1); FPY/Quality-ratio/defect-rate; **M6↔M4 reconciliation** | 02, 03, 04 |
| **M6-2** | SPC & capability (charts, WE/Nelson, Cpk, MSA-gated) + holds & disposition (incl. grade-downgrade); **M6↔M5 reconciliation** | 02, 04, 06 |
| **M6-3** | CAPA/8D + Cost of Quality (PAF; internal-failure == M5 loss, once) + Monitoring board + COA/MTC reporting | 05, 06, 07 |
| **M6-4** | Automatic capture (inline gauge/lab/vision) switch-on — Fidelity/MSA gate rises | 03, 07 |
| **Future** | Defect/SPC prediction + CV — gated on the shared ML-readiness History gate | 08 |


\newpage

# 01 · Data Model & Schema Spec
**Phase M6-0 · DDL:** `qual_schema.sql` (PostgreSQL 15+, `qual` schema, pglast-validated 53 statements)

## 1. Positioning — SoR, not thin-write

M5 and M4 are thin-write calc layers; **M6 is different — it is the quality system-of-record**, so it owns genuinely new transactional data: the conformance record (`inspection`, `measurement`, `defect_record`), the disposition (`quality_hold`, `nonconformance`), and the resolution (`capa`). What it does **not** re-record is the count: every `defect_record` carries the canonical `production_count_id` of the SAME `ProductionCount` that M4 (Quality factor), M3 (attainment) and M5 (priced loss) read. M6 **classifies and dispositions**; it never re-records a produced quantity.

The canonical `DefectCode`/`DefectRecord` scaffolding already exists in the canonical catalogue (doc 01 §10). M6 is the module that **brings the conformance side to life** and is the physical master of those Event-Spine specialisations (`qual.defect_code`, `qual.defect_record`), registered on `canon.event`.

## 2. Entity groups (see `qual_schema.sql`)

| Group | Tables | Role |
|---|---|---|
| **Reference & policy** | `quality_config`, `work_unit_config`, `characteristic`, `spec_limit`, `inspection_plan`, `inspection_plan_item`, `defect_code` | the specify layer — what to measure, against what limit, how to sample, the governed taxonomy |
| **Conformance capture** | `inspection`, `measurement` | executed inspection + the variable SPC input stream |
| **SPC** | `control_chart`, `spc_signal` | chart defn + limits + capability; special-cause violations |
| **Defect SoR & disposition** | `defect_record`, `quality_hold` | the bad-unit event + containment; carries disposition incl. grade-downgrade |
| **NCR / CAPA** | `nonconformance`, `ncr_defect_link`, `capa` | the case + MRB decision + the 8D root-cause-to-verified-closure |
| **Cost / targets / governance** | `coq_entry`, `quality_target`, `policy_change_log`, `readiness_snapshot`, `quality_prediction` | PAF pricing, targets, audit, readiness gates, the (dark) prediction stub |
| **Views** | `v_quality_rollup`, `v_coq_rollup` | SUM-then-divide conformance roll-up; PAF roll-up |

## 3. The no-double-count anchor (the critical invariant)

`defect_record.production_count_id` and `lot_ref` point at the **same** canonical rows M4 (Quality factor), M3 (attainment) and M5 (defect/loss) read. M6 **classifies + dispositions**; it never re-records a count. Therefore:
- M6's defect-driven Quality-loss **must equal** M4's Quality-factor loss by construction (same good/total, same ISO 22400 mapping) — spec 06 §4.
- Σ M6 disposition material (scrap+rework+downgrade) for defect-driven records **must equal** Σ M5 priced loss for those `DefectRecords` — spec 06 §4, M5 spec 06 §4.

## 4. Key column conventions

- IDs `BIGINT GENERATED ALWAYS AS IDENTITY`; `tenant_id UUID`; timestamps `TIMESTAMPTZ` (UTC); `ext JSONB` extension namespace; units in column names (`qty_mass_mt`, `gage_rr_pct`).
- **Hard FK only to `canon.*` and within `qual.*`.** Other modules are soft BIGINT `*_ref` (`route_ref` → M3 `ops.route`).
- **Versioning** — `spec_limit` and `inspection_plan` are versioned + effective-dated so a Cpk/conformance trend is never silently broken by a re-definition; every change is mirrored in `policy_change_log` (ISO 9001 traceability).
- **Append-only SoR** — `nonconformance`, `capa`, `defect_record` are audit-trailed (no destructive update of a dispositioned record; corrections create new rows / log entries).

## 5. Migration (target + bridge, deep-plan §14)

Existing M6 dashboards keep running; the calc is repointed onto `canon.production_count` + `qual.defect_record` via the Serving API; flat defect categories migrate as Layer-1/2 `defect_code` leaves (historical codes kept as aliases in `ext`); SPC limits seed from current data with an MSA status attached. **Back-test gate:** existing defect rate / FPY / disposition mix agree with canonical to tolerance on a back-test window, AND M6 Quality-loss == M4 Quality factor, AND M6 disposition == M5 priced loss (spec 09).


\newpage

# 02 · Conformance, SPC & Capability Spec
**Phase M6-1/2 · deep-plan §4**

## 1. Chart selection (the two lenses in code)

| Data | Subgroup | Chart (`control_chart.chart_type`) |
|---|---|---|
| variable | 2–~9 | `XBAR_R` (mean & range) |
| variable | ≥ ~10 | `XBAR_S` (mean & std-dev) |
| variable | individual (n=1, e.g. one coil) | `I_MR` (individual & moving range) |
| attribute | proportion / number defective | `P` / `NP` |
| attribute | defects per unit / area | `C` / `U` |

Hero Steels default: `I_MR` per coil for gauge; `P`/`U` for surface defect rate; capability on thickness per grade.

## 2. Run-rule sets (`spc_signal.rule_code`)

Ship **Western Electric** + **Nelson**, tenant-tunable subset (`quality_config.default_spc_rule_set`). Minimum rule pack:

| Rule | Trigger | Detects |
|---|---|---|
| WE1 | 1 point beyond 3σ | classic special cause |
| WE2 | 2 of 3 beyond 2σ (same side) | shift the limit misses |
| WE3 | 4 of 5 beyond 1σ (same side) | smaller shift |
| WE4 / Nelson | 8 (or 9) consecutive one side of centre | sustained shift |
| Nelson3 | 6–7 points steadily rising/falling | drift (tool wear, temp creep) |
| Nelson7/8 | 15 hugging centre / 8 avoiding it | stratification/mixture — **MSA red flag** |

A signal raises a `spc_signal` row and (via spec 07 events) a containment prompt — but only a **special cause** acts; common-cause variation must **not** trigger tampering (deep-plan Principle 4).

## 3. Process capability (`control_chart.cp/cpk/pp/ppk`)

| Index | Formula | Note |
|---|---|---|
| Cp | (USL−LSL)/6σ_within | spread only; process must be **in control** first |
| Cpk | min[(USL−μ), (μ−LSL)]/3σ_within | spread + centring (the one that matters) |
| Pp/Ppk | same, σ_overall | long-run performance |

Rules: compute **only for an in-control chart** (`in_control = TRUE`) and **only with `characteristic.msa_status IN ('ACCEPTABLE','MARGINAL')`** when `quality_config.msa_blocks_capability = TRUE` (else publish with low-confidence flag). Surface the **Cpk vs Ppk gap** as a between-subgroup-variation diagnostic. Targets: `cpk_target` (1.33) general, `cpk_target_critical` (1.67) for `criticality='CRITICAL'`.

## 4. Conformance metrics (ISO 22400-literal — agree with M4/M5 by construction)

From the *one* `canon.production_count`:
- **FPY** = good first-time ÷ started (== M5 FPY).
- **Quality Ratio** = good ÷ produced (**== M4 Quality factor**, the reconciliation invariant).
- **Scrap/Rework Ratio** = scrap or rework ÷ produced (== M5's loss accounting basis).
- **DPU** = defects ÷ units; **DPMO/ppm** = (defects ÷ (units × opportunities)) × 10⁶.

## 5. Sampling (`inspection_plan_item.sampling_basis`)

`FULL_100PCT` (critical / vision-automated), `AQL_2859` (lot-by-lot, `aql_pct` + critical/major/minor classes + inspection level), `FIXED_N` (e.g. one coupon/coil for mechanicals), `CONTINUOUS_SPC` (subgroup at a frequency). The plan is versioned reference data part of the control plan (spec 03).

## 6. Recompute & replay

SPC limits recomputed on a schedule (`limits_recalc_at`) or on demand after a process change; capability recomputed per rollup window. All recomputation is **deterministic & replayable** from `qual.measurement` + `canon.production_count` — a corrected measurement re-derives the affected chart, signals and Cpk without manual patching (deep-plan §13).


\newpage

# 03 · Inspection Capture, Genealogy & On-ramp Spec
**Phase M6-1 · deep-plan §5**

## 1. The control plan is the spine

Conformance is meaningless without **what to measure, where, how often, against what limit**. The control plan = `inspection_plan` (header, per work-unit/route) + `inspection_plan_item` (characteristic × sampling × reaction). This is the IATF-16949 bridge from PFMEA to the floor. Each item ties a `characteristic` to a `spec_limit` (the in/out-of-spec test) and a `sampling_basis`.

## 2. Two capture fidelities, one contract

| Fidelity (`capture_fidelity`) | Source | Contract rows |
|---|---|---|
| **MANUAL (v1)** | M1 inline checks (gauge readings), operator defect logging, entered lab/QC, slit/surface defects | `inspection` + `measurement` (variable) + `defect_record` (attribute) |
| **INGESTED** | existing QMS/LIMS/lab record via Manifold + quality sector template | same contract, mapped through review queue (D5) |
| **AUTOMATIC (future-proofed)** | inline thickness/flatness/width gauge; lab/spectrometer auto-feed; surface-vision encoder defect map | same contract, higher fidelity & frequency |

**None of the downstream engines change** between fidelities — only the fidelity, frequency and MSA confidence rise. The collector/sensor interfaces are specified here + spec 07 and built when a client instruments the line (the M4/M5 "switch-on" pattern; the CV path lands here per spec 08).

## 3. v1 bootstrap from M1 (cheapest first value)

Map M1's defect categories → `defect_code` (criticality + default disposition); treat entered gauge readings → `measurement` feeding SPC; attach entered lab results → `measurement` (mechanicals/composition); walk M1's **COIL_NO genealogy** (`canon.material_lot`) so a defect/disposition stays attached to the coil through slitting/annealing lineage. Computes full dual-lens conformance per process/coil/grade with **no new hardware**.

## 4. The MSA gate (data-honesty seam)

Before a measurement is trusted for SPC/capability, the **measurement system** must be trusted. `characteristic.msa_status` (+ `gage_rr_pct`) gates: an `UNACCEPTABLE` gage → SPC chart flagged low-confidence and **excluded from a published Cpk** (when `quality_config.msa_blocks_capability`); a chart showing stratification/mixture (Nelson rule) is flagged a possible measurement problem, not a process triumph. This is the quality analogue of M5's reconciliation-gap discipline.

## 5. Readiness on-ramps (`readiness_snapshot`, deep-plan §11)

Four gates: **Required** (is the control plan + spec + count present?), **Quality** (is the taxonomy governed — is "Other" runaway?), **Fidelity/MSA** (manual vs inline gauge? gage qualified? spec versioned?), **History** (enough labelled quality history per characteristic×route to train §8). The Fidelity/MSA gate drives the *confidence* shown beside every Cpk and defect number, so the UI honestly shows "Cpk indicative (gage unqualified, spot-sampled)" rather than a false precision.


\newpage

# 04 · Defect Taxonomy & Disposition Spec
**Phase M6-1/2 · deep-plan §6**

## 1. Three-layer governed taxonomy (`defect_code`, self-referencing)

`parent_code_id` + `layer` (1–3): **Layer 1** category (6–8 max: Surface · Dimensional · Mechanical · Edge · Chemical · Other) → **Layer 2** type (15–25, filtered by parent) → **Layer 3** root-cause detail (optional small, required critical). Each leaf carries `criticality`, `default_disposition`, `loss_category_ref` (→ Six Big Losses / OEE component).

Design rules (shared with M4/M5 reason-tree discipline):
- 6–8 top categories; ≤ 15–20 types per level, filtered by parent.
- **Criticality on every code** (`CRITICAL`/`MAJOR`/`MINOR`, ISO 2859 classes) drives sampling, default disposition and whether Layer-3 detail is mandatory.
- Capture the **symptom** at log time; the **diagnosis** is CAPA's job (spec 05).
- Exactly **one governed "Other"** (`is_other_bucket = TRUE`); auto-prompt to split when it enters the Pareto top-3 or > ~10%.

## 2. The disposition model (`defect_record.disposition`)

| Disposition | Material outcome | Cost-of-Quality |
|---|---|---|
| `SCRAP` | `ProductionCount.scrap` (M5 prices pure/salvage) | internal failure |
| `REWORK` | `ProductionCount.rework` (M5 prices net of recovery) | internal failure (rework) |
| `DOWNGRADE` | grade change `from_grade_ref → to_grade_ref` + price delta | internal failure (margin loss) |
| `USE_AS_IS` | good, with concession record | appraisal / deviation |
| `RETURN_TO_SUPPLIER` | supplier debit | supplier/external failure |
| `PENDING` | awaiting MRB | — |

## 3. Grade-downgrade is first-class (the steel reality)

In metals the dominant disposition is **downgrade**, not scrap/rework: a flawed coil is reclassified prime → second/commercial and sold lower. M6 models it explicitly (`from_grade_ref`, `to_grade_ref`) so M5 prices the **margin loss** rather than mis-recording scrap. Flat defect-count systems miss this entirely.

## 4. Quality holds (containment, `quality_hold`)

Suspect material is placed on a hold (quarantine) — blocked from ship/plan until released or dispositioned. M6 **publishes** the hold/release event; M3 reads it for `QUALITY_HOLD` shift-handover carryover & MRP netting (spec 07). M6 never writes `ops.*`. **Hold ageing** is a monitored KPI (spec 06).

## 5. The canonical mapping (makes quality add up)

Every `defect_code` carries `loss_category_ref` + criticality + default disposition; the resulting `defect_record` carries the disposition's ISO 22400 quantity class (SQ/RQ) and OEE component (Quality, L5/L6). This is what lets M6's defect-driven Quality-loss **reconcile to M4's Quality factor** and lets **M5 attribute and price** the exact disposition (spec 06 §4). Seeded by the sector template, tunable per tenant.


\newpage

# 05 · NCR, CAPA & Aggregation Pipeline Spec
**Phase M6-2/3 · deep-plan §7**

## 1. Nonconformance (NCR) & MRB (`nonconformance`, `ncr_defect_link`)

A `defect_record` (or a cluster, or an SPC special-cause signal) opens an **NCR** — the *case* that groups affected material (`ncr_defect_link`), records severity/scope, drives the **MRB disposition** (`mrb_decision` + `mrb_authoriser`), and triggers a CAPA when warranted. The NCR is the governed, audit-trailed record ISO 9001 cl. 8.7 requires. Routing: severities at/above `quality_config.mrb_severity_threshold` → full MRB; below → auto-disposition by `defect_code.default_disposition`.

## 2. CAPA / 8D (`capa`) — the recurrence-killer

A disposition fixes *this* material; a CAPA fixes the *process*. 8D stages map to columns:

| 8D | Column |
|---|---|
| D2 define | `title` |
| D3 containment | `containment_action` |
| D4 root cause | `rca_method` (`FIVE_WHY`/`FISHBONE`/`EIGHT_D`) + `root_cause` |
| D5/D6 corrective | `corrective_action` |
| D7 preventive + loop-back | `preventive_action` + `fmea_updated` |
| D8 verify | `effectiveness_verified` (gate to `status='CLOSED'`) |

Rules: **corrective ≠ preventive** (both tracked to `owner` + `due_at`); fishbone 6M *Machine* leg links to **M2** (equipment condition), *Measurement* leg to M6's MSA; **effectiveness verification is mandatory** — a CAPA is not closed until the metric (defect rate, Cpk, ppm) improves over a verification window. **Recurrence rate** & **cycle time** are KPIs (spec 06) — high recurrence ⇒ root causes guessed, not found. A verified CAPA updates the FMEA/control plan (`fmea_updated`) — the loop back to stage 1 of the quality loop.

## 3. Aggregation pipeline (events → mart)

```
measurement / defect_record / disposition (canonical events)
   → streaming: live SPC tile, out-of-control & defect-rate alerts (Flink, D2)
   → scheduled rollup: v_quality_rollup (FPY/ppm/disposition mix), capability recompute, v_coq_rollup
   → Serving APIs + KPI registry (spec 07)
```

Rollups are **SUM-then-divide** (`v_quality_rollup`) — never average sub-ratios. All rollups are **deterministic & replayable** from canonical events (deep-plan §13): a re-coded defect or corrected measurement re-derives the affected charts, dispositions and COQ.

## 4. Defect intelligence slices

Serve defect rate / ppm / Cpk / disposition mix by **defect type, step, grade, route, work-unit, shift, crew, and supplier lot** (the supplier-defect spread pre-stages the future scorecard). Pareto by **count and by cost** (they rank differently — a rare premium-grade downgrade can outweigh a common minor scratch); the executive list is ranked by money (spec 06).


\newpage

# 06 · KPIs, Analytics & Cost of Quality Spec
**Phase M6-2/3 · deep-plan §9**

## 1. KPI registry contributions (ISO 22400-reconciled)

| KPI | Formula | Source |
|---|---|---|
| First-Pass Yield | good first-time ÷ started | `canon.production_count` (== M5 FPY) |
| **Quality Ratio** | good ÷ produced | **== M4 Quality factor** (invariant) |
| Defect rate / DPU | defects ÷ units | `v_quality_rollup` |
| DPMO / ppm | (defects ÷ (units×opportunities))×10⁶ | `v_quality_rollup` |
| Cp/Cpk/Pp/Ppk | per characteristic | `control_chart` (target ≥1.33; critical ≥1.67) |
| % time in control | in-control subgroups ÷ total | `spc_signal` density |
| Disposition mix | scrap/rework/downgrade/use-as-is share | `v_quality_rollup` |
| Hold ageing | open holds by age | `quality_hold` |
| CAPA cycle time / recurrence | days to verified close; % recurring | `capa` |
| Right-First-Time | no defect & no rework ÷ total | derived |
| Cost of Quality | P + A + IF + EF | `v_coq_rollup` |

## 2. Cost of Quality — the PAF model (`coq_entry`, deep-plan §9)

Four buckets (`coq_category`): **Prevention** (FMEA, control plans, capable processes), **Appraisal** (inspection effort), **Internal Failure** (scrap/rework/downgrade — **priced via M5's loss bridge**, `is_from_m5_loss = TRUE`), **External Failure** (returns/claims/warranty — `defect_source='CUSTOMER'`). Priced with `canon.cost_rate` (D7, rate-as-of-detection). Exposes the **1-10-100** asymmetry (prevent ≪ internal fix ≪ external escape) and the **~15–20% of revenue** total. Output: "₹X/year COPQ, of which ₹Y removed by ₹Z prevention", Pareto & CAPA backlog ranked **by money**.

## 3. Reconciliation (the two CI tests, the discipline of the platform)

| Test | Assertion |
|---|---|
| **M6 ↔ M4** | M6 defect-driven Quality-loss == M4 Quality-factor loss (same good/total, same ISO 22400 mapping) |
| **M6 ↔ M5** | Σ M6 disposition material (scrap+rework+downgrade) for defect-driven records == Σ M5 priced loss for those DefectRecords; **the internal-failure € in COQ *is* M5's priced loss, counted once** |

Both run in CI (spec 09). They are the reason the platform can end the "quality says 3% defects, production says 96% good, finance says 4% scrap" argument: one defect truth, dispositioned once, priced once.

## 4. Steel reporting extras

Defect Pareto, control charts, COQ report, and the **certificate of analysis / mill test certificate** per shipped coil (characteristics + measured values + disposition + defect map), generated from `inspection`/`measurement`/`defect_record` joined on COIL_NO.


\newpage

# 07 · APIs, Events & Integration Spec
**Phase M6-2 · deep-plan §0, §12**

## 1. Serving APIs (read-heavy; versioned)

| API | Returns |
|---|---|
| `GET /quality/conformance?scope&grain` | FPY, Quality-ratio, defect rate/ppm, disposition mix |
| `GET /quality/spc/{characteristic}?work_unit&grade` | control chart (limits, points), signals, Cp/Cpk/Pp/Ppk + MSA status |
| `GET /quality/defects?scope&by=type|step|grade|supplier` | governed defect Pareto (count & cost) |
| `GET /quality/holds?status` | open/aged quality holds |
| `GET /quality/ncr/{id}` · `GET /quality/capa?status` | NCR/MRB record; CAPA backlog & recurrence |
| `GET /quality/coq?period` | PAF buckets, COPQ, prevention ROI |
| `GET /quality/certificate/{lot}` | certificate of analysis / mill test certificate |

## 2. Published events (others subscribe; M6 never writes their tables)

| Event | Consumer | Use |
|---|---|---|
| `quality.hold.opened` / `.released` | **M3** | `QUALITY_HOLD` handover carryover + MRP netting |
| `quality.defect.recorded` (with disposition) | **M5** | attribute & price the material loss |
| `quality.spc.signal` | Monitoring | out-of-control alert; containment prompt |
| `quality.capa.opened` / `.closed` | UIL / Monitoring | overdue-CAPA board, recurrence trend |
| `quality.coq.updated` | Financial Impact / UIL | COQ rollup, prevention-ROI |

## 3. Consumed (via canonical Serving APIs / Event Spine — golden rule)

`canon.production_count` (the shared count — conformance denominator); `canon.material_lot` genealogy (COIL_NO); `canon.material` (grade); `canon.cost_rate` (D7); **M5** priced internal-failure loss (for COQ, counted once); **M4** quality-loss-minutes context; **M2** equipment-condition link (`defect_record` ↔ `maint.work_order`, soft ref) for equipment-attributable defects; **M1** first-party measurements/defects.

## 4. The shared-truth contract (deep-plan §12)

M4/M5 read M6's `DefectRecord` through the **Serving DefectRecord projection**, never by querying `qual.*` directly. The bad unit is recorded once (`defect_record.production_count_id` = the canonical count); M6 classifies & dispositions, M4 reads the Quality factor, M5 prices the loss. No module writes another's tables; everything moves through canonical entities + versioned Serving APIs.

## 5. Manifold integration

M6 ships a **quality sector template** (steel surface/dimensional/mechanical characteristics, spec limits, control plan, defect catalog incl. grade-downgrade rules, sampling plan) seeded in Manifold. Ingested QMS/LIMS/lab fields map through the field-mapping engine + review queue (D5); readiness/unlock per doc 01 §16.


\newpage

# 08 · Prediction / Future-scope Interfaces Spec
**Status: FUTURE SCOPE (architected now, build deferred) · deep-plan §8**

## 1. What is deferred

| Capability | v1 (now) | Future |
|---|---|---|
| Defect level | classify, disposition, Pareto, price | **defect-risk prediction** per route×grade from process params & incoming certs |
| SPC | charts, rules, capability (reactive signal) | **SPC-excursion forecasting** — predict the breach *before* it happens (drift extrapolation) |
| Surface inspection | manual / logged defects | **automated visual-defect classification (CV)** — encoder-located map, type/severity, auto-disposition |
| Incoming material | defect-by-supplier-lot (diagnostic) | **incoming-quality prediction** from lot certificates (shared with M5 incoming-yield) |
| Decision support | SPC + Pareto + alerts | **prescriptive** ("adjust setpoint to avoid drift"); auto-CAPA suggestion from similar past cases |

## 2. The stub (`quality_prediction`)

Present, `is_active = FALSE` (dark) until the History gate passes. Holds predicted defect ppm per characteristic×work-unit×grade + model version + horizon. No write path in v1.

## 3. Why v1 makes this a switch-on, not a rebuild

(a) **labelled measurements & defect records with verified root causes** from day one (the training labels — why CAPA D8 verification matters beyond compliance); (b) **MSA-qualified measurement streams** (real features, not gage noise); (c) defect records **joined to genealogy, grade, process params, supplier lot and cost** (features + objective); (d) the **History readiness gate** per characteristic×route.

## 4. One shared model surface (not four)

M6's defect/SPC prediction shares the platform's **one** ML-readiness substrate and model surface with **M2** (PdM), **M4** (loss) and **M5** (yield): a grade transition that predicts a yield-loss window (M5) *and* a defect-risk window (M6) is **one** model surface; the *Machine* leg of a fishbone that predicts a roll-mark defect (M6) is the same condition signal that predicts the roll failure (M2). The CV/vision path lands on the spec 03 automatic-capture interface. Build only when the shared History gate is green for the target characteristic×route (D9).


\newpage

# 09 · Security, RBAC, NFRs & Acceptance Spec
**All phases · deep-plan §13**

## 1. RBAC (extends M1 Operator/Supervisor/Plant-Head/Admin)

| Role | Can |
|---|---|
| Operator / Inspector | record inline checks & measurements, log defects, see live SPC tile + reaction plan |
| Shift Supervisor | shift quality, defect Pareto, validate defect coding, raise/clear holds within authority |
| Quality Engineer | configure characteristics, spec limits, control plan, taxonomy, SPC rule-sets, sampling; run SPC/capability; chair routine disposition |
| MRB member | authorise non-routine dispositions (incl. downgrade/use-as-is) |
| CAPA owner / Quality Manager | own root-cause cases to verified close; manage CAPA backlog; read COQ |
| Cost / Finance analyst | read priced Cost of Quality (read-only) |
| Plant Manager | quality trends, COQ, hold/CAPA status (read-only) |
| Admin | masters, integration, capture/MSA config, quality policy |

## 2. Audit & record integrity (ISO 9001 / IATF 16949)

Every policy change (spec limit, control limit, disposition rule, taxonomy) is **audit-logged** with effective dating (`policy_change_log`) so a Cpk/defect trend is never silently broken by a re-definition, and every disposition is attributable to an authoriser. NCR/MRB/CAPA and `defect_record` are **append-only / audit-trailed** for record retention. Row-level scoping by site/area (RLS) as in M1. First-party/edge capture is **offline-tolerant** (queue locally, sync on reconnect).

## 3. NFRs

- **Latency** — live SPC tile & out-of-control alert near-real-time (D2, minutes default); capability recompute scheduled.
- **Determinism/replay** — recompute twice ⇒ identical charts/dispositions/COQ; corrected events re-derive without manual patching.
- **Scale** — measurement & SPC time-series on Timescale/ClickHouse; defect-Pareto heatmaps load-tested.
- **Isolation** — logical tenant isolation default, physical on request (D8).

## 4. Acceptance tests (MUST)

1. **No-double-count** — `defect_record.production_count_id` always references a canonical count; no produced quantity re-recorded.
2. **M6 ↔ M4 reconciliation** — M6 defect-driven Quality-loss == M4 Quality factor on a golden dataset (CI).
3. **M6 ↔ M5 reconciliation** — Σ M6 disposition material == Σ M5 priced loss for the same DefectRecords (CI).
4. **MSA gate** — an `UNACCEPTABLE` gage suppresses published Cpk (or flags low-confidence per config).
5. **SPC correctness** — WE/Nelson rules raise the right `spc_signal` on a seeded out-of-control series; common-cause noise raises none.
6. **Disposition integrity** — every non-conformance reaches exactly one disposition; downgrade carries from/to grade.
7. **CAPA closure gate** — a CAPA cannot close without `effectiveness_verified = TRUE`.
8. **Hold → M3** — `quality.hold.opened` produces a `QUALITY_HOLD` carryover.
9. **Back-test (MVP gate)** — existing defect rate / FPY / disposition mix agree with canonical to tolerance on a back-test window.
10. **RLS/security** — cross-tenant/site access denied.

**Golden dataset:** a Hero Steels shift with known coils, measurements (thickness/hardness), surface defects, and dispositions (incl. a prime→second downgrade) by COIL_NO.

## 5. Acceptance — SHOULD

Pareto-by-cost ranks above Pareto-by-count where they differ; "Other" auto-split prompt fires at threshold; certificate-of-analysis renders per coil; CAPA recurrence-rate KPI computes.


\newpage

# 10 · Glossary

- **Quality Intelligence (M6)** — the platform's conformance-and-intelligence layer & quality system-of-record: SPC, defect taxonomy, disposition, CAPA, Cost of Quality over the *shared* ProductionCount/DefectRecord.
- **Two lenses** — VARIABLE (measured characteristic → SPC → capability; catches drift) and ATTRIBUTE (non-conformance → defect → disposition; catches the reject). Equal-weight, per scoping.
- **Characteristic** — a measurable (variable) or observable (attribute) quality property, with criticality and MSA status.
- **Spec limit** — versioned nominal/USL/LSL per characteristic×grade; defines "in spec."
- **Control plan / Inspection plan** — what to measure, where, how often, against what limit, with what reaction (PFMEA → control plan).
- **SPC** — Statistical Process Control: control charts (X̄-R, X̄-s, I-MR variable; p, np, c, u attribute) + run rules (Western Electric / Nelson).
- **Special vs common cause** — assignable variation (act) vs inherent noise (do not tamper).
- **Capability (Cp/Cpk/Pp/Ppk)** — can the (in-control) process meet spec? Cpk = spread + centring; Ppk uses long-run σ.
- **MSA / Gage R&R** — Measurement System Analysis: is the measurement trustworthy enough to chart? Gates published Cpk.
- **DefectCode / DefectRecord** — the governed taxonomy / the conformance event (Event-Spine specialisation mastered by M6, anchored to the canonical ProductionCount).
- **Disposition** — the decision for non-conforming material: scrap / rework / **downgrade** / use-as-is / return-to-supplier.
- **Downgrade** — reclassify prime → second/commercial grade (the dominant metals disposition); priced as margin loss.
- **Quality hold** — quarantine on a lot/coil; blocks ship/plan; → M3 `QUALITY_HOLD` carryover.
- **NCR / MRB** — Nonconformance Report / Material Review Board: the governed case + disposition authority (ISO 9001 cl. 8.7).
- **CAPA / 8D** — Corrective And Preventive Action via Ford's 8 Disciplines (D0–D8); 5-Why + fishbone (Ishikawa 6M); effectiveness verification mandatory.
- **Cost of Quality (PAF)** — Prevention + Appraisal + Internal Failure + External Failure; ~15–20% of revenue; 1-10-100 rule.
- **COPQ** — Cost of Poor Quality = Internal + External failure (the invisible cost M6 makes visible).
- **AQL / ISO 2859-1** — Acceptance Quality Limit sampling by attributes; critical/major/minor classes.
- **FPY / Quality Ratio** — first-pass yield; good ÷ produced (== M4 Quality factor by construction).
- **Certificate of analysis / mill test certificate** — per-coil quality document (characteristics + values + disposition + defect map).
- **No-double-count anchor** — `qual.defect_record.production_count_id` = the SAME canonical count M4/M5 read; classified once, dispositioned once, priced once.
- **Reconciliation tests** — M6 Quality-loss == M4 Quality factor; M6 disposition material == M5 priced loss (CI).
- **Sector template** — Manifold-seeded steel quality pack (characteristics, specs, control plan, defect catalog, sampling) for low-touch onboarding.
- **Readiness gates** — Required / Quality / Fidelity(MSA) / History (the last gates §8 prediction).
- **D1–D11** — platform decisions (doc 04) binding M6: esp. D2 latency, D5 auto-map review, D6 KPI tier, D7 cost-rate-as-of, D9 rules-now/ML-later, D11 second-sector validation.


\newpage

# Appendix A · Reference Schema (qual_schema.sql)

```sql
-- =====================================================================
-- Zedral · M6 Quality Intelligence — Reference Schema (PostgreSQL 15+)
-- Status: v1 for build (dual-lens conformance: ATTRIBUTE defect/disposition
--         + VARIABLE measurement/SPC/capability; governed defect taxonomy;
--         quality holds; NCR -> MRB -> disposition incl. grade-downgrade;
--         CAPA/8D root cause; Cost of Quality P/A/IF/EF). v1 bootstraps from
--         M1 manual inline checks / defect logging / entered lab results;
--         inline gauge / lab / surface-vision future-proofed (deep-plan §5).
--         Prediction & visual-defect hooks present, build deferred (§8).
-- Conventions: follows canonical DDL spec (02_CanonicalDataModel_Spec §5):
--   lower_snake_case · surrogate BIGINT ids · UUID tenant_id · TIMESTAMPTZ (UTC)
--   JSONB `ext` extension namespace · FK to canon.* · units embedded in column name.
-- Assumes the canonical core already exists:
--   canon.equipment_node(node_id)      -- ISA-95 hierarchy incl. WORK_CENTER & WORK_UNIT
--   canon.event(event_id)              -- Event Spine; defect_record specialises it
--   canon.production_count(count_id)   -- good/scrap/rework/total (+ weight) — the shared count
--   canon.material_lot(lot_id, parent_lot_id) -- genealogy spine (M1 COIL_NO)
--   canon.material(material_id)        -- material/grade reference (grade = material variant)
--   canon.shift(shift_id)              -- shift/calendar
--   canon.loss_category(category_id, oee_component) -- Six Big Losses (ISO 22400/TPM)
--   canon.cost_rate(rate_id ...)       -- effective-dated rates (D7)
-- OWNERSHIP NOTE: M6 is the quality system-of-record, so DefectCode and
--   DefectRecord physically live in and are MASTERED by this `qual` schema
--   (unlike M4/M5 which are pure thin-write). defect_record is REGISTERED on the
--   canonical Event Spine via event_id and anchored to the SAME canon.production_count
--   that M4 (Quality factor) and M5 (priced loss) read — so the bad unit is recorded
--   ONCE. M5 spec 06 §4 reads qual.defect_record's disposition through the Serving API.
-- SOFT-REFERENCE RULE: references to OTHER module schemas (e.g. ops.route in M3,
--   maint.work_order in M2) are plain BIGINT *_ref values with NO cross-schema hard
--   FK, so canon/M6 stay independent. Hard FKs are used ONLY to canon.* and within qual.*.
-- THE no-double-count anchor: qual.defect_record.production_count_id is the canonical
--   ProductionCount; M6's defect-driven quality loss == M4 Quality factor (same good/total)
--   and == M5 priced loss (same DefectRecords) by construction.
-- =====================================================================

CREATE SCHEMA IF NOT EXISTS qual;
SET search_path = qual, canon, public;

-- ---------------------------------------------------------------------
-- 0. Enumerated types
-- ---------------------------------------------------------------------
CREATE TYPE qual.lens               AS ENUM ('VARIABLE','ATTRIBUTE');
CREATE TYPE qual.criticality        AS ENUM ('CRITICAL','MAJOR','MINOR');
CREATE TYPE qual.msa_status         AS ENUM ('NOT_ASSESSED','ACCEPTABLE','MARGINAL','UNACCEPTABLE');
CREATE TYPE qual.defect_source      AS ENUM ('IN_PROCESS','FINAL','INCOMING','SUPPLIER','CUSTOMER');
CREATE TYPE qual.disposition_type   AS ENUM ('PENDING','SCRAP','REWORK','DOWNGRADE','USE_AS_IS','RETURN_TO_SUPPLIER','ACCEPT');
CREATE TYPE qual.hold_status        AS ENUM ('OPEN','RELEASED','DISPOSITIONED','EXPIRED');
CREATE TYPE qual.ncr_status         AS ENUM ('OPEN','IN_MRB','DISPOSITIONED','CLOSED');
CREATE TYPE qual.capa_status        AS ENUM ('OPEN','CONTAINMENT','ROOT_CAUSE','CORRECTIVE','VERIFICATION','CLOSED','CANCELLED');
CREATE TYPE qual.rca_method         AS ENUM ('FIVE_WHY','FISHBONE','EIGHT_D','FMEA','OTHER');
CREATE TYPE qual.control_chart_type AS ENUM ('XBAR_R','XBAR_S','I_MR','P','NP','C','U');
CREATE TYPE qual.spc_rule_set       AS ENUM ('WESTERN_ELECTRIC','NELSON','CUSTOM');
CREATE TYPE qual.coq_category       AS ENUM ('PREVENTION','APPRAISAL','INTERNAL_FAILURE','EXTERNAL_FAILURE');
CREATE TYPE qual.sampling_basis     AS ENUM ('AQL_2859','FULL_100PCT','FIXED_N','CONTINUOUS_SPC');
CREATE TYPE qual.capture_fidelity   AS ENUM ('MANUAL','INGESTED','AUTOMATIC');
CREATE TYPE qual.readiness_gate     AS ENUM ('REQUIRED','QUALITY','FIDELITY','HISTORY');
CREATE TYPE qual.time_grain         AS ENUM ('SHIFT','DAY','WEEK','MONTH');
CREATE TYPE qual.inspection_result  AS ENUM ('PASS','FAIL','PASS_WITH_DEVIATION');
CREATE TYPE qual.rank_basis         AS ENUM ('COUNT','COST');

-- ---------------------------------------------------------------------
-- 1. Quality reference & policy
-- ---------------------------------------------------------------------

-- 1.1 Per-tenant quality policy (definitions-as-configuration)
CREATE TABLE qual.quality_config (
    config_id              BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id              UUID         NOT NULL,
    default_spc_rule_set   qual.spc_rule_set NOT NULL DEFAULT 'WESTERN_ELECTRIC',
    cpk_target             NUMERIC(4,2) NOT NULL DEFAULT 1.33,   -- general capability floor
    cpk_target_critical    NUMERIC(4,2) NOT NULL DEFAULT 1.67,   -- floor for CRITICAL characteristics
    msa_blocks_capability  BOOLEAN      NOT NULL DEFAULT TRUE,    -- unqualified gage hides published Cpk
    coq_scope              TEXT         NOT NULL DEFAULT 'IF_AND_APPRAISAL', -- v1 COQ buckets in scope
    mrb_severity_threshold qual.criticality NOT NULL DEFAULT 'MAJOR', -- at/above -> full MRB
    effective_from         TIMESTAMPTZ  NOT NULL DEFAULT now(),
    effective_to           TIMESTAMPTZ,
    ext                    JSONB        NOT NULL DEFAULT '{}'::jsonb,
    created_at             TIMESTAMPTZ  NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, effective_from)
);

-- 1.2 Per work-unit capture / MSA configuration
CREATE TABLE qual.work_unit_config (
    work_unit_config_id  BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    work_unit_ref        BIGINT      NOT NULL REFERENCES canon.equipment_node(node_id),
    capture_fidelity     qual.capture_fidelity NOT NULL DEFAULT 'MANUAL',
    default_sampling     qual.sampling_basis   NOT NULL DEFAULT 'FIXED_N',
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, work_unit_ref)
);

-- 1.3 Quality characteristic master (variable or attribute; criticality; MSA)
CREATE TABLE qual.characteristic (
    characteristic_id    BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    code                 TEXT        NOT NULL,                   -- e.g. THICKNESS, HARDNESS, SURFACE
    name                 TEXT        NOT NULL,
    lens                 qual.lens   NOT NULL,                   -- VARIABLE -> SPC; ATTRIBUTE -> defect
    criticality          qual.criticality NOT NULL DEFAULT 'MAJOR',
    uom                  TEXT,                                   -- mm, HRB, MPa ... (NULL for attribute)
    work_unit_ref        BIGINT      REFERENCES canon.equipment_node(node_id),
    material_ref         BIGINT      REFERENCES canon.material(material_id), -- grade scope (NULL = all)
    msa_status           qual.msa_status NOT NULL DEFAULT 'NOT_ASSESSED',
    gage_rr_pct          NUMERIC(5,2),                           -- % Gage R&R (lower is better)
    is_active            BOOLEAN     NOT NULL DEFAULT TRUE,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, code, work_unit_ref)
);

-- 1.4 Specification limits (versioned; per characteristic x grade) — defines "in spec"
CREATE TABLE qual.spec_limit (
    spec_id              BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    characteristic_ref   BIGINT      NOT NULL REFERENCES qual.characteristic(characteristic_id),
    grade_ref            BIGINT      REFERENCES canon.material(material_id),  -- grade variant
    nominal              NUMERIC(14,5),                          -- target
    usl                  NUMERIC(14,5),                          -- upper spec limit
    lsl                  NUMERIC(14,5),                          -- lower spec limit
    version              INT         NOT NULL DEFAULT 1,
    is_active            BOOLEAN     NOT NULL DEFAULT TRUE,
    effective_from       TIMESTAMPTZ NOT NULL DEFAULT now(),
    effective_to         TIMESTAMPTZ,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, characteristic_ref, grade_ref, version)
);

-- 1.5 Inspection / control plan header (PFMEA -> control plan, the specify layer)
CREATE TABLE qual.inspection_plan (
    plan_id              BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    name                 TEXT        NOT NULL,
    work_unit_ref        BIGINT      NOT NULL REFERENCES canon.equipment_node(node_id),
    route_ref            BIGINT,                                 -- soft ref to ops.route (M3)
    is_active            BOOLEAN     NOT NULL DEFAULT TRUE,
    version              INT         NOT NULL DEFAULT 1,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, name, version)
);

-- 1.6 Inspection plan item (characteristic x sampling x reaction inside a plan)
CREATE TABLE qual.inspection_plan_item (
    plan_item_id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    plan_ref             BIGINT      NOT NULL REFERENCES qual.inspection_plan(plan_id),
    characteristic_ref   BIGINT      NOT NULL REFERENCES qual.characteristic(characteristic_id),
    sampling_basis       qual.sampling_basis NOT NULL DEFAULT 'FIXED_N',
    aql_pct              NUMERIC(5,3),                           -- AQL when sampling = AQL_2859
    sample_size          INT,                                   -- fixed-n / per-lot sample
    frequency_txt        TEXT,                                  -- e.g. 'per coil', 'every 30 min'
    reaction_txt         TEXT,                                  -- reaction plan on a limit breach
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (plan_ref, characteristic_ref)
);

-- 1.7 Governed defect taxonomy (3-layer self-referencing; M6 masters it)
--     Layer 1 category -> Layer 2 type -> Layer 3 root-cause detail.
CREATE TABLE qual.defect_code (
    defect_code_id       BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    parent_code_id       BIGINT      REFERENCES qual.defect_code(defect_code_id), -- NULL at Layer 1
    layer                SMALLINT    NOT NULL CHECK (layer BETWEEN 1 AND 3),
    code                 TEXT        NOT NULL,
    label                TEXT        NOT NULL,
    criticality          qual.criticality NOT NULL DEFAULT 'MAJOR',
    default_disposition  qual.disposition_type NOT NULL DEFAULT 'PENDING',
    loss_category_ref    BIGINT      REFERENCES canon.loss_category(category_id), -- Six Big Losses map
    is_other_bucket      BOOLEAN     NOT NULL DEFAULT FALSE,     -- exactly one governed 'Other'
    is_active            BOOLEAN     NOT NULL DEFAULT TRUE,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, code)
);

-- ---------------------------------------------------------------------
-- 2. Conformance capture (inspection + measurement) — capture-agnostic
-- ---------------------------------------------------------------------

-- 2.1 Executed inspection event (links to the shared ProductionCount / lot)
CREATE TABLE qual.inspection (
    inspection_id        BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    plan_ref             BIGINT      REFERENCES qual.inspection_plan(plan_id),
    production_count_id  BIGINT      REFERENCES canon.production_count(count_id), -- the shared count
    lot_ref              BIGINT      REFERENCES canon.material_lot(lot_id),       -- COIL_NO
    work_unit_ref        BIGINT      REFERENCES canon.equipment_node(node_id),
    shift_ref            BIGINT      REFERENCES canon.shift(shift_id),
    capture_fidelity     qual.capture_fidelity NOT NULL DEFAULT 'MANUAL',
    sample_size          INT,
    result               qual.inspection_result NOT NULL DEFAULT 'PASS',
    inspector            TEXT,
    inspected_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_qual_inspection_count ON qual.inspection (production_count_id);
CREATE INDEX ix_qual_inspection_lot   ON qual.inspection (lot_ref);

-- 2.2 Variable measurement (the SPC input stream)
CREATE TABLE qual.measurement (
    measurement_id       BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    inspection_ref       BIGINT      REFERENCES qual.inspection(inspection_id),
    characteristic_ref   BIGINT      NOT NULL REFERENCES qual.characteristic(characteristic_id),
    spec_ref             BIGINT      REFERENCES qual.spec_limit(spec_id),
    lot_ref              BIGINT      REFERENCES canon.material_lot(lot_id),
    value_num            NUMERIC(14,5) NOT NULL,
    in_spec              BOOLEAN,                                -- computed vs spec_ref
    subgroup_key         TEXT,                                  -- groups values into an SPC subgroup
    measured_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_qual_meas_char ON qual.measurement (characteristic_ref, measured_at);

-- ---------------------------------------------------------------------
-- 3. SPC & capability
-- ---------------------------------------------------------------------

-- 3.1 Control chart definition + current limits + capability indices
CREATE TABLE qual.control_chart (
    chart_id             BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    characteristic_ref   BIGINT      NOT NULL REFERENCES qual.characteristic(characteristic_id),
    work_unit_ref        BIGINT      REFERENCES canon.equipment_node(node_id),
    grade_ref            BIGINT      REFERENCES canon.material(material_id),
    chart_type           qual.control_chart_type NOT NULL,
    rule_set             qual.spc_rule_set NOT NULL DEFAULT 'WESTERN_ELECTRIC',
    subgroup_size        INT         NOT NULL DEFAULT 1,
    center_line          NUMERIC(14,5),
    ucl                  NUMERIC(14,5),
    lcl                  NUMERIC(14,5),
    cp                   NUMERIC(6,3),
    cpk                  NUMERIC(6,3),
    pp                   NUMERIC(6,3),
    ppk                  NUMERIC(6,3),
    in_control           BOOLEAN     NOT NULL DEFAULT TRUE,
    limits_recalc_at     TIMESTAMPTZ,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, characteristic_ref, work_unit_ref, grade_ref, chart_type)
);

-- 3.2 SPC special-cause signal (a run-rule violation)
CREATE TABLE qual.spc_signal (
    signal_id            BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    chart_ref            BIGINT      NOT NULL REFERENCES qual.control_chart(chart_id),
    rule_code            TEXT        NOT NULL,                   -- e.g. WE1 (beyond 3s), NELSON3 (trend)
    description          TEXT,
    sample_value         NUMERIC(14,5),
    is_acknowledged      BOOLEAN     NOT NULL DEFAULT FALSE,
    raised_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_qual_signal_chart ON qual.spc_signal (chart_ref, raised_at);

-- ---------------------------------------------------------------------
-- 4. Defect record (the quality SoR event) + disposition
-- ---------------------------------------------------------------------

-- 4.1 DefectRecord — Event-Spine specialisation MASTERED by M6.
--     Anchored to the SAME canon.production_count M4/M5 read (no double-count).
CREATE TABLE qual.defect_record (
    defect_record_id     BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    event_id             BIGINT      REFERENCES canon.event(event_id),            -- registered on the spine
    production_count_id  BIGINT      REFERENCES canon.production_count(count_id), -- the shared count anchor
    lot_ref              BIGINT      REFERENCES canon.material_lot(lot_id),       -- COIL_NO
    inspection_ref       BIGINT      REFERENCES qual.inspection(inspection_id),
    defect_code_ref      BIGINT      NOT NULL REFERENCES qual.defect_code(defect_code_id),
    source               qual.defect_source NOT NULL DEFAULT 'IN_PROCESS',
    severity             qual.criticality NOT NULL DEFAULT 'MAJOR',
    disposition          qual.disposition_type NOT NULL DEFAULT 'PENDING',
    from_grade_ref       BIGINT      REFERENCES canon.material(material_id),      -- downgrade: from
    to_grade_ref         BIGINT      REFERENCES canon.material(material_id),      -- downgrade: to
    qty_count            NUMERIC(14,3),                          -- units affected
    qty_mass_mt          NUMERIC(14,4),                          -- mass affected (M5 prices this)
    location             JSONB       NOT NULL DEFAULT '{}'::jsonb,-- coil position / defect-map coords
    detected_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_qual_defrec_count ON qual.defect_record (production_count_id);
CREATE INDEX ix_qual_defrec_code  ON qual.defect_record (defect_code_ref);
CREATE INDEX ix_qual_defrec_lot   ON qual.defect_record (lot_ref);

-- 4.2 Quality hold (containment / quarantine) -> M3 QUALITY_HOLD carryover
CREATE TABLE qual.quality_hold (
    hold_id              BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    lot_ref              BIGINT      REFERENCES canon.material_lot(lot_id),
    defect_record_ref    BIGINT      REFERENCES qual.defect_record(defect_record_id),
    status               qual.hold_status NOT NULL DEFAULT 'OPEN',
    reason_txt           TEXT,
    opened_by            TEXT,
    opened_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
    released_at          TIMESTAMPTZ,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_qual_hold_status ON qual.quality_hold (status, opened_at);

-- ---------------------------------------------------------------------
-- 5. Nonconformance (NCR / MRB) + CAPA
-- ---------------------------------------------------------------------

-- 5.1 Nonconformance case (groups defect records; drives MRB)
CREATE TABLE qual.nonconformance (
    ncr_id               BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    title                TEXT        NOT NULL,
    severity             qual.criticality NOT NULL DEFAULT 'MAJOR',
    status               qual.ncr_status NOT NULL DEFAULT 'OPEN',
    primary_defect_ref   BIGINT      REFERENCES qual.defect_record(defect_record_id),
    mrb_decision         qual.disposition_type,
    mrb_authoriser       TEXT,
    opened_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
    closed_at            TIMESTAMPTZ,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 5.2 NCR <-> defect_record link (an NCR may span many records)
CREATE TABLE qual.ncr_defect_link (
    ncr_ref              BIGINT      NOT NULL REFERENCES qual.nonconformance(ncr_id),
    defect_record_ref    BIGINT      NOT NULL REFERENCES qual.defect_record(defect_record_id),
    PRIMARY KEY (ncr_ref, defect_record_ref)
);

-- 5.3 CAPA / 8D case (root cause -> corrective + preventive -> verify)
CREATE TABLE qual.capa (
    capa_id              BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    ncr_ref              BIGINT      REFERENCES qual.nonconformance(ncr_id),
    title                TEXT        NOT NULL,
    status               qual.capa_status NOT NULL DEFAULT 'OPEN',
    rca_method           qual.rca_method NOT NULL DEFAULT 'FIVE_WHY',
    root_cause           TEXT,
    containment_action   TEXT,                                   -- D3
    corrective_action    TEXT,                                   -- D5/D6
    preventive_action    TEXT,                                   -- D7
    fmea_updated         BOOLEAN     NOT NULL DEFAULT FALSE,     -- loop back to control plan
    effectiveness_verified BOOLEAN   NOT NULL DEFAULT FALSE,     -- D8 gate to close
    owner                TEXT,
    due_at               TIMESTAMPTZ,
    opened_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
    closed_at            TIMESTAMPTZ,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_qual_capa_status ON qual.capa (status, due_at);

-- ---------------------------------------------------------------------
-- 6. Cost of Quality + targets + governance
-- ---------------------------------------------------------------------

-- 6.1 Cost-of-Quality ledger entry (PAF model; internal-failure == M5 loss, once)
CREATE TABLE qual.coq_entry (
    coq_id               BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    coq_category         qual.coq_category NOT NULL,
    defect_record_ref    BIGINT      REFERENCES qual.defect_record(defect_record_id),
    capa_ref             BIGINT      REFERENCES qual.capa(capa_id),
    cost_rate_ref        BIGINT      REFERENCES canon.cost_rate(rate_id),
    amount               NUMERIC(16,2) NOT NULL,
    currency             TEXT        NOT NULL DEFAULT 'INR',
    is_from_m5_loss      BOOLEAN     NOT NULL DEFAULT FALSE,     -- TRUE when sourced from M5 priced loss
    period_grain         qual.time_grain NOT NULL DEFAULT 'MONTH',
    period_start         DATE,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_qual_coq_cat ON qual.coq_entry (coq_category, period_start);

-- 6.2 Quality targets (per characteristic / work-unit / KPI)
CREATE TABLE qual.quality_target (
    target_id            BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    kpi_code             TEXT        NOT NULL,                   -- FPY, CPK, DPMO, COQ_PCT ...
    work_unit_ref        BIGINT      REFERENCES canon.equipment_node(node_id),
    characteristic_ref   BIGINT      REFERENCES qual.characteristic(characteristic_id),
    target_value         NUMERIC(14,4) NOT NULL,
    effective_from       TIMESTAMPTZ NOT NULL DEFAULT now(),
    effective_to         TIMESTAMPTZ,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 6.3 Policy change log (audit any spec / limit / disposition-rule / taxonomy change)
CREATE TABLE qual.policy_change_log (
    change_id            BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    entity_type          TEXT        NOT NULL,                   -- SPEC_LIMIT, CONTROL_CHART, DEFECT_CODE ...
    entity_id            BIGINT      NOT NULL,
    change_summary       TEXT        NOT NULL,
    changed_by           TEXT        NOT NULL,
    effective_from       TIMESTAMPTZ NOT NULL DEFAULT now(),
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 6.4 Readiness snapshot (Required / Quality / Fidelity(MSA) / History gates)
CREATE TABLE qual.readiness_snapshot (
    snapshot_id          BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    work_unit_ref        BIGINT      REFERENCES canon.equipment_node(node_id),
    gate                 qual.readiness_gate NOT NULL,
    score_pct            NUMERIC(5,2),
    detail               JSONB       NOT NULL DEFAULT '{}'::jsonb,
    captured_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 6.5 Quality prediction (FUTURE SCOPE stub — defect-risk / SPC-excursion / CV)
CREATE TABLE qual.quality_prediction (
    prediction_id        BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    characteristic_ref   BIGINT      REFERENCES qual.characteristic(characteristic_id),
    work_unit_ref        BIGINT      REFERENCES canon.equipment_node(node_id),
    grade_ref            BIGINT      REFERENCES canon.material(material_id),
    horizon_txt          TEXT,
    predicted_defect_ppm NUMERIC(12,2),
    model_version        TEXT,
    is_active            BOOLEAN     NOT NULL DEFAULT FALSE,     -- dark until History gate passes
    generated_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb
);

-- ---------------------------------------------------------------------
-- 7. Roll-up views (SUM-then-divide; never average sub-ratios)
-- ---------------------------------------------------------------------

-- 7.1 Conformance roll-up — FPY / quality-ratio / defect-rate from canonical counts
CREATE VIEW qual.v_quality_rollup AS
SELECT
    dr.tenant_id,
    pc.work_unit_ref,
    pc.material_ref,
    date_trunc('day', dr.detected_at)                          AS day,
    COUNT(*)                                                   AS defect_count,
    SUM(COALESCE(dr.qty_count, 0))                             AS defect_qty,
    SUM(COALESCE(dr.qty_mass_mt, 0))                           AS defect_mass_mt,
    SUM(CASE WHEN dr.disposition = 'SCRAP'     THEN 1 ELSE 0 END) AS scrap_count,
    SUM(CASE WHEN dr.disposition = 'REWORK'    THEN 1 ELSE 0 END) AS rework_count,
    SUM(CASE WHEN dr.disposition = 'DOWNGRADE' THEN 1 ELSE 0 END) AS downgrade_count
FROM qual.defect_record dr
JOIN canon.production_count pc ON pc.count_id = dr.production_count_id
GROUP BY dr.tenant_id, pc.work_unit_ref, pc.material_ref, date_trunc('day', dr.detected_at);

-- 7.2 Cost-of-Quality roll-up — the PAF buckets, priced
CREATE VIEW qual.v_coq_rollup AS
SELECT
    tenant_id,
    period_start,
    coq_category,
    SUM(amount)                                               AS total_cost,
    COUNT(*)                                                  AS entry_count
FROM qual.coq_entry
GROUP BY tenant_id, period_start, coq_category;

-- =====================================================================
-- End M6 qual schema. Build phasing in 00_INDEX_and_Architecture.md.
-- =====================================================================

```
