# 08 · Prediction / Future-scope Interfaces Spec
**Build:** Future (gated) · deep-plan §8

> Forecasting load, predicting the demand peak, and prescribing the cheapest-and-cleanest choice is the operating-model's post-6-month → prescriptive horizon, **gated on accumulated interval history**. v1 is descriptive/diagnostic; this spec keeps prediction a switch-on, not a rebuild. `energy.energy_prediction` is the dark stub (`is_active=FALSE`).

## 1. Future capabilities (the ladder)

| Capability | v1 | Future |
|---|---|---|
| Consumption | meter, normalise, EnPI, balance | **load/consumption forecasting** per SEU×grade from plan & weather |
| Demand | track vs cap (off bill/early meters) | **demand-peak forecast + automated demand response / load control** (needs real-time metering) |
| Baseline variance | CUSUM excess signal | **excess-consumption anomaly ML** → auto-attribute to SEU |
| Condition | energy-signature trend | **energy-signature condition monitoring** (rising SEC/falling efficiency → fouled furnace / worn compressor / degrading motor; shared with M2) |
| Tariff/sourcing | ToU surface + DG-vs-grid view | **prescriptive tariff & load optimisation** — optimal schedule, DG-vs-grid dispatch, battery, contract right-sizing |
| Design | SEC by grade | **design-to-energy** — lowest-energy route×grade (shared with M5 design-to-yield) |

## 2. What v1 must get right (so it's a switch-on)

(a) **time-stamped consumption joined to production, state, grade, weather, tariff** from day one (features + objective); (b) **meter calibration/comms-health** on every stream (real features, not meter noise — the spec 03 gate); (c) **interval data where it exists** (DR & anomaly need sub-hourly — exactly why automatic metering is future-proofed now); (d) a **prediction-readiness (History) gate** (`readiness_snapshot.gate=HISTORY`, `history_days`) reporting per SEU×route when enough interval history exists. No prediction *promises* in v1 — only *readiness*.

## 3. One shared ML model surface (M2/M4/M5/M6/M7)

The **energy-signature** that predicts a compressor failure (M7) *is* the condition signal M2 reads; a grade transition that predicts a yield-loss window (M5) and a defect-risk window (M6) is the same window that predicts an energy-intensity spike (M7) — **one** model surface, not five. M7's prediction shares the platform ML-readiness substrate; automated demand-response & tariff-optimisation land on the §5 real-time metering interface.

## 4. Interfaces present now (dark)

`energy_prediction` (model_kind: LOAD_FORECAST / DEMAND_PEAK / EXCESS_ANOMALY / ENERGY_SIGNATURE / TARIFF_OPT; `is_active=FALSE`); the streaming meter interface (spec 03); the History readiness gate. No build until the gate passes and the shared model surface is online.

## 5. Acceptance (this spec)

The stub exists and is dark; the History gate reports interval-days per SEU×route; turning on a model requires no schema change to the v1 consumption/baseline/demand tables; an energy-signature feature is derivable from existing `meter_reading` + `enpi_value` without re-modelling.
