# 10 · Glossary
**M7 · Energy Intelligence** — terms, standards & acronyms

## Energy management & performance
- **EnMS** — Energy Management System (ISO 50001): the energy review → SEU → baseline → EnPI → objectives → action plan PDCA loop.
- **Energy review** — the ISO 50001 analysis of energy use & consumption that identifies the SEUs.
- **SEU — Significant Energy Use** — a use/system accounting for substantial consumption or holding large improvement potential (steel: reheating furnace, mill drives, compressed air). DOE system taxonomy: process heating, compressed air, motor/drive, pumping, fans, steam, HVAC, lighting, process cooling.
- **EnB — Energy Baseline** — the reference (≥12 months) energy-performance model every improvement is measured against (ISO 50006). May be a simple ratio or a regression (intercept β₀ = standing/no-load load).
- **EnPI — Energy Performance Indicator** — a metric of energy performance; here a ratio (SEC) or a regression-normalised model (ISO 50006).
- **SEC — Specific Energy Consumption** — energy per unit output (GJ/t, kWh/t) — the headline intensity.
- **Normalisation / relevant variables** — adjusting energy for the drivers that legitimately move it (production volume, weather HDD/CDD, product/grade mix, charge temperature) so efficiency is separated from volume.
- **Absolute vs Normalised lens** — M7's dual lenses: absolute = kWh/GJ/₹/kgCO₂e drawn & spent; normalised = EnPI/SEC efficiency. Equal weight (cf. M5 mass+count, M6 attribute+variable).

## Measurement & verification
- **M&V** — Measurement & Verification of energy savings (ISO 50015).
- **IPMVP** — International Performance Measurement & Verification Protocol; Options **A** (retrofit isolation, key-parameter), **B** (retrofit isolation, all-parameter), **C** (whole-facility regression), **D** (calibrated simulation).
- **Avoided energy** — baseline-projected energy at current conditions − actual; the *real* saving (not naïve before/after).
- **CUSUM** — cumulative sum of (actual − expected) energy; a slope change pinpoints when a process drifted off baseline. M7's analogue of the SPC control chart.
- **Energy balance** — purchased + generated = distributed + losses + unmetered gap (per carrier). The gap = metering-coverage honesty, never waste. M7's analogue of M5's mass balance.

## Carriers, metering & electricity
- **Carrier** — an energy type (electricity, gas, steam, compressed air, water…) converted to common-unit **GJ** + **kgCO₂e**.
- **Metering hierarchy** — boundary → area → feeder → sub → machine meters; `parent_meter_ref`.
- **Basis / Fidelity** — how a consumption number was derived: METERED / BILLED / CALCULATED / APPORTIONED / ESTIMATED × MANUAL / BILL / INGESTED / AUTOMATIC.
- **Protocols** — Modbus, DNP3, IEC 61850, DLMS/COSEM (meters) → data concentrator → **OPC-UA** → historian (the automatic on-ramp).
- **Maximum demand** — highest average power over a rolling 15/30-min window; sets the **demand charge** (often ~40% of the electricity bill).
- **Peak shaving** — shedding/shifting load to keep below the demand cap.
- **Time-of-use (ToU)** — energy priced by peak/shoulder/off-peak windows.
- **Power factor (PF)** — kW÷kVA; low PF (lagging) draws a **kVA/kVAr penalty**; corrected with capacitors (target ≥ 0.95).
- **Demand response (DR)** — automated load control to a demand/price signal (future-scope).

## Carbon
- **GHG Protocol** — corporate carbon-accounting standard. **Scope 1** = on-site combustion (furnace gas, DG fuel); **Scope 2** = purchased electricity/steam, computed **location-based** (grid average) **and** **market-based** (contractual/PPA/REC + residual mix); **Scope 3** = value-chain (future).
- **Emission factor** — kgCO₂e per GJ/kWh; effective-dated (rate-as-of).
- **ISO 14404** — calculation method for CO₂-emission intensity of steel (Part 1 blast furnace / Part 2 EAF / Part 3 EAF+DRI / Part 4 guidance + universal calculation sheet); tCO₂ per tonne on an import/export boundary.

## Platform & cross-module
- **Embodied / embedded energy** — energy already spent making material that became scrap (M5) or defective/downgraded (M6); wasted twice; counted **once** with M5/M6's loss.
- **Energy-by-state** — energy split by M4 `StateInterval` (running/idle/down); idle/standby = avoidable energy loss tied to the same downtime minutes M4 owns.
- **No-double-count anchor** — `energy_consumption.production_count_id` = the one shared `ProductionCount`; EnPI denominator == the tonnes under OEE/yield/quality.
- **Standards reconciled** — ISO 50001 (EnMS), ISO 50006 (EnB/EnPI), ISO 50015/IPMVP (M&V), GHG Protocol + ISO 14064 (carbon), ISO 14404 (steel CO₂), ISO 22400-2 (energy KPI), DOE Better Plants (SEU taxonomy).
