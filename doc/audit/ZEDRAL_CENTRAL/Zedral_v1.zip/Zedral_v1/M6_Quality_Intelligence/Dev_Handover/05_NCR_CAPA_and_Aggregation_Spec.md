# 05 · NCR, CAPA & Aggregation Pipeline Spec
**Phase M6-2/3 · deep-plan §7**

## 1. Nonconformance (NCR) & MRB (`nonconformance`, `ncr_defect_link`)

A `defect_record` (or a cluster, or an SPC special-cause signal) opens an **NCR** — the *case* that groups affected material (`ncr_defect_link`), records severity/scope, drives the **MRB disposition** (`mrb_decision` + `mrb_authoriser`), and triggers a CAPA when warranted. The NCR is the governed, audit-trailed record ISO 9001 cl. 8.7 requires. Routing: severities at/above `quality_config.mrb_severity_threshold` → full MRB; below → auto-disposition by `defect_code.default_disposition`.

## 2. CAPA / 8D (`capa`) — the recurrence-killer

A disposition fixes *this* material; a CAPA fixes the *process*. 8D stages map to columns:

| 8D | Column |
|---|---|
| D2 define | `title` |
| D3 containment | `containment_action` |
| D4 root cause | `rca_method` (`FIVE_WHY`/`FISHBONE`/`EIGHT_D`) + `root_cause` |
| D5/D6 corrective | `corrective_action` |
| D7 preventive + loop-back | `preventive_action` + `fmea_updated` |
| D8 verify | `effectiveness_verified` (gate to `status='CLOSED'`) |

Rules: **corrective ≠ preventive** (both tracked to `owner` + `due_at`); fishbone 6M *Machine* leg links to **M2** (equipment condition), *Measurement* leg to M6's MSA; **effectiveness verification is mandatory** — a CAPA is not closed until the metric (defect rate, Cpk, ppm) improves over a verification window. **Recurrence rate** & **cycle time** are KPIs (spec 06) — high recurrence ⇒ root causes guessed, not found. A verified CAPA updates the FMEA/control plan (`fmea_updated`) — the loop back to stage 1 of the quality loop.

## 3. Aggregation pipeline (events → mart)

```
measurement / defect_record / disposition (canonical events)
   → streaming: live SPC tile, out-of-control & defect-rate alerts (Flink, D2)
   → scheduled rollup: v_quality_rollup (FPY/ppm/disposition mix), capability recompute, v_coq_rollup
   → Serving APIs + KPI registry (spec 07)
```

Rollups are **SUM-then-divide** (`v_quality_rollup`) — never average sub-ratios. All rollups are **deterministic & replayable** from canonical events (deep-plan §13): a re-coded defect or corrected measurement re-derives the affected charts, dispositions and COQ.

## 4. Defect intelligence slices

Serve defect rate / ppm / Cpk / disposition mix by **defect type, step, grade, route, work-unit, shift, crew, and supplier lot** (the supplier-defect spread pre-stages the future scorecard). Pareto by **count and by cost** (they rank differently — a rare premium-grade downgrade can outweigh a common minor scratch); the executive list is ranked by money (spec 06).
