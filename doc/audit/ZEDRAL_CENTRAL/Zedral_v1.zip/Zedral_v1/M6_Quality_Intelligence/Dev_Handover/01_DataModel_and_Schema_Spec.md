# 01 · Data Model & Schema Spec
**Phase M6-0 · DDL:** `qual_schema.sql` (PostgreSQL 15+, `qual` schema, pglast-validated 53 statements)

## 1. Positioning — SoR, not thin-write

M5 and M4 are thin-write calc layers; **M6 is different — it is the quality system-of-record**, so it owns genuinely new transactional data: the conformance record (`inspection`, `measurement`, `defect_record`), the disposition (`quality_hold`, `nonconformance`), and the resolution (`capa`). What it does **not** re-record is the count: every `defect_record` carries the canonical `production_count_id` of the SAME `ProductionCount` that M4 (Quality factor), M3 (attainment) and M5 (priced loss) read. M6 **classifies and dispositions**; it never re-records a produced quantity.

The canonical `DefectCode`/`DefectRecord` scaffolding already exists in the canonical catalogue (doc 01 §10). M6 is the module that **brings the conformance side to life** and is the physical master of those Event-Spine specialisations (`qual.defect_code`, `qual.defect_record`), registered on `canon.event`.

## 2. Entity groups (see `qual_schema.sql`)

| Group | Tables | Role |
|---|---|---|
| **Reference & policy** | `quality_config`, `work_unit_config`, `characteristic`, `spec_limit`, `inspection_plan`, `inspection_plan_item`, `defect_code` | the specify layer — what to measure, against what limit, how to sample, the governed taxonomy |
| **Conformance capture** | `inspection`, `measurement` | executed inspection + the variable SPC input stream |
| **SPC** | `control_chart`, `spc_signal` | chart defn + limits + capability; special-cause violations |
| **Defect SoR & disposition** | `defect_record`, `quality_hold` | the bad-unit event + containment; carries disposition incl. grade-downgrade |
| **NCR / CAPA** | `nonconformance`, `ncr_defect_link`, `capa` | the case + MRB decision + the 8D root-cause-to-verified-closure |
| **Cost / targets / governance** | `coq_entry`, `quality_target`, `policy_change_log`, `readiness_snapshot`, `quality_prediction` | PAF pricing, targets, audit, readiness gates, the (dark) prediction stub |
| **Views** | `v_quality_rollup`, `v_coq_rollup` | SUM-then-divide conformance roll-up; PAF roll-up |

## 3. The no-double-count anchor (the critical invariant)

`defect_record.production_count_id` and `lot_ref` point at the **same** canonical rows M4 (Quality factor), M3 (attainment) and M5 (defect/loss) read. M6 **classifies + dispositions**; it never re-records a count. Therefore:
- M6's defect-driven Quality-loss **must equal** M4's Quality-factor loss by construction (same good/total, same ISO 22400 mapping) — spec 06 §4.
- Σ M6 disposition material (scrap+rework+downgrade) for defect-driven records **must equal** Σ M5 priced loss for those `DefectRecords` — spec 06 §4, M5 spec 06 §4.

## 4. Key column conventions

- IDs `BIGINT GENERATED ALWAYS AS IDENTITY`; `tenant_id UUID`; timestamps `TIMESTAMPTZ` (UTC); `ext JSONB` extension namespace; units in column names (`qty_mass_mt`, `gage_rr_pct`).
- **Hard FK only to `canon.*` and within `qual.*`.** Other modules are soft BIGINT `*_ref` (`route_ref` → M3 `ops.route`).
- **Versioning** — `spec_limit` and `inspection_plan` are versioned + effective-dated so a Cpk/conformance trend is never silently broken by a re-definition; every change is mirrored in `policy_change_log` (ISO 9001 traceability).
- **Append-only SoR** — `nonconformance`, `capa`, `defect_record` are audit-trailed (no destructive update of a dispositioned record; corrections create new rows / log entries).

## 5. Migration (target + bridge, deep-plan §14)

Existing M6 dashboards keep running; the calc is repointed onto `canon.production_count` + `qual.defect_record` via the Serving API; flat defect categories migrate as Layer-1/2 `defect_code` leaves (historical codes kept as aliases in `ext`); SPC limits seed from current data with an MSA status attached. **Back-test gate:** existing defect rate / FPY / disposition mix agree with canonical to tolerance on a back-test window, AND M6 Quality-loss == M4 Quality factor, AND M6 disposition == M5 priced loss (spec 09).
