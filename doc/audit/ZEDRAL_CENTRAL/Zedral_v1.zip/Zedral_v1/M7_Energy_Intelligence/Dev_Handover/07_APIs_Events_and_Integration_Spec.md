# 07 · APIs, Events & Integration Spec
**Build:** Phase M7-2 · deep-plan §12

> M7 publishes energy facts and reads everyone else's; it never writes another module's tables (golden rule). All cross-module access is via versioned Serving APIs / events, never direct `energy.*` queries.

## 1. Serving APIs (read; FastAPI, versioned `/v1`)

- `GET /energy/consumption?carrier&seu&node&from&to&grain` → normalised GJ + CO₂e + cost, with basis/fidelity.
- `GET /energy/enpi?enpi&grain&from&to` → actual / expected / variance / CUSUM / avoided.
- `GET /energy/balance?carrier&period` → purchased/distributed/loss/**gap%** (coverage honesty).
- `GET /energy/demand?node&from&to` → max-demand vs cap, PF, peak events; `GET /energy/tariff-surface` → ToU windows + rates (for M3).
- `GET /energy/carbon?scope&period` → Scope 1 / 2-location / 2-market + ISO 14404 intensity.
- `GET /energy/waste?category&grain` → ranked avoidable waste (₹ + kgCO₂e + owner).
- `GET /energy/readiness?seu` → Required/Coverage/Fidelity/History gates.

## 2. Published events (Kafka; for Monitoring/UIL/siblings)

`energy.consumption.recorded`, `energy.enpi.computed`, `energy.baseline.excursion` (CUSUM slope change), `energy.demand.peak_approach`, `energy.powerfactor.penalty`, `energy.balance.gap_exceeded`, `energy.carbon.computed`, `energy.waste.ranked`. Each carries the canonical anchors (`production_count_id`, `state_interval_ref`, asset node) so consumers join to the shared truth.

## 3. Sibling contracts (the boundaries — deep-plan §12)

| Boundary | M7 reads | M7 publishes | Shared artifact |
|---|---|---|---|
| **M4 (OEE)** | `StateInterval` (running/idle/down) | energy-by-state, idle-energy loss | one `StateInterval` (M4 classifies, M7 attributes energy) |
| **M5 (Yield)** | loss qty | embodied energy of loss | one `ProductionCount` loss (M5 material, M7 energy) |
| **M6 (Quality)** | good/defective split (`DefectRecord`) | embedded-energy of defective | one `DefectRecord` |
| **M3 (Planning)** | plan/route/sequence | ToU cost surface + demand headroom | M7 signal in, M3 schedules; M7 never writes ops.* |
| **M2 (Maint.)** | condition/failure | energy-signature degradation (rising SEC) | shared ML model surface |
| **M1** | manual reads/bills/fuel-logs, COIL_NO | the energy SoR | `MeterReading`, `EnergyConsumption` |
| **Manifold** | meter/SCADA/bill/historian connectors | data contract + energy sector template | sector template |
| **UIL / Monitoring / Financial** | KPI registry / live cache / CostRate-Tariff | EnPI/consumption/demand/carbon/cost | shared registry |

## 4. Manifold integration

Connectors: CSV/Excel bill & meter exports (D4 first), generic DB, then meter/SCADA-historian/utility-portal (switch-on). Carrier/meter/tariff field-mapping through the **review queue** (D5, never blind). The seeded **energy sector template** carries the steel carrier set, SEU register, SEC EnPIs + relevant variables, tariff shape, emission factors and the ISO 14404 boundary.

## 5. Acceptance (this spec)

Every API is versioned and returns the canonical anchors; no consumer queries `energy.*` directly; events fire with the production/state anchor; M3 can read the ToU surface and M4/M5/M6 can read energy-by-state / embodied energy through the projection; a re-versioned factor re-emits derived events deterministically.
