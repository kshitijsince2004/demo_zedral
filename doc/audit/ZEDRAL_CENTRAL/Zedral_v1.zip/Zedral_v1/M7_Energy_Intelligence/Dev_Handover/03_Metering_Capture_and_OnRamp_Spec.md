# 03 · Metering Capture & On-ramp Spec
**Build:** Phase M7-1 · deep-plan §5

> Where M7's capture decision lives. **v1 bootstraps from M1 manual meter reads, typed utility bills and fuel/DG logs; automatic interval metering, SCADA/historian and BMS are future-proofed → the full-EnMS metering platform.** Same canonical contract (`meter_reading` → `energy_consumption`), two fidelities.

## 1. The metering hierarchy (the spine)

`meter` models the tree via `parent_meter_ref`: BOUNDARY (utility bill / main meter) → AREA → FEEDER → SUB → MACHINE, plus VIRTUAL (calculated). Each meter carries `carrier_ref`, `asset_node_ref` (where it sits), `seu_ref`, `multiplier` (CT/PT ratio), `meter_kind`, `capture_fidelity`, and (electricity) `has_demand_register`. Hero Steels' single-line diagram and utility headers (gas/air/water) define the initial tree.

## 2. Two capture fidelities, one contract

| | v1 — Manual bootstrap (today) | Future-proofed — Automatic (switch-on) |
|---|---|---|
| Electricity | manual reads + utility bill (kWh, max demand, PF, ₹) | interval meters: 15-min kWh/kVA/PF per feeder (Modbus/DNP3/IEC 61850/DLMS) → concentrator → OPC-UA |
| Thermal | fuel/DG logs, gas bill | flow meters on gas/steam/air/water headers + BMS |
| Resolution | monthly / per-read | sub-hourly, sub-metered |
| Basis | `BILLED` / `APPORTIONED` | `METERED` |

Both emit `meter_reading` → `energy_consumption`; **no downstream engine changes**, only fidelity and confidence rise. The automatic path is what turns the demand engine from retrospective (off the bill) to real-time (peak-shave before the peak sets) and unlocks true sub-metered M&V (IPMVP-B) — it is the layer that realises the meter-device-management, real-time-monitoring and demand-response rungs of the full-EnMS target.

## 3. v1 — bootstrap from M1 (cheapest first value)

M1's manual reads → consumption stream; the utility bill → tariff/demand/PF source + the regression-baseline history; fuel/DG logs → Scope 1 carrier. M7 converts to GJ + CO₂e, **apportions** boundary/area energy down to work-centre and SEU by run-time / throughput / connected load (`allocation_method`), computes EnPI/SEC per process & grade, builds the regression baseline from a year of bills, and lights up demand/PF/ToU off the bill — **no new hardware**. Apportioned numbers are tagged `APPORTIONED` (not `METERED`).

## 4. Meter device management & the data-quality gate

Per meter: `health` (OK / UNCALIBRATED / STALE_COMMS / FAULT), `last_calibrated_on`, `multiplier`, `comms_protocol`. The gate: an uncalibrated or stale-comms meter is flagged low-confidence and **excluded from a published EnPI baseline fit**; an apportioned consumption shows its method, never a hard sub-meter; the energy-balance gap (spec 02 §2) is the aggregate honesty check feeding the **Coverage/Fidelity** readiness gate. This is the energy analogue of M6's MSA gate / M5's reconciliation-gap discipline.

## 5. On-ramps & readiness

Four on-ramps → `readiness_snapshot`: (a) **M1 first-party** reads/bills/logs (v1, no hardware); (b) **ingest** existing EMS/utility-portal/historian via Manifold + energy sector template; (c) **automatic** interval meters/SCADA/BMS (edge collectors, switch-on); (d) **first-party** energy capture + portable-meter campaign where nothing exists. Gates: Required (carrier+output+meter present), **Coverage** (metered share vs apportioned), **Fidelity** (calibration/comms), **History** (interval days for prediction). UI shows honest confidence: "this furnace SEC is indicative (bill-apportioned, no sub-meter)".

## 6. Acceptance (this spec)

Manual reads + a bill produce balanced `energy_consumption` in GJ + CO₂e with correct basis/fidelity; the metering tree rolls child meters into parents without double counting; an uncalibrated meter is excluded from the baseline fit; the Coverage gate reports the metered share; switching a meter from MANUAL to AUTOMATIC raises fidelity with no schema change.
