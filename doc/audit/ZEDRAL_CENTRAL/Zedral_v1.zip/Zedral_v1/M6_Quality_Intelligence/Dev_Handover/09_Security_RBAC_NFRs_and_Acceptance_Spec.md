# 09 · Security, RBAC, NFRs & Acceptance Spec
**All phases · deep-plan §13**

## 1. RBAC (extends M1 Operator/Supervisor/Plant-Head/Admin)

| Role | Can |
|---|---|
| Operator / Inspector | record inline checks & measurements, log defects, see live SPC tile + reaction plan |
| Shift Supervisor | shift quality, defect Pareto, validate defect coding, raise/clear holds within authority |
| Quality Engineer | configure characteristics, spec limits, control plan, taxonomy, SPC rule-sets, sampling; run SPC/capability; chair routine disposition |
| MRB member | authorise non-routine dispositions (incl. downgrade/use-as-is) |
| CAPA owner / Quality Manager | own root-cause cases to verified close; manage CAPA backlog; read COQ |
| Cost / Finance analyst | read priced Cost of Quality (read-only) |
| Plant Manager | quality trends, COQ, hold/CAPA status (read-only) |
| Admin | masters, integration, capture/MSA config, quality policy |

## 2. Audit & record integrity (ISO 9001 / IATF 16949)

Every policy change (spec limit, control limit, disposition rule, taxonomy) is **audit-logged** with effective dating (`policy_change_log`) so a Cpk/defect trend is never silently broken by a re-definition, and every disposition is attributable to an authoriser. NCR/MRB/CAPA and `defect_record` are **append-only / audit-trailed** for record retention. Row-level scoping by site/area (RLS) as in M1. First-party/edge capture is **offline-tolerant** (queue locally, sync on reconnect).

## 3. NFRs

- **Latency** — live SPC tile & out-of-control alert near-real-time (D2, minutes default); capability recompute scheduled.
- **Determinism/replay** — recompute twice ⇒ identical charts/dispositions/COQ; corrected events re-derive without manual patching.
- **Scale** — measurement & SPC time-series on Timescale/ClickHouse; defect-Pareto heatmaps load-tested.
- **Isolation** — logical tenant isolation default, physical on request (D8).

## 4. Acceptance tests (MUST)

1. **No-double-count** — `defect_record.production_count_id` always references a canonical count; no produced quantity re-recorded.
2. **M6 ↔ M4 reconciliation** — M6 defect-driven Quality-loss == M4 Quality factor on a golden dataset (CI).
3. **M6 ↔ M5 reconciliation** — Σ M6 disposition material == Σ M5 priced loss for the same DefectRecords (CI).
4. **MSA gate** — an `UNACCEPTABLE` gage suppresses published Cpk (or flags low-confidence per config).
5. **SPC correctness** — WE/Nelson rules raise the right `spc_signal` on a seeded out-of-control series; common-cause noise raises none.
6. **Disposition integrity** — every non-conformance reaches exactly one disposition; downgrade carries from/to grade.
7. **CAPA closure gate** — a CAPA cannot close without `effectiveness_verified = TRUE`.
8. **Hold → M3** — `quality.hold.opened` produces a `QUALITY_HOLD` carryover.
9. **Back-test (MVP gate)** — existing defect rate / FPY / disposition mix agree with canonical to tolerance on a back-test window.
10. **RLS/security** — cross-tenant/site access denied.

**Golden dataset:** a Hero Steels shift with known coils, measurements (thickness/hardness), surface defects, and dispositions (incl. a prime→second downgrade) by COIL_NO.

## 5. Acceptance — SHOULD

Pareto-by-cost ranks above Pareto-by-count where they differ; "Other" auto-split prompt fires at threshold; certificate-of-analysis renders per coil; CAPA recurrence-rate KPI computes.
