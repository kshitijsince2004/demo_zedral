# 01 · Data Model & Schema Spec
**Build:** Phase M7-0 · **Runnable DDL:** `energy_schema.sql` (PostgreSQL 15+, schema `energy`, pglast-valid 50 statements: 19 enums, 22 tables, 3 indexes, 4 views)

> The *why* is deep-plan §6 (carriers/SEU/SoR) and §11 (data contract). This spec is the **what** the engineer builds against. M7 is the energy system-of-record: `meter`, `meter_reading`, `energy_consumption` are **mastered here**, but every consumption row is anchored to the *one* shared `canon.production_count` (EnPI denominator), `canon.state_interval` (M4 state) and `canon.material_lot` (genealogy) — so a tonne of steel and the energy that made it are recorded **once** and reconcile by construction.

## 1. Entity groups (22 tables)

**Reference & policy (6):** `energy_config` (per-tenant policy: energy basis, default baseline method, demand window, PF threshold, balance-gap tolerance, normalisation drivers, carbon-in-waste), `energy_carrier` (carrier + `gj_per_native_unit` + default scope), `emission_factor` (effective-dated kgCO₂e/GJ per carrier×scope×region), `seu` (Significant Energy Use register), `tariff` (demand/PF/fixed/carbon structure, effective-dated), `tariff_period` (ToU windows + energy rate).

**Metering & capture (3):** `meter` (hierarchy via `parent_meter_ref`, carrier, asset node, multiplier, comms protocol, health, calibration), `meter_reading` (raw cumulative/interval, kVA/PF registers), `utility_bill` (boundary invoice decomposition — v1 primary source).

**Consumption spine (1):** `energy_consumption` — the canonical carrier-normalised fact (native + GJ + CO₂e, `direction`, `basis`, `fidelity`, `allocation_method`, window), anchored to `production_count_id` / `state_interval_ref` / `material_lot_ref` / `seu_ref`.

**Balance, baseline, EnPI, M&V (4):** `energy_balance` (purchased+generated = distributed+loss+gap), `enpi_definition` (numerator scope ÷ denominator driver), `energy_baseline` (EnB regression: intercept + `coefficients` JSONB + R²; versioned), `enpi_value` (per-period actual/expected/variance/CUSUM/avoided).

**Demand, carbon, cost, waste (4):** `demand_interval` (max-demand & PF; peak events), `emission_entry` (computed Scope 1/2 carbon), `energy_cost_entry` (priced per tariff component, rate-as-of), `energy_waste_entry` (ranked avoidable waste, ₹ + carbon, with M4/M5/M6 anchors).

**Targets, governance, readiness, prediction (4):** `energy_target` (ISO 50001 objectives), `policy_change_log` (audit), `readiness_snapshot` (Required/Coverage/Fidelity/History gates), `energy_prediction` (future stub, `is_active=FALSE`).

## 2. The no-double-count anchor (the most important rule)

`energy_consumption.production_count_id` is the canonical `ProductionCount` — the **same** row M4 reads for OEE, M5 for yield, M6 for conformance. M7 never recomputes production, state, yield or defect:

- **EnPI denominator** = `SUM` of the production tonnes on those `production_count_id`s — identical to the number under OEE/yield/quality.
- **Idle-energy waste** (`energy_waste_entry.state_interval_ref`) is tied to the **same** `canon.state_interval` M4 classified as idle/down — one state, two costs (lost time + idle energy).
- **Embodied-energy waste** for loss/defect (`m5_loss_ref` / `m6_defect_ref`) is the energy spent on the **same** units M5 prices as material loss and M6 classifies as defective — counted **once**, never re-priced as a separate loss.

## 3. DDL conventions (inherit canonical 02 §5)

`lower_snake_case`; surrogate `BIGINT … GENERATED ALWAYS AS IDENTITY`; `UUID tenant_id`; `TIMESTAMPTZ` UTC; units in the column name (`quantity_gj`, `co2e_kg`, `kva_demand`); `JSONB ext` extension namespace on every table; **hard FK only to `canon.*` and within `energy.*`**; other-module references are soft `*_ref` BIGINT. Reserved word `window` avoided (`window_kind`).

## 4. Key constraints & indexes

`UNIQUE (tenant_id, code)` on carrier/SEU/meter/EnPI; `UNIQUE (tenant_id, meter_ref, read_at)` on readings; `UNIQUE (tenant_id, enpi_ref, version_no)` on baselines (version history preserved for audit); window `CHECK (end >= start)` throughout; indexes on `energy_consumption` by (carrier, window), (SEU, window) and (production_count_id) for the reconciliation join. `meter_reading` and `enpi_value`/`demand_interval` are TimescaleDB hypertable candidates (time-series).

## 5. Views (SUM-then-divide)

`v_energy_rollup` (GJ + CO₂e by carrier×month), `v_enpi_rollup` (Σenergy ÷ Σdriver — never average ratios), `v_energy_balance_recon` (boundary vs accounted + gap%), `v_carbon_rollup` (by scope×month). These are the Serving projections UIL/Reporting read.
