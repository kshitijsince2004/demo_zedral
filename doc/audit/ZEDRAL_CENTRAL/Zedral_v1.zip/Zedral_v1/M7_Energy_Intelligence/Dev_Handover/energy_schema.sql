-- =====================================================================
-- Zedral · M7 Energy Intelligence — Reference Schema (PostgreSQL 15+)
-- Status: v1 for build (dual-lens energy: ABSOLUTE consumption/cost/carbon
--         + NORMALISED intensity/EnPI vs regression baseline; all-utilities
--         multi-carrier energy balance; SEU register; ISO 50006 EnB/EnPI;
--         IPMVP M&V; maximum-demand / power-factor / time-of-use; GHG
--         Scope 1/2 + ISO 14404 steel CO2 intensity; priced energy waste).
--         v1 bootstraps from M1 manual meter reads / utility bills / fuel-DG
--         logs; automatic interval metering, SCADA/historian & BMS streaming
--         future-proofed -> the full-EnMS metering platform (deep-plan §5).
--         Forecast / anomaly / energy-signature / demand-response & tariff-
--         optimisation hooks present, build deferred (§8).
-- Conventions: follows canonical DDL spec (02_CanonicalDataModel_Spec §5):
--   lower_snake_case · surrogate BIGINT ids · UUID tenant_id · TIMESTAMPTZ (UTC)
--   JSONB `ext` extension namespace · FK to canon.* · units embedded in column name.
-- Assumes the canonical core already exists:
--   canon.equipment_node(node_id)      -- ISA-95 hierarchy (SITE/AREA/WORK_CENTER/WORK_UNIT) = metering tree
--   canon.event(event_id)              -- Event Spine; energy_consumption may register on it
--   canon.production_count(count_id)   -- good/scrap/rework/total (+ weight) — the shared EnPI denominator
--   canon.state_interval(interval_id, state) -- M4 running/idle/down (energy-by-state)
--   canon.material_lot(lot_id, parent_lot_id) -- genealogy spine (M1 COIL_NO)
--   canon.material(material_id)        -- material/grade reference (grade = material variant)
--   canon.shift(shift_id)              -- shift/calendar (the period spine)
--   canon.cost_rate(rate_id ...)       -- effective-dated rates / tariff anchor (D7)
-- OWNERSHIP NOTE: M7 is the energy-and-carbon system-of-record, so Meter,
--   MeterReading and EnergyConsumption physically live in and are MASTERED by
--   this `energy` schema (like M6's conformance record; unlike pure thin-write
--   M4/M5). Every energy_consumption is anchored to the SAME canon.production_count
--   (EnPI denominator), canon.state_interval (M4 state) and canon.material_lot
--   (M5/M6 genealogy) the other modules read — so a tonne of steel and the
--   energy that made it are recorded ONCE and reconcile by construction.
-- SOFT-REFERENCE RULE: references to OTHER module schemas (e.g. ops.route in M3,
--   maint.work_order in M2, the M5 loss row, the M6 defect_record) are plain BIGINT
--   *_ref values with NO cross-schema hard FK. Hard FKs only to canon.* and within energy.*.
-- THE no-double-count anchor: energy.energy_consumption.production_count_id is the
--   canonical ProductionCount; M7's embodied-energy-of-loss == the energy spent on the
--   SAME units M5 prices as material loss and M6 classifies as defective (counted once,
--   deep-plan §12), and the idle-energy loss is tied to the SAME canon.state_interval M4 owns.
-- =====================================================================

CREATE SCHEMA IF NOT EXISTS energy;
SET search_path = energy, canon, public;

-- ---------------------------------------------------------------------
-- 0. Enumerated types
-- ---------------------------------------------------------------------
CREATE TYPE energy.carrier_kind      AS ENUM ('ELECTRICITY_GRID','ELECTRICITY_CAPTIVE','NATURAL_GAS','FUEL_OIL','LPG','COAL','STEAM','COMPRESSED_AIR','WATER','CHILLED_WATER','SOLAR','RECOVERED_HEAT','OTHER');
CREATE TYPE energy.meter_kind        AS ENUM ('BOUNDARY','AREA','FEEDER','SUB','MACHINE','VIRTUAL');
CREATE TYPE energy.meter_health      AS ENUM ('OK','UNCALIBRATED','STALE_COMMS','FAULT','NOT_ASSESSED');
CREATE TYPE energy.capture_fidelity  AS ENUM ('MANUAL','BILL','INGESTED','AUTOMATIC');
CREATE TYPE energy.consumption_basis AS ENUM ('METERED','BILLED','CALCULATED','APPORTIONED','ESTIMATED');
CREATE TYPE energy.flow_direction    AS ENUM ('PURCHASED','GENERATED','CONSUMED','EXPORTED','LOSS');
CREATE TYPE energy.seu_class         AS ENUM ('PROCESS_HEATING','COMPRESSED_AIR','MOTOR_DRIVE','PUMPING','FAN','STEAM','HVAC','LIGHTING','PROCESS_COOLING','GENERAL_UNALLOCATED','OTHER');
CREATE TYPE energy.baseline_method   AS ENUM ('SIMPLE_RATIO','REGRESSION','IPMVP_A','IPMVP_B','IPMVP_C','IPMVP_D');
CREATE TYPE energy.enpi_kind         AS ENUM ('ABSOLUTE','SPECIFIC','REGRESSION_NORMALISED');
CREATE TYPE energy.ghg_scope         AS ENUM ('SCOPE_1','SCOPE_2_LOCATION','SCOPE_2_MARKET','SCOPE_3');
CREATE TYPE energy.tariff_component  AS ENUM ('ENERGY_TOU','DEMAND','FIXED_CAPACITY','POWER_FACTOR','FUEL_SURCHARGE','TAX','CARBON');
CREATE TYPE energy.tou_period        AS ENUM ('PEAK','SHOULDER','OFF_PEAK','NORMAL');
CREATE TYPE energy.demand_window     AS ENUM ('MIN_15','MIN_30');
CREATE TYPE energy.demand_event_kind AS ENUM ('PEAK_APPROACH','PEAK_BREACH','PF_PENALTY');
CREATE TYPE energy.cost_category     AS ENUM ('ENERGY_CHARGE','DEMAND_CHARGE','PF_PENALTY','FUEL_COST','CARBON_COST','FIXED_CAPACITY');
CREATE TYPE energy.waste_category    AS ENUM ('IDLE_STANDBY','AIR_LEAK','DEMAND_PEAK','POWER_FACTOR','OFF_BASELINE','EMBODIED_SCRAP','ON_PEAK_SHIFTABLE','OTHER');
CREATE TYPE energy.readiness_gate    AS ENUM ('REQUIRED','COVERAGE','FIDELITY','HISTORY');
CREATE TYPE energy.time_grain        AS ENUM ('INTERVAL','SHIFT','DAY','WEEK','MONTH');
CREATE TYPE energy.energy_basis      AS ENUM ('FINAL','PRIMARY','SOURCE');

-- ---------------------------------------------------------------------
-- 1. Energy reference & policy
-- ---------------------------------------------------------------------

-- 1.1 Per-tenant energy policy (definitions-as-configuration)
CREATE TABLE energy.energy_config (
    config_id              BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id              UUID         NOT NULL,
    energy_basis           energy.energy_basis NOT NULL DEFAULT 'FINAL',     -- final vs primary/source GJ
    default_baseline_method energy.baseline_method NOT NULL DEFAULT 'SIMPLE_RATIO',
    demand_window          energy.demand_window NOT NULL DEFAULT 'MIN_30',   -- max-demand averaging window
    pf_penalty_threshold   NUMERIC(4,3) NOT NULL DEFAULT 0.950,              -- below -> kVA penalty
    balance_gap_tolerance  NUMERIC(5,2) NOT NULL DEFAULT 5.00,               -- % unmetered gap flagged
    normalisation_drivers  TEXT[]       NOT NULL DEFAULT ARRAY['PRODUCTION'],-- PRODUCTION/WEATHER/MIX/CHARGE_TEMP
    carbon_in_waste        BOOLEAN      NOT NULL DEFAULT TRUE,               -- price carbon inside waste register
    reporting_period       energy.time_grain NOT NULL DEFAULT 'MONTH',
    effective_from         TIMESTAMPTZ  NOT NULL DEFAULT now(),
    effective_to           TIMESTAMPTZ,
    ext                    JSONB        NOT NULL DEFAULT '{}'::jsonb,
    created_at             TIMESTAMPTZ  NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, effective_from)
);

-- 1.2 Energy carrier master (carrier -> common unit GJ + default emission scope)
CREATE TABLE energy.energy_carrier (
    carrier_id           BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    carrier_kind         energy.carrier_kind NOT NULL,
    code                 TEXT        NOT NULL,                   -- e.g. ELEC_GRID, FURNACE_GAS, CA_HEADER
    name                 TEXT        NOT NULL,
    native_uom           TEXT        NOT NULL,                   -- kWh, m3, tonne, Nm3 ...
    gj_per_native_unit   NUMERIC(16,8) NOT NULL,                 -- common-unit conversion (NCV / enthalpy / 3.6e-3)
    default_scope        energy.ghg_scope NOT NULL DEFAULT 'SCOPE_2_LOCATION',
    is_self_generated    BOOLEAN     NOT NULL DEFAULT FALSE,
    is_active            BOOLEAN     NOT NULL DEFAULT TRUE,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, code)
);

-- 1.3 Emission factor library (effective-dated; per carrier x scope x region — "rate-as-of")
CREATE TABLE energy.emission_factor (
    factor_id            BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    carrier_ref          BIGINT      NOT NULL REFERENCES energy.energy_carrier(carrier_id),
    scope                energy.ghg_scope NOT NULL,
    region_code          TEXT,                                   -- grid region / supplier (NULL = default)
    kgco2e_per_gj        NUMERIC(14,5) NOT NULL,                 -- combustion / grid factor
    source_label         TEXT,                                   -- IEA / national grid / supplier PPA
    effective_from       DATE        NOT NULL,
    effective_to         DATE,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, carrier_ref, scope, region_code, effective_from)
);

-- 1.4 Significant Energy Use register (ISO 50001 §6.3; DOE system taxonomy)
CREATE TABLE energy.seu (
    seu_id               BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    code                 TEXT        NOT NULL,                   -- e.g. REHEAT_FURNACE, MILL_MAIN_DRIVE
    name                 TEXT        NOT NULL,
    seu_class            energy.seu_class NOT NULL,
    asset_node_ref       BIGINT      REFERENCES canon.equipment_node(node_id),
    cost_centre_ref      BIGINT,                                 -- soft ref (finance dimension)
    energy_share_pct     NUMERIC(5,2),                           -- share of plant energy (Pareto)
    relevant_variables   TEXT[]      NOT NULL DEFAULT ARRAY['PRODUCTION'],
    is_active            BOOLEAN     NOT NULL DEFAULT TRUE,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, code)
);

-- 1.5 Tariff master (the bill structure — not one number)
CREATE TABLE energy.tariff (
    tariff_id            BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    carrier_ref          BIGINT      NOT NULL REFERENCES energy.energy_carrier(carrier_id),
    code                 TEXT        NOT NULL,
    name                 TEXT        NOT NULL,
    contracted_demand_kva NUMERIC(14,2),                         -- the demand cap (NULL = read from bill)
    demand_charge_per_kva NUMERIC(14,4),
    pf_penalty_per_kvarh NUMERIC(14,4),
    fixed_capacity_charge NUMERIC(14,4),
    carbon_price_per_tonne NUMERIC(14,4),
    currency             TEXT        NOT NULL DEFAULT 'INR',
    effective_from       DATE        NOT NULL,
    effective_to         DATE,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, code, effective_from)
);

-- 1.6 Tariff time-of-use periods (peak / shoulder / off-peak windows + energy rate)
CREATE TABLE energy.tariff_period (
    period_id            BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tariff_ref           BIGINT      NOT NULL REFERENCES energy.tariff(tariff_id),
    tou_period           energy.tou_period NOT NULL,
    day_start_minute     INT         NOT NULL DEFAULT 0,         -- minute-of-day window start
    day_end_minute       INT         NOT NULL DEFAULT 1440,
    energy_rate_per_kwh   NUMERIC(14,5) NOT NULL,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    CHECK (day_start_minute >= 0 AND day_end_minute <= 1440 AND day_start_minute < day_end_minute)
);

-- ---------------------------------------------------------------------
-- 2. Metering & capture
-- ---------------------------------------------------------------------

-- 2.1 Meter master (the metering hierarchy; manual or automatic) + device management
CREATE TABLE energy.meter (
    meter_id             BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    carrier_ref          BIGINT      NOT NULL REFERENCES energy.energy_carrier(carrier_id),
    asset_node_ref       BIGINT      REFERENCES canon.equipment_node(node_id), -- where it sits in the tree
    parent_meter_ref     BIGINT      REFERENCES energy.meter(meter_id),         -- metering hierarchy
    seu_ref              BIGINT      REFERENCES energy.seu(seu_id),
    code                 TEXT        NOT NULL,
    meter_kind           energy.meter_kind NOT NULL DEFAULT 'SUB',
    capture_fidelity     energy.capture_fidelity NOT NULL DEFAULT 'MANUAL',
    multiplier           NUMERIC(14,5) NOT NULL DEFAULT 1.0,     -- CT/PT ratio etc.
    comms_protocol       TEXT,                                   -- MODBUS / DNP3 / IEC61850 / DLMS / OPCUA
    health               energy.meter_health NOT NULL DEFAULT 'NOT_ASSESSED',
    last_calibrated_on   DATE,
    has_demand_register  BOOLEAN     NOT NULL DEFAULT FALSE,     -- tracks kVA/PF (electricity)
    is_active            BOOLEAN     NOT NULL DEFAULT TRUE,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, code)
);

-- 2.2 Meter reading (raw cumulative or interval value; TimescaleDB hypertable candidate)
CREATE TABLE energy.meter_reading (
    reading_id           BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    meter_ref            BIGINT      NOT NULL REFERENCES energy.meter(meter_id),
    read_at              TIMESTAMPTZ NOT NULL,
    interval_seconds     INT,                                    -- NULL = spot/cumulative, else interval length
    value_native         NUMERIC(18,5) NOT NULL,                 -- reading in carrier native unit
    is_cumulative        BOOLEAN     NOT NULL DEFAULT TRUE,      -- cumulative register vs interval delta
    kva_peak             NUMERIC(14,3),                          -- demand register (electricity)
    power_factor         NUMERIC(4,3),
    source_fidelity      energy.capture_fidelity NOT NULL DEFAULT 'MANUAL',
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, meter_ref, read_at)
);

-- 2.3 Utility bill (the boundary invoice decomposition — v1 primary source)
CREATE TABLE energy.utility_bill (
    bill_id              BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    carrier_ref          BIGINT      NOT NULL REFERENCES energy.energy_carrier(carrier_id),
    tariff_ref           BIGINT      REFERENCES energy.tariff(tariff_id),
    period_start         DATE        NOT NULL,
    period_end           DATE        NOT NULL,
    consumption_native   NUMERIC(18,3) NOT NULL,                 -- billed kWh / m3 / GJ
    max_demand_kva       NUMERIC(14,3),
    power_factor         NUMERIC(4,3),
    energy_charge        NUMERIC(16,2),
    demand_charge        NUMERIC(16,2),
    pf_penalty           NUMERIC(16,2),
    fuel_charge          NUMERIC(16,2),
    other_charge         NUMERIC(16,2),
    total_amount         NUMERIC(16,2),
    currency             TEXT        NOT NULL DEFAULT 'INR',
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (period_end >= period_start)
);

-- ---------------------------------------------------------------------
-- 3. The energy consumption spine (M7's system-of-record)
-- ---------------------------------------------------------------------

-- 3.1 EnergyConsumption — the canonical, carrier-normalised consumption fact
CREATE TABLE energy.energy_consumption (
    consumption_id       BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    event_id             BIGINT      REFERENCES canon.event(event_id),         -- optional Event-Spine registration
    carrier_ref          BIGINT      NOT NULL REFERENCES energy.energy_carrier(carrier_id),
    meter_ref            BIGINT      REFERENCES energy.meter(meter_id),         -- NULL when bill/apportioned
    seu_ref              BIGINT      REFERENCES energy.seu(seu_id),
    asset_node_ref       BIGINT      REFERENCES canon.equipment_node(node_id),
    -- shared canonical anchors (no-double-count):
    production_count_id  BIGINT      REFERENCES canon.production_count(count_id), -- EnPI denominator (shared)
    state_interval_ref   BIGINT,                                 -- soft ref to canon.state_interval (M4 state)
    material_lot_ref     BIGINT      REFERENCES canon.material_lot(lot_id),     -- COIL_NO genealogy
    shift_ref            BIGINT      REFERENCES canon.shift(shift_id),
    -- quantities:
    quantity_native      NUMERIC(18,5) NOT NULL,                 -- in carrier native unit
    quantity_gj          NUMERIC(18,6) NOT NULL,                 -- common-unit energy
    co2e_kg              NUMERIC(18,4),                          -- derived carbon (Scope 1/2)
    direction            energy.flow_direction NOT NULL DEFAULT 'CONSUMED',
    basis                energy.consumption_basis NOT NULL DEFAULT 'METERED',
    fidelity             energy.capture_fidelity NOT NULL DEFAULT 'MANUAL',
    allocation_method    TEXT,                                   -- RUNTIME / THROUGHPUT / CONNECTED_LOAD (if APPORTIONED)
    window_start         TIMESTAMPTZ NOT NULL,
    window_end           TIMESTAMPTZ NOT NULL,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (window_end >= window_start)
);
CREATE INDEX ix_consumption_carrier_window ON energy.energy_consumption (tenant_id, carrier_ref, window_start);
CREATE INDEX ix_consumption_seu            ON energy.energy_consumption (tenant_id, seu_ref, window_start);
CREATE INDEX ix_consumption_prodcount      ON energy.energy_consumption (production_count_id);

-- ---------------------------------------------------------------------
-- 4. Energy balance, baseline, EnPI & M&V
-- ---------------------------------------------------------------------

-- 4.1 Energy balance (per carrier x period): purchased+generated = distributed+loss+gap
CREATE TABLE energy.energy_balance (
    balance_id           BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    carrier_ref          BIGINT      NOT NULL REFERENCES energy.energy_carrier(carrier_id),
    asset_node_ref       BIGINT      REFERENCES canon.equipment_node(node_id), -- boundary scope (NULL = plant)
    grain                energy.time_grain NOT NULL DEFAULT 'MONTH',
    period_start         TIMESTAMPTZ NOT NULL,
    period_end           TIMESTAMPTZ NOT NULL,
    purchased_gj         NUMERIC(18,6) NOT NULL DEFAULT 0,
    generated_gj         NUMERIC(18,6) NOT NULL DEFAULT 0,
    distributed_gj       NUMERIC(18,6) NOT NULL DEFAULT 0,       -- sum sub-metered/apportioned
    measured_loss_gj     NUMERIC(18,6) NOT NULL DEFAULT 0,
    unmetered_gap_gj     NUMERIC(18,6) NOT NULL DEFAULT 0,       -- coverage gap (data honesty, NOT waste)
    gap_pct              NUMERIC(7,3),                           -- gap / boundary energy
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (period_end >= period_start)
);

-- 4.2 EnPI definition (numerator energy scope ÷ denominator driver; normalisation)
CREATE TABLE energy.enpi_definition (
    enpi_id              BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    code                 TEXT        NOT NULL,                   -- e.g. FURNACE_GJ_PER_T, MILL_KWH_PER_T
    name                 TEXT        NOT NULL,
    enpi_kind            energy.enpi_kind NOT NULL DEFAULT 'SPECIFIC',
    seu_ref              BIGINT      REFERENCES energy.seu(seu_id),
    carrier_ref          BIGINT      REFERENCES energy.energy_carrier(carrier_id),
    numerator_uom        TEXT        NOT NULL DEFAULT 'GJ',
    denominator_driver   TEXT        NOT NULL DEFAULT 'PRODUCTION_TONNE',
    grade_ref            BIGINT      REFERENCES canon.material(material_id),    -- grade-relative EnPI (NULL = all)
    is_active            BOOLEAN     NOT NULL DEFAULT TRUE,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, code)
);

-- 4.3 Energy baseline (EnB) — the regression / ratio model fitted over a reference period
CREATE TABLE energy.energy_baseline (
    baseline_id          BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    enpi_ref             BIGINT      NOT NULL REFERENCES energy.enpi_definition(enpi_id),
    method               energy.baseline_method NOT NULL DEFAULT 'SIMPLE_RATIO',
    baseline_from        DATE        NOT NULL,
    baseline_to          DATE        NOT NULL,
    intercept_gj         NUMERIC(18,6),                          -- beta0 = standing/no-load energy
    coefficients         JSONB       NOT NULL DEFAULT '{}'::jsonb, -- {production: b1, hdd: b2, mix: b3 ...}
    r_squared            NUMERIC(5,4),
    version_no           INT         NOT NULL DEFAULT 1,
    is_current           BOOLEAN     NOT NULL DEFAULT TRUE,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (baseline_to >= baseline_from),
    UNIQUE (tenant_id, enpi_ref, version_no)
);

-- 4.4 EnPI value (computed per period: actual + baseline-expected + variance / avoided)
CREATE TABLE energy.enpi_value (
    enpi_value_id        BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    enpi_ref             BIGINT      NOT NULL REFERENCES energy.enpi_definition(enpi_id),
    baseline_ref         BIGINT      REFERENCES energy.energy_baseline(baseline_id),
    grain                energy.time_grain NOT NULL DEFAULT 'MONTH',
    period_start         TIMESTAMPTZ NOT NULL,
    period_end           TIMESTAMPTZ NOT NULL,
    energy_gj            NUMERIC(18,6) NOT NULL,
    driver_value         NUMERIC(18,4),                          -- e.g. tonnes produced
    enpi_actual          NUMERIC(18,6),                          -- energy / driver
    enpi_expected        NUMERIC(18,6),                          -- baseline model at this period's drivers
    variance_gj          NUMERIC(18,6),                          -- actual − expected (residual)
    cusum_gj             NUMERIC(18,6),                          -- running CUSUM of residuals
    avoided_energy_gj    NUMERIC(18,6),                          -- M&V (IPMVP) saving
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (period_end >= period_start),
    UNIQUE (tenant_id, enpi_ref, grain, period_start)
);

-- ---------------------------------------------------------------------
-- 5. Demand, power quality, carbon & cost
-- ---------------------------------------------------------------------

-- 5.1 Demand interval (max-demand & power-factor tracking; peak-approach events)
CREATE TABLE energy.demand_interval (
    demand_id            BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    meter_ref            BIGINT      NOT NULL REFERENCES energy.meter(meter_id),
    window_kind          energy.demand_window NOT NULL DEFAULT 'MIN_30',
    window_start         TIMESTAMPTZ NOT NULL,
    avg_kw               NUMERIC(14,3),
    kva_demand           NUMERIC(14,3),
    power_factor         NUMERIC(4,3),
    contracted_cap_kva   NUMERIC(14,2),
    event_kind           energy.demand_event_kind,               -- NULL = normal interval
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, meter_ref, window_start)
);

-- 5.2 Emission entry (computed carbon per consumption x scope; location & market both)
CREATE TABLE energy.emission_entry (
    emission_id          BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    consumption_ref      BIGINT      REFERENCES energy.energy_consumption(consumption_id),
    factor_ref           BIGINT      REFERENCES energy.emission_factor(factor_id),
    scope                energy.ghg_scope NOT NULL,
    energy_gj            NUMERIC(18,6) NOT NULL,
    co2e_kg              NUMERIC(18,4) NOT NULL,
    period_start         TIMESTAMPTZ NOT NULL,
    period_end           TIMESTAMPTZ NOT NULL,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (period_end >= period_start)
);

-- 5.3 Energy cost entry (priced consumption per tariff component)
CREATE TABLE energy.energy_cost_entry (
    cost_id              BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    consumption_ref      BIGINT      REFERENCES energy.energy_consumption(consumption_id),
    tariff_ref           BIGINT      REFERENCES energy.tariff(tariff_id),
    cost_category        energy.cost_category NOT NULL,
    tou_period           energy.tou_period,
    amount               NUMERIC(16,4) NOT NULL,
    currency             TEXT        NOT NULL DEFAULT 'INR',
    rate_as_of           DATE        NOT NULL,                   -- D7 rate-as-of-event provenance
    period_start         TIMESTAMPTZ NOT NULL,
    period_end           TIMESTAMPTZ NOT NULL,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (period_end >= period_start)
);

-- 5.4 Energy waste entry (the ranked avoidable-waste register, ₹ + carbon)
CREATE TABLE energy.energy_waste_entry (
    waste_id             BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    waste_category       energy.waste_category NOT NULL,
    seu_ref              BIGINT      REFERENCES energy.seu(seu_id),
    asset_node_ref       BIGINT      REFERENCES canon.equipment_node(node_id),
    -- shared anchors so embodied-energy reconciles & is counted once (deep-plan §12):
    state_interval_ref   BIGINT,                                 -- M4 idle state (idle-energy)
    production_count_id  BIGINT      REFERENCES canon.production_count(count_id),
    m5_loss_ref          BIGINT,                                 -- soft ref to M5 loss row
    m6_defect_ref        BIGINT,                                 -- soft ref to M6 defect_record
    energy_gj            NUMERIC(18,6),
    co2e_kg              NUMERIC(18,4),
    amount               NUMERIC(16,4),
    currency             TEXT        NOT NULL DEFAULT 'INR',
    grain                energy.time_grain NOT NULL DEFAULT 'MONTH',
    period_start         TIMESTAMPTZ NOT NULL,
    period_end           TIMESTAMPTZ NOT NULL,
    is_avoidable         BOOLEAN     NOT NULL DEFAULT TRUE,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (period_end >= period_start)
);

-- ---------------------------------------------------------------------
-- 6. Targets, governance, readiness & prediction (future)
-- ---------------------------------------------------------------------

-- 6.1 Energy target (EnPI / consumption / CO2 objective — ISO 50001 objectives)
CREATE TABLE energy.energy_target (
    target_id            BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    enpi_ref             BIGINT      REFERENCES energy.enpi_definition(enpi_id),
    seu_ref              BIGINT      REFERENCES energy.seu(seu_id),
    metric               TEXT        NOT NULL,                   -- ENPI / CONSUMPTION_GJ / CO2_INTENSITY
    target_value         NUMERIC(18,6) NOT NULL,
    target_period_start  DATE        NOT NULL,
    target_period_end    DATE        NOT NULL,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (target_period_end >= target_period_start)
);

-- 6.2 Policy change log (audit every config/baseline/factor change — ISO 50001 traceability)
CREATE TABLE energy.policy_change_log (
    change_id            BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    entity_kind          TEXT        NOT NULL,                   -- CONFIG / BASELINE / EMISSION_FACTOR / TARIFF / CARRIER
    entity_ref           BIGINT,
    change_summary       TEXT        NOT NULL,
    changed_by           TEXT,
    effective_from       TIMESTAMPTZ NOT NULL DEFAULT now(),
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 6.3 Readiness snapshot (Required + Coverage + Fidelity + History gates)
CREATE TABLE energy.readiness_snapshot (
    snapshot_id          BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    seu_ref              BIGINT      REFERENCES energy.seu(seu_id),
    gate                 energy.readiness_gate NOT NULL,
    score_pct            NUMERIC(5,2),
    metered_coverage_pct NUMERIC(5,2),                           -- share of energy actually sub-metered
    balance_gap_pct      NUMERIC(7,3),
    history_days         INT,                                    -- interval history accumulated
    detail               JSONB       NOT NULL DEFAULT '{}'::jsonb,
    captured_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 6.4 Energy prediction (FUTURE-SCOPE stub; dark in v1 — deep-plan §8)
CREATE TABLE energy.energy_prediction (
    prediction_id        BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    seu_ref              BIGINT      REFERENCES energy.seu(seu_id),
    model_kind           TEXT        NOT NULL,                   -- LOAD_FORECAST / DEMAND_PEAK / EXCESS_ANOMALY / ENERGY_SIGNATURE / TARIFF_OPT
    horizon_minutes      INT,
    predicted_value      NUMERIC(18,6),
    predicted_for        TIMESTAMPTZ,
    is_active            BOOLEAN     NOT NULL DEFAULT FALSE,      -- dark until History gate passes
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------
-- 7. Serving roll-up views (SUM-then-divide — never average sub-ratios)
-- ---------------------------------------------------------------------

-- 7.1 Energy & carbon roll-up by carrier x period (absolute lens)
CREATE VIEW energy.v_energy_rollup AS
SELECT c.tenant_id,
       c.carrier_ref,
       date_trunc('month', c.window_start) AS period_month,
       SUM(c.quantity_gj)                  AS total_gj,
       SUM(c.co2e_kg)                      AS total_co2e_kg
FROM energy.energy_consumption c
WHERE c.direction = 'CONSUMED'
GROUP BY c.tenant_id, c.carrier_ref, date_trunc('month', c.window_start);

-- 7.2 EnPI roll-up (SUM energy / SUM driver — never average the per-period ratios)
CREATE VIEW energy.v_enpi_rollup AS
SELECT v.tenant_id,
       v.enpi_ref,
       date_trunc('month', v.period_start) AS period_month,
       SUM(v.energy_gj)                    AS total_energy_gj,
       SUM(v.driver_value)                 AS total_driver,
       CASE WHEN SUM(v.driver_value) > 0
            THEN SUM(v.energy_gj) / SUM(v.driver_value) END AS enpi_actual,
       SUM(v.avoided_energy_gj)            AS total_avoided_gj
FROM energy.enpi_value v
GROUP BY v.tenant_id, v.enpi_ref, date_trunc('month', v.period_start);

-- 7.3 Energy-balance reconciliation (the metering-coverage gap, named honestly)
CREATE VIEW energy.v_energy_balance_recon AS
SELECT b.tenant_id,
       b.carrier_ref,
       b.period_start,
       (b.purchased_gj + b.generated_gj)                              AS boundary_gj,
       (b.distributed_gj + b.measured_loss_gj)                        AS accounted_gj,
       b.unmetered_gap_gj,
       CASE WHEN (b.purchased_gj + b.generated_gj) > 0
            THEN 100.0 * b.unmetered_gap_gj / (b.purchased_gj + b.generated_gj) END AS gap_pct
FROM energy.energy_balance b;

-- 7.4 Carbon roll-up by scope x period (Scope 1 / 2-location / 2-market)
CREATE VIEW energy.v_carbon_rollup AS
SELECT e.tenant_id,
       e.scope,
       date_trunc('month', e.period_start) AS period_month,
       SUM(e.co2e_kg)                      AS total_co2e_kg
FROM energy.emission_entry e
GROUP BY e.tenant_id, e.scope, date_trunc('month', e.period_start);

-- =====================================================================
-- End of energy schema. Reconciliation contracts (enforced as CI tests, spec 06/09):
--   (1) EnPI denominator == canon.production_count tonnes M4/M5/M6 use (one number).
--   (2) idle-energy waste tied to the SAME canon.state_interval M4 classified as down/idle.
--   (3) Sum(embodied-energy waste for loss/defect reasons) == energy spent on the SAME
--       canon.production_count / M5-loss / M6-defect units (counted once; never re-priced).
--   (4) energy balance: purchased+generated == distributed+loss+gap (gap = coverage, not waste).
-- =====================================================================
