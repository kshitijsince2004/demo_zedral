-- =====================================================================
-- Zedral · M6 Quality Intelligence — Reference Schema (PostgreSQL 15+)
-- Status: v1 for build (dual-lens conformance: ATTRIBUTE defect/disposition
--         + VARIABLE measurement/SPC/capability; governed defect taxonomy;
--         quality holds; NCR -> MRB -> disposition incl. grade-downgrade;
--         CAPA/8D root cause; Cost of Quality P/A/IF/EF). v1 bootstraps from
--         M1 manual inline checks / defect logging / entered lab results;
--         inline gauge / lab / surface-vision future-proofed (deep-plan §5).
--         Prediction & visual-defect hooks present, build deferred (§8).
-- Conventions: follows canonical DDL spec (02_CanonicalDataModel_Spec §5):
--   lower_snake_case · surrogate BIGINT ids · UUID tenant_id · TIMESTAMPTZ (UTC)
--   JSONB `ext` extension namespace · FK to canon.* · units embedded in column name.
-- Assumes the canonical core already exists:
--   canon.equipment_node(node_id)      -- ISA-95 hierarchy incl. WORK_CENTER & WORK_UNIT
--   canon.event(event_id)              -- Event Spine; defect_record specialises it
--   canon.production_count(count_id)   -- good/scrap/rework/total (+ weight) — the shared count
--   canon.material_lot(lot_id, parent_lot_id) -- genealogy spine (M1 COIL_NO)
--   canon.material(material_id)        -- material/grade reference (grade = material variant)
--   canon.shift(shift_id)              -- shift/calendar
--   canon.loss_category(category_id, oee_component) -- Six Big Losses (ISO 22400/TPM)
--   canon.cost_rate(rate_id ...)       -- effective-dated rates (D7)
-- OWNERSHIP NOTE: M6 is the quality system-of-record, so DefectCode and
--   DefectRecord physically live in and are MASTERED by this `qual` schema
--   (unlike M4/M5 which are pure thin-write). defect_record is REGISTERED on the
--   canonical Event Spine via event_id and anchored to the SAME canon.production_count
--   that M4 (Quality factor) and M5 (priced loss) read — so the bad unit is recorded
--   ONCE. M5 spec 06 §4 reads qual.defect_record's disposition through the Serving API.
-- SOFT-REFERENCE RULE: references to OTHER module schemas (e.g. ops.route in M3,
--   maint.work_order in M2) are plain BIGINT *_ref values with NO cross-schema hard
--   FK, so canon/M6 stay independent. Hard FKs are used ONLY to canon.* and within qual.*.
-- THE no-double-count anchor: qual.defect_record.production_count_id is the canonical
--   ProductionCount; M6's defect-driven quality loss == M4 Quality factor (same good/total)
--   and == M5 priced loss (same DefectRecords) by construction.
-- =====================================================================

CREATE SCHEMA IF NOT EXISTS qual;
SET search_path = qual, canon, public;

-- ---------------------------------------------------------------------
-- 0. Enumerated types
-- ---------------------------------------------------------------------
CREATE TYPE qual.lens               AS ENUM ('VARIABLE','ATTRIBUTE');
CREATE TYPE qual.criticality        AS ENUM ('CRITICAL','MAJOR','MINOR');
CREATE TYPE qual.msa_status         AS ENUM ('NOT_ASSESSED','ACCEPTABLE','MARGINAL','UNACCEPTABLE');
CREATE TYPE qual.defect_source      AS ENUM ('IN_PROCESS','FINAL','INCOMING','SUPPLIER','CUSTOMER');
CREATE TYPE qual.disposition_type   AS ENUM ('PENDING','SCRAP','REWORK','DOWNGRADE','USE_AS_IS','RETURN_TO_SUPPLIER','ACCEPT');
CREATE TYPE qual.hold_status        AS ENUM ('OPEN','RELEASED','DISPOSITIONED','EXPIRED');
CREATE TYPE qual.ncr_status         AS ENUM ('OPEN','IN_MRB','DISPOSITIONED','CLOSED');
CREATE TYPE qual.capa_status        AS ENUM ('OPEN','CONTAINMENT','ROOT_CAUSE','CORRECTIVE','VERIFICATION','CLOSED','CANCELLED');
CREATE TYPE qual.rca_method         AS ENUM ('FIVE_WHY','FISHBONE','EIGHT_D','FMEA','OTHER');
CREATE TYPE qual.control_chart_type AS ENUM ('XBAR_R','XBAR_S','I_MR','P','NP','C','U');
CREATE TYPE qual.spc_rule_set       AS ENUM ('WESTERN_ELECTRIC','NELSON','CUSTOM');
CREATE TYPE qual.coq_category       AS ENUM ('PREVENTION','APPRAISAL','INTERNAL_FAILURE','EXTERNAL_FAILURE');
CREATE TYPE qual.sampling_basis     AS ENUM ('AQL_2859','FULL_100PCT','FIXED_N','CONTINUOUS_SPC');
CREATE TYPE qual.capture_fidelity   AS ENUM ('MANUAL','INGESTED','AUTOMATIC');
CREATE TYPE qual.readiness_gate     AS ENUM ('REQUIRED','QUALITY','FIDELITY','HISTORY');
CREATE TYPE qual.time_grain         AS ENUM ('SHIFT','DAY','WEEK','MONTH');
CREATE TYPE qual.inspection_result  AS ENUM ('PASS','FAIL','PASS_WITH_DEVIATION');
CREATE TYPE qual.rank_basis         AS ENUM ('COUNT','COST');

-- ---------------------------------------------------------------------
-- 1. Quality reference & policy
-- ---------------------------------------------------------------------

-- 1.1 Per-tenant quality policy (definitions-as-configuration)
CREATE TABLE qual.quality_config (
    config_id              BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id              UUID         NOT NULL,
    default_spc_rule_set   qual.spc_rule_set NOT NULL DEFAULT 'WESTERN_ELECTRIC',
    cpk_target             NUMERIC(4,2) NOT NULL DEFAULT 1.33,   -- general capability floor
    cpk_target_critical    NUMERIC(4,2) NOT NULL DEFAULT 1.67,   -- floor for CRITICAL characteristics
    msa_blocks_capability  BOOLEAN      NOT NULL DEFAULT TRUE,    -- unqualified gage hides published Cpk
    coq_scope              TEXT         NOT NULL DEFAULT 'IF_AND_APPRAISAL', -- v1 COQ buckets in scope
    mrb_severity_threshold qual.criticality NOT NULL DEFAULT 'MAJOR', -- at/above -> full MRB
    effective_from         TIMESTAMPTZ  NOT NULL DEFAULT now(),
    effective_to           TIMESTAMPTZ,
    ext                    JSONB        NOT NULL DEFAULT '{}'::jsonb,
    created_at             TIMESTAMPTZ  NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, effective_from)
);

-- 1.2 Per work-unit capture / MSA configuration
CREATE TABLE qual.work_unit_config (
    work_unit_config_id  BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    work_unit_ref        BIGINT      NOT NULL REFERENCES canon.equipment_node(node_id),
    capture_fidelity     qual.capture_fidelity NOT NULL DEFAULT 'MANUAL',
    default_sampling     qual.sampling_basis   NOT NULL DEFAULT 'FIXED_N',
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, work_unit_ref)
);

-- 1.3 Quality characteristic master (variable or attribute; criticality; MSA)
CREATE TABLE qual.characteristic (
    characteristic_id    BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    code                 TEXT        NOT NULL,                   -- e.g. THICKNESS, HARDNESS, SURFACE
    name                 TEXT        NOT NULL,
    lens                 qual.lens   NOT NULL,                   -- VARIABLE -> SPC; ATTRIBUTE -> defect
    criticality          qual.criticality NOT NULL DEFAULT 'MAJOR',
    uom                  TEXT,                                   -- mm, HRB, MPa ... (NULL for attribute)
    work_unit_ref        BIGINT      REFERENCES canon.equipment_node(node_id),
    material_ref         BIGINT      REFERENCES canon.material(material_id), -- grade scope (NULL = all)
    msa_status           qual.msa_status NOT NULL DEFAULT 'NOT_ASSESSED',
    gage_rr_pct          NUMERIC(5,2),                           -- % Gage R&R (lower is better)
    is_active            BOOLEAN     NOT NULL DEFAULT TRUE,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, code, work_unit_ref)
);

-- 1.4 Specification limits (versioned; per characteristic x grade) — defines "in spec"
CREATE TABLE qual.spec_limit (
    spec_id              BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    characteristic_ref   BIGINT      NOT NULL REFERENCES qual.characteristic(characteristic_id),
    grade_ref            BIGINT      REFERENCES canon.material(material_id),  -- grade variant
    nominal              NUMERIC(14,5),                          -- target
    usl                  NUMERIC(14,5),                          -- upper spec limit
    lsl                  NUMERIC(14,5),                          -- lower spec limit
    version              INT         NOT NULL DEFAULT 1,
    is_active            BOOLEAN     NOT NULL DEFAULT TRUE,
    effective_from       TIMESTAMPTZ NOT NULL DEFAULT now(),
    effective_to         TIMESTAMPTZ,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, characteristic_ref, grade_ref, version)
);

-- 1.5 Inspection / control plan header (PFMEA -> control plan, the specify layer)
CREATE TABLE qual.inspection_plan (
    plan_id              BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    name                 TEXT        NOT NULL,
    work_unit_ref        BIGINT      NOT NULL REFERENCES canon.equipment_node(node_id),
    route_ref            BIGINT,                                 -- soft ref to ops.route (M3)
    is_active            BOOLEAN     NOT NULL DEFAULT TRUE,
    version              INT         NOT NULL DEFAULT 1,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, name, version)
);

-- 1.6 Inspection plan item (characteristic x sampling x reaction inside a plan)
CREATE TABLE qual.inspection_plan_item (
    plan_item_id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    plan_ref             BIGINT      NOT NULL REFERENCES qual.inspection_plan(plan_id),
    characteristic_ref   BIGINT      NOT NULL REFERENCES qual.characteristic(characteristic_id),
    sampling_basis       qual.sampling_basis NOT NULL DEFAULT 'FIXED_N',
    aql_pct              NUMERIC(5,3),                           -- AQL when sampling = AQL_2859
    sample_size          INT,                                   -- fixed-n / per-lot sample
    frequency_txt        TEXT,                                  -- e.g. 'per coil', 'every 30 min'
    reaction_txt         TEXT,                                  -- reaction plan on a limit breach
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (plan_ref, characteristic_ref)
);

-- 1.7 Governed defect taxonomy (3-layer self-referencing; M6 masters it)
--     Layer 1 category -> Layer 2 type -> Layer 3 root-cause detail.
CREATE TABLE qual.defect_code (
    defect_code_id       BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    parent_code_id       BIGINT      REFERENCES qual.defect_code(defect_code_id), -- NULL at Layer 1
    layer                SMALLINT    NOT NULL CHECK (layer BETWEEN 1 AND 3),
    code                 TEXT        NOT NULL,
    label                TEXT        NOT NULL,
    criticality          qual.criticality NOT NULL DEFAULT 'MAJOR',
    default_disposition  qual.disposition_type NOT NULL DEFAULT 'PENDING',
    loss_category_ref    BIGINT      REFERENCES canon.loss_category(category_id), -- Six Big Losses map
    is_other_bucket      BOOLEAN     NOT NULL DEFAULT FALSE,     -- exactly one governed 'Other'
    is_active            BOOLEAN     NOT NULL DEFAULT TRUE,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, code)
);

-- ---------------------------------------------------------------------
-- 2. Conformance capture (inspection + measurement) — capture-agnostic
-- ---------------------------------------------------------------------

-- 2.1 Executed inspection event (links to the shared ProductionCount / lot)
CREATE TABLE qual.inspection (
    inspection_id        BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    plan_ref             BIGINT      REFERENCES qual.inspection_plan(plan_id),
    production_count_id  BIGINT      REFERENCES canon.production_count(count_id), -- the shared count
    lot_ref              BIGINT      REFERENCES canon.material_lot(lot_id),       -- COIL_NO
    work_unit_ref        BIGINT      REFERENCES canon.equipment_node(node_id),
    shift_ref            BIGINT      REFERENCES canon.shift(shift_id),
    capture_fidelity     qual.capture_fidelity NOT NULL DEFAULT 'MANUAL',
    sample_size          INT,
    result               qual.inspection_result NOT NULL DEFAULT 'PASS',
    inspector            TEXT,
    inspected_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_qual_inspection_count ON qual.inspection (production_count_id);
CREATE INDEX ix_qual_inspection_lot   ON qual.inspection (lot_ref);

-- 2.2 Variable measurement (the SPC input stream)
CREATE TABLE qual.measurement (
    measurement_id       BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    inspection_ref       BIGINT      REFERENCES qual.inspection(inspection_id),
    characteristic_ref   BIGINT      NOT NULL REFERENCES qual.characteristic(characteristic_id),
    spec_ref             BIGINT      REFERENCES qual.spec_limit(spec_id),
    lot_ref              BIGINT      REFERENCES canon.material_lot(lot_id),
    value_num            NUMERIC(14,5) NOT NULL,
    in_spec              BOOLEAN,                                -- computed vs spec_ref
    subgroup_key         TEXT,                                  -- groups values into an SPC subgroup
    measured_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_qual_meas_char ON qual.measurement (characteristic_ref, measured_at);

-- ---------------------------------------------------------------------
-- 3. SPC & capability
-- ---------------------------------------------------------------------

-- 3.1 Control chart definition + current limits + capability indices
CREATE TABLE qual.control_chart (
    chart_id             BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    characteristic_ref   BIGINT      NOT NULL REFERENCES qual.characteristic(characteristic_id),
    work_unit_ref        BIGINT      REFERENCES canon.equipment_node(node_id),
    grade_ref            BIGINT      REFERENCES canon.material(material_id),
    chart_type           qual.control_chart_type NOT NULL,
    rule_set             qual.spc_rule_set NOT NULL DEFAULT 'WESTERN_ELECTRIC',
    subgroup_size        INT         NOT NULL DEFAULT 1,
    center_line          NUMERIC(14,5),
    ucl                  NUMERIC(14,5),
    lcl                  NUMERIC(14,5),
    cp                   NUMERIC(6,3),
    cpk                  NUMERIC(6,3),
    pp                   NUMERIC(6,3),
    ppk                  NUMERIC(6,3),
    in_control           BOOLEAN     NOT NULL DEFAULT TRUE,
    limits_recalc_at     TIMESTAMPTZ,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, characteristic_ref, work_unit_ref, grade_ref, chart_type)
);

-- 3.2 SPC special-cause signal (a run-rule violation)
CREATE TABLE qual.spc_signal (
    signal_id            BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    chart_ref            BIGINT      NOT NULL REFERENCES qual.control_chart(chart_id),
    rule_code            TEXT        NOT NULL,                   -- e.g. WE1 (beyond 3s), NELSON3 (trend)
    description          TEXT,
    sample_value         NUMERIC(14,5),
    is_acknowledged      BOOLEAN     NOT NULL DEFAULT FALSE,
    raised_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_qual_signal_chart ON qual.spc_signal (chart_ref, raised_at);

-- ---------------------------------------------------------------------
-- 4. Defect record (the quality SoR event) + disposition
-- ---------------------------------------------------------------------

-- 4.1 DefectRecord — Event-Spine specialisation MASTERED by M6.
--     Anchored to the SAME canon.production_count M4/M5 read (no double-count).
CREATE TABLE qual.defect_record (
    defect_record_id     BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    event_id             BIGINT      REFERENCES canon.event(event_id),            -- registered on the spine
    production_count_id  BIGINT      REFERENCES canon.production_count(count_id), -- the shared count anchor
    lot_ref              BIGINT      REFERENCES canon.material_lot(lot_id),       -- COIL_NO
    inspection_ref       BIGINT      REFERENCES qual.inspection(inspection_id),
    defect_code_ref      BIGINT      NOT NULL REFERENCES qual.defect_code(defect_code_id),
    source               qual.defect_source NOT NULL DEFAULT 'IN_PROCESS',
    severity             qual.criticality NOT NULL DEFAULT 'MAJOR',
    disposition          qual.disposition_type NOT NULL DEFAULT 'PENDING',
    from_grade_ref       BIGINT      REFERENCES canon.material(material_id),      -- downgrade: from
    to_grade_ref         BIGINT      REFERENCES canon.material(material_id),      -- downgrade: to
    qty_count            NUMERIC(14,3),                          -- units affected
    qty_mass_mt          NUMERIC(14,4),                          -- mass affected (M5 prices this)
    location             JSONB       NOT NULL DEFAULT '{}'::jsonb,-- coil position / defect-map coords
    detected_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_qual_defrec_count ON qual.defect_record (production_count_id);
CREATE INDEX ix_qual_defrec_code  ON qual.defect_record (defect_code_ref);
CREATE INDEX ix_qual_defrec_lot   ON qual.defect_record (lot_ref);

-- 4.2 Quality hold (containment / quarantine) -> M3 QUALITY_HOLD carryover
CREATE TABLE qual.quality_hold (
    hold_id              BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    lot_ref              BIGINT      REFERENCES canon.material_lot(lot_id),
    defect_record_ref    BIGINT      REFERENCES qual.defect_record(defect_record_id),
    status               qual.hold_status NOT NULL DEFAULT 'OPEN',
    reason_txt           TEXT,
    opened_by            TEXT,
    opened_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
    released_at          TIMESTAMPTZ,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_qual_hold_status ON qual.quality_hold (status, opened_at);

-- ---------------------------------------------------------------------
-- 5. Nonconformance (NCR / MRB) + CAPA
-- ---------------------------------------------------------------------

-- 5.1 Nonconformance case (groups defect records; drives MRB)
CREATE TABLE qual.nonconformance (
    ncr_id               BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    title                TEXT        NOT NULL,
    severity             qual.criticality NOT NULL DEFAULT 'MAJOR',
    status               qual.ncr_status NOT NULL DEFAULT 'OPEN',
    primary_defect_ref   BIGINT      REFERENCES qual.defect_record(defect_record_id),
    mrb_decision         qual.disposition_type,
    mrb_authoriser       TEXT,
    opened_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
    closed_at            TIMESTAMPTZ,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 5.2 NCR <-> defect_record link (an NCR may span many records)
CREATE TABLE qual.ncr_defect_link (
    ncr_ref              BIGINT      NOT NULL REFERENCES qual.nonconformance(ncr_id),
    defect_record_ref    BIGINT      NOT NULL REFERENCES qual.defect_record(defect_record_id),
    PRIMARY KEY (ncr_ref, defect_record_ref)
);

-- 5.3 CAPA / 8D case (root cause -> corrective + preventive -> verify)
CREATE TABLE qual.capa (
    capa_id              BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    ncr_ref              BIGINT      REFERENCES qual.nonconformance(ncr_id),
    title                TEXT        NOT NULL,
    status               qual.capa_status NOT NULL DEFAULT 'OPEN',
    rca_method           qual.rca_method NOT NULL DEFAULT 'FIVE_WHY',
    root_cause           TEXT,
    containment_action   TEXT,                                   -- D3
    corrective_action    TEXT,                                   -- D5/D6
    preventive_action    TEXT,                                   -- D7
    fmea_updated         BOOLEAN     NOT NULL DEFAULT FALSE,     -- loop back to control plan
    effectiveness_verified BOOLEAN   NOT NULL DEFAULT FALSE,     -- D8 gate to close
    owner                TEXT,
    due_at               TIMESTAMPTZ,
    opened_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
    closed_at            TIMESTAMPTZ,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_qual_capa_status ON qual.capa (status, due_at);

-- ---------------------------------------------------------------------
-- 6. Cost of Quality + targets + governance
-- ---------------------------------------------------------------------

-- 6.1 Cost-of-Quality ledger entry (PAF model; internal-failure == M5 loss, once)
CREATE TABLE qual.coq_entry (
    coq_id               BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    coq_category         qual.coq_category NOT NULL,
    defect_record_ref    BIGINT      REFERENCES qual.defect_record(defect_record_id),
    capa_ref             BIGINT      REFERENCES qual.capa(capa_id),
    cost_rate_ref        BIGINT      REFERENCES canon.cost_rate(rate_id),
    amount               NUMERIC(16,2) NOT NULL,
    currency             TEXT        NOT NULL DEFAULT 'INR',
    is_from_m5_loss      BOOLEAN     NOT NULL DEFAULT FALSE,     -- TRUE when sourced from M5 priced loss
    period_grain         qual.time_grain NOT NULL DEFAULT 'MONTH',
    period_start         DATE,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_qual_coq_cat ON qual.coq_entry (coq_category, period_start);

-- 6.2 Quality targets (per characteristic / work-unit / KPI)
CREATE TABLE qual.quality_target (
    target_id            BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    kpi_code             TEXT        NOT NULL,                   -- FPY, CPK, DPMO, COQ_PCT ...
    work_unit_ref        BIGINT      REFERENCES canon.equipment_node(node_id),
    characteristic_ref   BIGINT      REFERENCES qual.characteristic(characteristic_id),
    target_value         NUMERIC(14,4) NOT NULL,
    effective_from       TIMESTAMPTZ NOT NULL DEFAULT now(),
    effective_to         TIMESTAMPTZ,
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 6.3 Policy change log (audit any spec / limit / disposition-rule / taxonomy change)
CREATE TABLE qual.policy_change_log (
    change_id            BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    entity_type          TEXT        NOT NULL,                   -- SPEC_LIMIT, CONTROL_CHART, DEFECT_CODE ...
    entity_id            BIGINT      NOT NULL,
    change_summary       TEXT        NOT NULL,
    changed_by           TEXT        NOT NULL,
    effective_from       TIMESTAMPTZ NOT NULL DEFAULT now(),
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 6.4 Readiness snapshot (Required / Quality / Fidelity(MSA) / History gates)
CREATE TABLE qual.readiness_snapshot (
    snapshot_id          BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    work_unit_ref        BIGINT      REFERENCES canon.equipment_node(node_id),
    gate                 qual.readiness_gate NOT NULL,
    score_pct            NUMERIC(5,2),
    detail               JSONB       NOT NULL DEFAULT '{}'::jsonb,
    captured_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 6.5 Quality prediction (FUTURE SCOPE stub — defect-risk / SPC-excursion / CV)
CREATE TABLE qual.quality_prediction (
    prediction_id        BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tenant_id            UUID        NOT NULL,
    characteristic_ref   BIGINT      REFERENCES qual.characteristic(characteristic_id),
    work_unit_ref        BIGINT      REFERENCES canon.equipment_node(node_id),
    grade_ref            BIGINT      REFERENCES canon.material(material_id),
    horizon_txt          TEXT,
    predicted_defect_ppm NUMERIC(12,2),
    model_version        TEXT,
    is_active            BOOLEAN     NOT NULL DEFAULT FALSE,     -- dark until History gate passes
    generated_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    ext                  JSONB       NOT NULL DEFAULT '{}'::jsonb
);

-- ---------------------------------------------------------------------
-- 7. Roll-up views (SUM-then-divide; never average sub-ratios)
-- ---------------------------------------------------------------------

-- 7.1 Conformance roll-up — FPY / quality-ratio / defect-rate from canonical counts
CREATE VIEW qual.v_quality_rollup AS
SELECT
    dr.tenant_id,
    pc.work_unit_ref,
    pc.material_ref,
    date_trunc('day', dr.detected_at)                          AS day,
    COUNT(*)                                                   AS defect_count,
    SUM(COALESCE(dr.qty_count, 0))                             AS defect_qty,
    SUM(COALESCE(dr.qty_mass_mt, 0))                           AS defect_mass_mt,
    SUM(CASE WHEN dr.disposition = 'SCRAP'     THEN 1 ELSE 0 END) AS scrap_count,
    SUM(CASE WHEN dr.disposition = 'REWORK'    THEN 1 ELSE 0 END) AS rework_count,
    SUM(CASE WHEN dr.disposition = 'DOWNGRADE' THEN 1 ELSE 0 END) AS downgrade_count
FROM qual.defect_record dr
JOIN canon.production_count pc ON pc.count_id = dr.production_count_id
GROUP BY dr.tenant_id, pc.work_unit_ref, pc.material_ref, date_trunc('day', dr.detected_at);

-- 7.2 Cost-of-Quality roll-up — the PAF buckets, priced
CREATE VIEW qual.v_coq_rollup AS
SELECT
    tenant_id,
    period_start,
    coq_category,
    SUM(amount)                                               AS total_cost,
    COUNT(*)                                                  AS entry_count
FROM qual.coq_entry
GROUP BY tenant_id, period_start, coq_category;

-- =====================================================================
-- End M6 qual schema. Build phasing in 00_INDEX_and_Architecture.md.
-- =====================================================================
