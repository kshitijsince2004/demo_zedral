# 07 · APIs, Events & Integration Spec
**Phase M6-2 · deep-plan §0, §12**

## 1. Serving APIs (read-heavy; versioned)

| API | Returns |
|---|---|
| `GET /quality/conformance?scope&grain` | FPY, Quality-ratio, defect rate/ppm, disposition mix |
| `GET /quality/spc/{characteristic}?work_unit&grade` | control chart (limits, points), signals, Cp/Cpk/Pp/Ppk + MSA status |
| `GET /quality/defects?scope&by=type|step|grade|supplier` | governed defect Pareto (count & cost) |
| `GET /quality/holds?status` | open/aged quality holds |
| `GET /quality/ncr/{id}` · `GET /quality/capa?status` | NCR/MRB record; CAPA backlog & recurrence |
| `GET /quality/coq?period` | PAF buckets, COPQ, prevention ROI |
| `GET /quality/certificate/{lot}` | certificate of analysis / mill test certificate |

## 2. Published events (others subscribe; M6 never writes their tables)

| Event | Consumer | Use |
|---|---|---|
| `quality.hold.opened` / `.released` | **M3** | `QUALITY_HOLD` handover carryover + MRP netting |
| `quality.defect.recorded` (with disposition) | **M5** | attribute & price the material loss |
| `quality.spc.signal` | Monitoring | out-of-control alert; containment prompt |
| `quality.capa.opened` / `.closed` | UIL / Monitoring | overdue-CAPA board, recurrence trend |
| `quality.coq.updated` | Financial Impact / UIL | COQ rollup, prevention-ROI |

## 3. Consumed (via canonical Serving APIs / Event Spine — golden rule)

`canon.production_count` (the shared count — conformance denominator); `canon.material_lot` genealogy (COIL_NO); `canon.material` (grade); `canon.cost_rate` (D7); **M5** priced internal-failure loss (for COQ, counted once); **M4** quality-loss-minutes context; **M2** equipment-condition link (`defect_record` ↔ `maint.work_order`, soft ref) for equipment-attributable defects; **M1** first-party measurements/defects.

## 4. The shared-truth contract (deep-plan §12)

M4/M5 read M6's `DefectRecord` through the **Serving DefectRecord projection**, never by querying `qual.*` directly. The bad unit is recorded once (`defect_record.production_count_id` = the canonical count); M6 classifies & dispositions, M4 reads the Quality factor, M5 prices the loss. No module writes another's tables; everything moves through canonical entities + versioned Serving APIs.

## 5. Manifold integration

M6 ships a **quality sector template** (steel surface/dimensional/mechanical characteristics, spec limits, control plan, defect catalog incl. grade-downgrade rules, sampling plan) seeded in Manifold. Ingested QMS/LIMS/lab fields map through the field-mapping engine + review queue (D5); readiness/unlock per doc 01 §16.
