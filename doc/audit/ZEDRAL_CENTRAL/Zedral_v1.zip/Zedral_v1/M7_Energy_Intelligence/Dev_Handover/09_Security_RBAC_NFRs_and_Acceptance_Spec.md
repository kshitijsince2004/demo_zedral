# 09 · Security, RBAC, NFRs & Acceptance Spec
**Build:** All phases · deep-plan §13

## 1. Roles (extend M1 Operator/Supervisor/Plant-Head/Admin)

| Role | Can |
|---|---|
| **Operator / Utilities operator** | record manual reads & fuel logs; see live load/demand tile + peak-approach alert for their area |
| **Shift Supervisor** | shift energy & intensity, demand & PF status; validate reads; act on load-shed/shift prompt |
| **Energy Manager / ISO 50001 lead** | configure carriers, meters, SEUs, EnPI defs & targets, baselines, normalisation drivers; run M&V; own the energy review & management-review pack |
| **Energy Engineer** | analyse SEU consumption, build regression baselines, size corrections (capacitors, VFDs, leak fixes) |
| **Sustainability / Carbon analyst** | Scope 1/2, location vs market, ISO 14404 intensity; emission-factor config |
| **Cost / Finance analyst** | read priced energy waste (read-only) |
| **Plant Manager** | energy trends, ₹ + CO₂, demand & baseline status (read-only) |
| **Admin** | masters, meter/connector integration, tariff & emission-factor config, energy policy |

## 2. Governance & audit

Energy configuration (baselines, normalisation drivers, tariff structure, emission factors, carrier factors) directly moves the EnPI/cost/carbon numbers → **every change is audit-logged** (`policy_change_log`) with effective dating (ISO 50001 traceability); an EnPI/CO₂ trend is never silently broken by a re-baseline or factor revision (old baseline version preserved); a saving is always attributable to a baseline version. The energy SoR (consumption, bills, baselines, M&V) is **append-only / audit-trailed** for ISO 50001 / ISO 14404 / GHG-assurance retention. Row-level scoping by site/area (M1). First-party/edge capture is **offline-tolerant** (queue local reads, sync on reconnect).

## 3. NFRs

Deterministic & replayable recompute from canonical readings (corrected reading / re-versioned factor re-derives consumption/EnPI/cost/CO₂ without manual patching). Live tile latency = D2 near-real-time (where automatic metering exists); scheduled baseline/EnPI/carbon rollups via Airflow. Tenant isolation = D8 logical default. No new infra beyond inherited stack (spec 00 §5). Multi-currency aware (`currency` columns); multi-carrier unit-safe (units in column names).

## 4. Acceptance tests (module-level gates)

1. **Balance closes** — purchased+generated == distributed+loss+gap within `balance_gap_tolerance`; gap named, not waste.
2. **EnPI normalised** — actual vs baseline-expected reproduces a known month within ε; SUM-then-divide rollups.
3. **Reconciliation (no double-count)** — EnPI denominator == M4/M5/M6 tonnes; idle-energy ↔ same M4 `StateInterval`; embodied-energy == M5 loss energy == M6 defect energy, counted once.
4. **Demand** — peak-approach fires before breach; PF penalty + correction sized.
5. **Carbon** — Scope 2 both location & market; ISO 14404 intensity ties to Σ Scope 1+2 ÷ tonnes.
6. **Fidelity honesty** — uncalibrated meter excluded from baseline fit; apportioned ≠ metered confidence.
7. **MVP migration gate** — existing kWh/energy-cost/intensity == canonical on the back-test window; existing dashboards keep running while repointed onto `energy.*`.
8. **Audit** — every config/baseline/factor change logged with effective dating; recompute reproducible.
