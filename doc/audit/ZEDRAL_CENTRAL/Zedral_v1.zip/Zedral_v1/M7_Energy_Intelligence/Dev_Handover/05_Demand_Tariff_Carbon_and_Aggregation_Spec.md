# 05 · Demand, Tariff, Carbon & Aggregation Spec
**Build:** Phase M7-2/3 · deep-plan §7

> M7's deepest differentiation over a flat "kWh dashboard": the demand/power-quality charges set by a handful of unmanaged moments, and the carbon nobody priced until asked.

## 1. The tariff model (the bill is not one number)

`tariff` + `tariff_period` decompose the bill so it can be predicted and optimised: **energy charge** (ToU peak/shoulder/off-peak rate per `tariff_period`), **demand charge** (`demand_charge_per_kva` × max kVA), **power-factor penalty** (`pf_penalty_per_kvarh` below `energy_config.pf_penalty_threshold`), **fixed/capacity**, **fuel/gas charge**, **carbon price** (`carbon_price_per_tonne`). Effective-dated (rate-as-of, D7).

## 2. Demand management (manage the moment, don't pay for it)

`demand_interval` tracks the rolling **maximum demand** over the `energy_config.demand_window` (15/30-min) against `tariff.contracted_demand_kva` and the historical monthly peak. `event_kind`: **PEAK_APPROACH** (raise with lead time to shed/shift), **PEAK_BREACH**, **PF_PENALTY**. The value is entirely *before* the peak sets the month's demand charge. `power_factor` watched against threshold → capacitor-correction opportunity (raise > 0.95). ToU surface exposed to M3 for energy-aware scheduling. In v1 these are **signals/decision support** off the bill & early meters; **automated demand response / load control** is the future-proofed rung on the real-time metering interface (spec 08).

## 3. Carbon accounting (two-scope, steel-literal)

`emission_entry` derives carbon from the same consumption, per the GHG Protocol:
- **Scope 1** — on-site combustion (furnace gas, DG fuel): GJ × `emission_factor` combustion factor.
- **Scope 2** — purchased electricity/steam, **both** `SCOPE_2_LOCATION` (grid average factor) **and** `SCOPE_2_MARKET` (contractual/PPA/REC, residual-mix remainder). The two disagree by exactly the clean-energy procurement — both shown.
- **ISO 14404 intensity** — tCO₂ per tonne on the standard import/export boundary (Part 2 EAF / Part 1 BF / Part 3 EAF+DRI). M7 produces the universal-calculation-sheet inputs from metered carriers.
- **Scope 3** = future-proofed hook (`ghg_scope` enum carries it).

## 4. Embodied-energy of loss/defect (the M7↔M5↔M6 seam)

Energy spent making material then scrapped/downgraded is wasted twice. `energy_waste_entry` (category EMBODIED_SCRAP) computes the kWh/GJ + kgCO₂e attributable (per-process SEC × the lost/defective quantity) to M5's yield loss (`m5_loss_ref`) and M6's defective units (`m6_defect_ref`). This is the **same** energy as the energy component of M5/M6's loss — counted **once** (§6, spec 06 §4), never re-priced.

## 5. Aggregation pipeline

Streaming path (where automatic metering exists): live load/demand tile + peak-approach/PF/baseline-excursion alerts (Flink → Redis). Scheduled rollups (Airflow): `energy_consumption` → `energy_balance`, `enpi_value` (EnPI + CUSUM + avoided), `emission_entry`, `energy_cost_entry`, `energy_waste_entry` → the `v_*` Serving views. Deterministic & replayable: a corrected reading or re-versioned factor re-derives affected consumption/EnPI/cost/CO₂ without manual patching (old baseline version preserved).

## 6. Acceptance (this spec)

A bill decomposes into the right tariff components; a simulated demand approaching the cap raises PEAK_APPROACH before breach; low PF flags the penalty + correction size; Scope 2 produces both location and market figures; ISO 14404 intensity reconciles to summed Scope 1+2 ÷ tonnes; embodied-energy of a scrap lot equals SEC × lost qty and ties to the M5 loss row without re-pricing.
