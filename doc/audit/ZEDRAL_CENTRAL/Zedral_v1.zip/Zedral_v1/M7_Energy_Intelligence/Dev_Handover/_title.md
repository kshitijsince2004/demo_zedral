---
title: "Zedral · M7 Energy Intelligence — Developer Handover"
subtitle: "v1 for build · all-utilities multi-carrier · dual-lens (absolute + normalised EnPI) · ISO 50001/50006/50015 · IPMVP · GHG Scope 1/2 + ISO 14404 · full-EnMS target with future-proofed automatic metering & prediction"
date: "2026-06-19"
---

